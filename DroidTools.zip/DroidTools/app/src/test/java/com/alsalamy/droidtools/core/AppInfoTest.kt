package com.alsalamy.droidtools.core

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class AppInfoTest {

    @Test
    fun knownPermissionsAreTranslated() {
        assertEquals("Accès à Internet", AppInfo.permissionLabel("android.permission.INTERNET"))
        assertEquals("Caméra", AppInfo.permissionLabel("android.permission.CAMERA"))
        assertTrue(
            AppInfo.permissionLabel("com.alsalamy.droidtools.DYNAMIC_RECEIVER_NOT_EXPORTED_PERMISSION").startsWith("Permission interne"),
        )
        assertEquals("com.example.UNKNOWN", AppInfo.permissionLabel("com.example.UNKNOWN"))
    }
}
