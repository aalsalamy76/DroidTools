package com.alsalamy.droidtools.ui.settings

import android.content.ActivityNotFoundException
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.consumeWindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.OpenInNew
import androidx.compose.material.icons.rounded.CleaningServices
import androidx.compose.material.icons.rounded.DeleteForever
import androidx.compose.material.icons.rounded.DeleteSweep
import androidx.compose.material.icons.rounded.History
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import com.alsalamy.droidtools.core.AppInfo
import com.alsalamy.droidtools.core.ByteFormat
import com.alsalamy.droidtools.core.LocalAppContainer
import com.alsalamy.droidtools.data.AppSettings
import com.alsalamy.droidtools.domain.SensitiveResource
import com.alsalamy.droidtools.domain.ToolCatalog
import com.alsalamy.droidtools.forms.NoticeLevel
import com.alsalamy.droidtools.ui.components.BackButton
import com.alsalamy.droidtools.ui.components.CenteredContent
import com.alsalamy.droidtools.ui.components.InfoCard
import com.alsalamy.droidtools.ui.components.LocalMessenger
import com.alsalamy.droidtools.ui.components.NoticeCard
import com.alsalamy.droidtools.ui.components.SectionHeader
import com.alsalamy.droidtools.ui.components.withInner
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

private const val INTERNET = "android.permission.INTERNET"

/** Contenu du cache (fichiers temporaires) : taille et suppression. */
private fun cacheSize(dir: File): Long = dir.walkTopDown().filter { it.isFile }.sumOf { it.length() }

private fun clearCache(dir: File) {
    dir.listFiles()?.forEach { it.deleteRecursively() }
}

@Composable
fun PrivacyCenterScreen(settings: AppSettings, onBack: () -> Unit, onOpenTool: (String) -> Unit) {
    val context = LocalContext.current
    val container = LocalAppContainer.current
    val messenger = LocalMessenger.current
    val scope = rememberCoroutineScope()

    // Relu à chaque retour sur l'écran (l'utilisateur peut modifier les permissions dans Android).
    var refresh by remember { mutableIntStateOf(0) }
    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) { refresh++ }
    val permissions = remember(refresh) { AppInfo.requestedPermissions(context) }
    val internetDeclared = permissions.any { it.name == INTERNET }
    var cache by remember { mutableStateOf<Long?>(null) }
    LaunchedEffect(refresh) { cache = withContext(Dispatchers.IO) { cacheSize(container.cacheDir) } }
    var confirmWipe by remember { mutableStateOf(false) }

    Scaffold(topBar = { TopAppBar(title = { Text("Confidentialité et sécurité") }, navigationIcon = { BackButton(onBack) }) }) { padding ->
        CenteredContent {
            Column(
                Modifier.fillMaxSize().consumeWindowInsets(padding).verticalScroll(rememberScrollState()).padding(padding.withInner()),
                verticalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                // Constat vérifié à l'exécution à partir du manifeste réellement installé.
                if (internetDeclared) {
                    NoticeCard("Cette version déclare la permission Internet. Les outils qui l'utilisent sont signalés « Réseau requis ».", NoticeLevel.WARNING)
                } else {
                    NoticeCard(
                        "Cette version de DroidTools ne déclare pas la permission Internet : Android l'empêche d'ouvrir la moindre connexion réseau. " +
                            "Tous les traitements ont lieu sur l'appareil.",
                        NoticeLevel.SUCCESS,
                    )
                }

                SectionHeader("Permissions")
                val granted = permissions.filter { it.granted }
                val denied = permissions.filterNot { it.granted }
                InfoCard {
                    Text("Accordées", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
                    if (granted.isEmpty()) Text("Aucune.") else granted.forEach { Text("• ${it.label}", style = MaterialTheme.typography.bodyMedium) }
                    Text("Refusées ou non accordées", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(top = 8.dp))
                    if (denied.isEmpty()) Text("Aucune.") else denied.forEach { Text("• ${it.label}", style = MaterialTheme.typography.bodyMedium) }
                    Text(
                        "Les permissions sensibles (caméra, micro, localisation) ne seront demandées qu'au lancement d'un outil qui en a besoin, " +
                            "avec une explication préalable. Aucun outil actuel n'en a besoin.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
                NavRow(Icons.AutoMirrored.Rounded.OpenInNew, "Ouvrir les réglages Android de DroidTools", "Permissions, stockage, notifications") {
                    val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.fromParts("package", context.packageName, null))
                    try {
                        context.startActivity(intent)
                    } catch (e: ActivityNotFoundException) {
                        messenger.show("Réglages Android indisponibles sur cet appareil.")
                    }
                }

                SectionHeader("Fonctions accédant à des ressources sensibles")
                SensitiveResource.entries.forEach { resource ->
                    val active = ToolCatalog.all.filter { it.privacy?.resources?.contains(resource) == true }
                    InfoCard {
                        Text(resource.label, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
                        if (active.isEmpty()) {
                            Text("Aucun outil disponible n'y accède.", style = MaterialTheme.typography.bodyMedium)
                        } else {
                            active.forEach { tool ->
                                Text(
                                    "• ${tool.name} — ${tool.privacy?.resourceUsage.orEmpty()}",
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.clickable(onClickLabel = "Ouvrir ${tool.name}") { onOpenTool(tool.id) },
                                )
                            }
                        }
                    }
                }

                SectionHeader("Données stockées sur l'appareil")
                InfoCard {
                    Text(
                        "• Réglages (thème, couleurs, historique activé ou non)\n" +
                            "• Favoris : ${settings.favorites.size} outil(s)\n" +
                            "• Outils récents : " + (if (settings.historyEnabled) "${settings.recents.size} outil(s)" else "désactivé") + "\n" +
                            "• Checklist (si vous l'utilisez), non chiffrée\n" +
                            "• Cache : " + (cache?.let { ByteFormat.format(it) } ?: "calcul…"),
                        style = MaterialTheme.typography.bodyMedium,
                    )
                    Text(
                        "Tout reste dans l'espace privé de l'application, exclu des sauvegardes Android et des transferts entre appareils. " +
                            "Aucun mot de passe, PIN ou contenu saisi dans un outil n'est enregistré.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
                SwitchRow(
                    icon = Icons.Rounded.History,
                    title = "Mémoriser les outils récents",
                    subtitle = "Désactiver efface aussi l'historique existant",
                    checked = settings.historyEnabled,
                    enabled = true,
                    onChange = { enabled -> container.launch { container.settings.setHistoryEnabled(enabled) } },
                )
                NavRow(Icons.Rounded.DeleteSweep, "Vider l'historique", "Efface la liste des outils récents") {
                    container.launch { container.settings.clearRecents() }
                    messenger.show("Historique vidé.")
                }
                NavRow(Icons.Rounded.CleaningServices, "Vider le cache et les fichiers temporaires", cache?.let { ByteFormat.format(it) }) {
                    scope.launch {
                        withContext(Dispatchers.IO) { clearCache(container.cacheDir) }
                        refresh++
                        messenger.show("Cache vidé.")
                    }
                }
                NavRow(Icons.Rounded.DeleteForever, "Effacer toutes les données de DroidTools", "Réglages, favoris, historique, checklist et cache") {
                    confirmWipe = true
                }

                SectionHeader("Aucun traçage")
                InfoCard {
                    Text(
                        "DroidTools n'intègre ni publicité, ni outil d'analyse d'usage, ni identifiant publicitaire, ni service de rapport de plantage. " +
                            "Aucune donnée n'est envoyée au développeur.",
                        style = MaterialTheme.typography.bodyMedium,
                    )
                }
            }
        }
    }

    if (confirmWipe) {
        AlertDialog(
            onDismissRequest = { confirmWipe = false },
            title = { Text("Tout effacer ?") },
            text = { Text("Réglages, favoris, historique, checklist et cache seront définitivement supprimés de cet appareil.") },
            confirmButton = {
                TextButton(onClick = {
                    confirmWipe = false
                    scope.launch {
                        container.settings.clearAll()
                        container.checklist.clear()
                        withContext(Dispatchers.IO) { clearCache(container.cacheDir) }
                        refresh++
                        messenger.show("Toutes les données locales ont été effacées.")
                    }
                }) { Text("Effacer") }
            },
            dismissButton = { TextButton(onClick = { confirmWipe = false }) { Text("Annuler") } },
        )
    }
}
