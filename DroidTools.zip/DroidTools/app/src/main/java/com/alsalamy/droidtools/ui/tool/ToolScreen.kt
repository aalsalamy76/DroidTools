package com.alsalamy.droidtools.ui.tool

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.consumeWindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Construction
import androidx.compose.material.icons.rounded.PrivacyTip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.alsalamy.droidtools.core.LocalAppContainer
import com.alsalamy.droidtools.data.AppSettings
import com.alsalamy.droidtools.domain.SensitiveResource
import com.alsalamy.droidtools.domain.ToolCatalog
import com.alsalamy.droidtools.domain.ToolDefinition
import com.alsalamy.droidtools.forms.NoticeLevel
import com.alsalamy.droidtools.forms.ToolForms
import com.alsalamy.droidtools.ui.components.BackButton
import com.alsalamy.droidtools.ui.components.CenteredContent
import com.alsalamy.droidtools.ui.components.EmptyState
import com.alsalamy.droidtools.ui.components.FavoriteButton
import com.alsalamy.droidtools.ui.components.InfoCard
import com.alsalamy.droidtools.ui.components.NoticeCard
import com.alsalamy.droidtools.ui.components.withInner
import com.alsalamy.droidtools.ui.custom.CustomToolContent
import com.alsalamy.droidtools.ui.form.FormToolContent

/**
 * Écran d'un outil, choisi à partir de son identifiant :
 * formulaire générique ([ToolForms]), écran dédié, ou statut « NON IMPLÉMENTÉ ».
 */
@Composable
fun ToolScreen(toolId: String, settings: AppSettings, onBack: () -> Unit, onOpenPrivacy: () -> Unit) {
    val container = LocalAppContainer.current
    val tool = remember(toolId) { ToolCatalog.find(toolId) }
    val form = remember(toolId) { ToolForms.forTool(toolId) }

    LaunchedEffect(toolId) {
        // Seul l'identifiant de l'outil est mémorisé, et uniquement si l'historique est activé.
        if (tool != null && tool.isAvailable) container.settings.recordRecent(toolId)
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(tool?.name ?: "Outil introuvable", maxLines = 1, overflow = TextOverflow.Ellipsis) },
                navigationIcon = { BackButton(onBack) },
                actions = {
                    if (tool != null) {
                        FavoriteButton(toolId in settings.favorites, tool.name) {
                            container.launch { container.settings.toggleFavorite(toolId) }
                        }
                        IconButton(onClick = onOpenPrivacy) {
                            Icon(Icons.Rounded.PrivacyTip, contentDescription = "Fiche de confidentialité de ${tool.name}")
                        }
                    }
                },
            )
        },
    ) { padding ->
        when {
            tool == null -> EmptyState(Icons.Rounded.Construction, "Outil introuvable", "Cet outil n'existe pas dans cette version.", Modifier.padding(padding))
            !tool.isAvailable -> NotImplementedContent(tool, padding)
            toolId in ToolForms.customScreens -> CustomToolContent(tool, padding)
            form != null -> FormToolContent(tool, form, padding)
            else -> NotImplementedContent(tool, padding)
        }
    }
}

/** Écran honnête pour un outil prévu mais absent : aucune fonction simulée. */
@Composable
fun NotImplementedContent(tool: ToolDefinition, padding: PaddingValues) {
    CenteredContent {
        Column(
            Modifier.fillMaxSize().consumeWindowInsets(padding).verticalScroll(rememberScrollState()).padding(padding.withInner()),
            verticalArrangement = Arrangement.spacedBy(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Icon(Icons.Rounded.Construction, contentDescription = null, modifier = Modifier.size(56.dp).padding(top = 16.dp), tint = MaterialTheme.colorScheme.primary)
            Text("NON IMPLÉMENTÉ", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            Text(
                "« ${tool.name} » est prévu dans DroidTools mais n'est pas encore disponible dans cette version. " +
                    "Aucune fonction n'est simulée : cet écran ne fait rien et n'accède à aucune ressource.",
                style = MaterialTheme.typography.bodyLarge,
            )
            InfoCard {
                Text("Fonction prévue", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
                Text(tool.description, style = MaterialTheme.typography.bodyMedium)
                if (tool.plannedResources.isNotEmpty()) {
                    Text(
                        "Ressources sensibles probablement nécessaires : " + tool.plannedResources.joinToString(", ") { it.label.lowercase() } + ".",
                        style = MaterialTheme.typography.bodyMedium,
                    )
                }
            }
            if (SensitiveResource.NETWORK in tool.plannedResources) {
                NoticeCard("Cet outil nécessitera le réseau. Il sera réservé au diagnostic de réseaux et d'appareils que vous êtes autorisé à analyser.", NoticeLevel.INFO)
            }
        }
    }
}

@Composable
fun ToolPrivacyScreen(toolId: String, onBack: () -> Unit) {
    val tool = remember(toolId) { ToolCatalog.find(toolId) }
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Confidentialité", maxLines = 1) },
                navigationIcon = { BackButton(onBack) },
            )
        },
    ) { padding ->
        CenteredContent {
            Column(
                Modifier.fillMaxSize().consumeWindowInsets(padding).verticalScroll(rememberScrollState()).padding(padding.withInner()),
                verticalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                if (tool == null) {
                    Text("Outil introuvable.")
                } else {
                    Text(tool.name, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.SemiBold)
                    Text("Statut : ${tool.status.displayName}", style = MaterialTheme.typography.bodyMedium)
                    PrivacySheetView(tool)
                }
            }
        }
    }
}

/** Fiche de confidentialité. Elle reprend mot pour mot la fiche du catalogue, maintenue avec le code. */
@Composable
fun PrivacySheetView(tool: ToolDefinition) {
    val sheet = tool.privacy
    if (sheet == null) {
        NoticeCard(
            "Outil non implémenté : aucune fiche n'est publiée tant que le code n'existe pas, " +
                "pour ne rien affirmer qui ne soit vérifié. L'écran actuel n'utilise aucune ressource.",
            NoticeLevel.INFO,
        )
        return
    }
    InfoCard {
        SheetLine("Traitement", sheet.processing.label)
        SheetLine("Internet", if (sheet.internetRequired) "REQUIS" else "NON REQUIS — aucune connexion réseau")
        SheetLine("Permissions Android", if (sheet.permissions.isEmpty()) "Aucune" else sheet.permissions.joinToString(", ") { it.label })
        SheetLine(
            "Ressources sensibles",
            if (sheet.resources.isEmpty()) "Aucune" else sheet.resources.joinToString(", ") { it.label },
        )
        SheetLine("Utilisation des ressources", sheet.resourceUsage)
    }
    InfoCard {
        SheetLine("Données manipulées", sheet.dataHandled)
        SheetLine("Conservation", sheet.storage)
        SheetLine("Destination des données", sheet.destination)
        SheetLine("Dépendances externes", sheet.externalDependencies)
    }
    if (sheet.notes.isNotEmpty()) {
        InfoCard {
            Text("À savoir", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
            sheet.notes.forEach { Text("• $it", style = MaterialTheme.typography.bodyMedium) }
        }
    }
    if (tool.limitations.isNotEmpty()) {
        InfoCard {
            Text("Limites connues", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
            tool.limitations.forEach { Text("• $it", style = MaterialTheme.typography.bodyMedium) }
        }
    }
}

@Composable
private fun SheetLine(label: String, value: String) {
    Column(Modifier.fillMaxWidth()) {
        Text(label, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(value, style = MaterialTheme.typography.bodyMedium)
    }
}
