package com.alsalamy.droidtools.ui.settings

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.consumeWindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.semantics.heading
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.alsalamy.droidtools.ui.components.BackButton
import com.alsalamy.droidtools.ui.components.CenteredContent
import com.alsalamy.droidtools.ui.components.withInner

/**
 * Politique de confidentialité intégrée : même fichier que PRIVACY.md à la racine du dépôt
 * (l'intégration continue vérifie que les deux copies sont identiques).
 */
@Composable
fun PrivacyPolicyScreen(onBack: () -> Unit) {
    val context = LocalContext.current
    var lines by remember { mutableStateOf<List<String>?>(null) }
    LaunchedEffect(Unit) {
        lines = (loadAsset(context, "privacy_policy.md") ?: "Politique de confidentialité introuvable.").lines()
    }
    Scaffold(topBar = { TopAppBar(title = { Text("Politique de confidentialité") }, navigationIcon = { BackButton(onBack) }) }) { padding ->
        CenteredContent {
            LazyColumn(
                modifier = Modifier.fillMaxSize().consumeWindowInsets(padding),
                contentPadding = padding.withInner(),
                verticalArrangement = Arrangement.spacedBy(4.dp),
            ) {
                itemsIndexed(lines.orEmpty()) { _, raw -> MarkdownLine(raw) }
            }
        }
    }
}

private val tableSeparator = Regex("^\\|?[\\s:|-]+\\|?$")

/** Rendu minimal du Markdown utilisé par PRIVACY.md : titres, puces, paragraphes. */
@Composable
private fun MarkdownLine(raw: String) {
    val line = raw.replace("**", "").replace("`", "")
    when {
        line.isBlank() -> Spacer(Modifier.height(4.dp))
        tableSeparator.matches(line) -> Unit
        line.startsWith("# ") -> Text(line.removePrefix("# "), style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold, modifier = Modifier.semantics { heading() })
        line.startsWith("## ") -> Text(line.removePrefix("## "), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.primary, modifier = Modifier.padding(top = 12.dp).semantics { heading() })
        line.startsWith("### ") -> Text(line.removePrefix("### "), style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(top = 8.dp).semantics { heading() })
        line.trimStart().startsWith("- ") -> Text("•  " + line.trimStart().removePrefix("- "), style = MaterialTheme.typography.bodyMedium, modifier = Modifier.padding(start = 8.dp))
        line.startsWith("|") -> Text(line.trim('|').replace("|", " · ").trim(), style = MaterialTheme.typography.bodySmall)
        else -> Text(line, style = MaterialTheme.typography.bodyMedium)
    }
}
