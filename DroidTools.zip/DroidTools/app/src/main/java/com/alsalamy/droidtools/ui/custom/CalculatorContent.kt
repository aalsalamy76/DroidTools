package com.alsalamy.droidtools.ui.custom

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.consumeWindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.Backspace
import androidx.compose.material.icons.rounded.ContentCopy
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.semantics.LiveRegionMode
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.liveRegion
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.alsalamy.droidtools.security.rememberCopyAction
import com.alsalamy.droidtools.tools.calc.AngleMode
import com.alsalamy.droidtools.domain.ToolCategory
import com.alsalamy.droidtools.ui.theme.Bricolage
import com.alsalamy.droidtools.ui.theme.colors
import com.alsalamy.droidtools.tools.calc.CalcKey
import com.alsalamy.droidtools.tools.calc.Calculator
import com.alsalamy.droidtools.tools.calc.CalculatorState
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update

class CalculatorViewModel : ViewModel() {
    private val _state = MutableStateFlow(CalculatorState())
    val state: StateFlow<CalculatorState> = _state.asStateFlow()

    /** La logique du clavier est pure et rapide (expression limitée à 1000 caractères). */
    fun press(key: CalcKey) = _state.update { Calculator.press(it, key) }
}

@Composable
fun CalculatorContent(scientific: Boolean, padding: PaddingValues) {
    val viewModel: CalculatorViewModel = viewModel(key = if (scientific) "calc-sci" else "calc")
    val state by viewModel.state.collectAsStateWithLifecycle()
    val rows = (if (scientific) Calculator.scientificKeys else emptyList()) + Calculator.basicKeys

    BoxWithConstraints(Modifier.fillMaxSize().consumeWindowInsets(padding).padding(padding).padding(12.dp)) {
        if (maxWidth > maxHeight) {
            // Paysage : affichage à gauche, clavier à droite.
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Column(Modifier.weight(1f).fillMaxHeight()) { CalculatorDisplay(state, scientific, viewModel::press, Modifier.weight(1f)) }
                Column(Modifier.weight(1.2f).fillMaxHeight()) { Keypad(rows, viewModel::press) }
            }
        } else {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                CalculatorDisplay(state, scientific, viewModel::press, Modifier.weight(if (scientific) 0.28f else 0.36f))
                Column(Modifier.weight(if (scientific) 0.72f else 0.64f)) { Keypad(rows, viewModel::press) }
            }
        }
    }
}

@Composable
private fun CalculatorDisplay(state: CalculatorState, scientific: Boolean, press: (CalcKey) -> Unit, modifier: Modifier) {
    val copy = rememberCopyAction()
    val expression = state.expression.ifEmpty { "0" }
    val fontSize = when {
        expression.length < 10 -> 44.sp
        expression.length < 18 -> 34.sp
        else -> 26.sp
    }
    Surface(shape = MaterialTheme.shapes.large, color = MaterialTheme.colorScheme.surfaceContainer, modifier = modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), horizontalAlignment = Alignment.End, verticalArrangement = Arrangement.Bottom) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                if (scientific) {
                    Text(
                        if (state.angleMode == AngleMode.DEGREES) "DEG" else "RAD",
                        style = MaterialTheme.typography.labelLarge,
                        color = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.semantics {
                            contentDescription = if (state.angleMode == AngleMode.DEGREES) "Angles en degrés" else "Angles en radians"
                        },
                    )
                }
                Spacer(Modifier.weight(1f))
                IconButton(onClick = { copy("Résultat", state.preview ?: state.expression, false) }, enabled = state.expression.isNotEmpty()) {
                    Icon(Icons.Rounded.ContentCopy, contentDescription = "Copier le résultat")
                }
                IconButton(onClick = { press(CalcKey.Backspace) }) {
                    Icon(Icons.AutoMirrored.Rounded.Backspace, contentDescription = CalcKey.Backspace.spoken)
                }
            }
            Spacer(Modifier.weight(1f))
            state.lastExpression?.let {
                Text("$it =", style = MaterialTheme.typography.bodyLarge, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 2, textAlign = TextAlign.End)
            }
            Text(
                expression,
                fontSize = fontSize,
                lineHeight = fontSize * 1.1f,
                fontFamily = Bricolage,
                fontWeight = FontWeight.Bold,
                textAlign = TextAlign.End,
                maxLines = 3,
                modifier = Modifier.fillMaxWidth().semantics { contentDescription = "Expression : $expression" },
            )
            val secondary = state.error ?: state.preview?.let { "= $it" }
            if (secondary != null) {
                Text(
                    secondary,
                    style = MaterialTheme.typography.titleLarge,
                    color = if (state.error != null) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurfaceVariant,
                    textAlign = TextAlign.End,
                    modifier = Modifier.fillMaxWidth().semantics { liveRegion = LiveRegionMode.Polite },
                )
            }
        }
    }
}

@Composable
private fun Keypad(rows: List<List<CalcKey>>, press: (CalcKey) -> Unit) {
    val haptic = LocalHapticFeedback.current
    Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        rows.forEach { row ->
            Row(Modifier.weight(1f).fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                row.forEach { key ->
                    CalcButton(
                        key = key,
                        modifier = Modifier.weight(1f).fillMaxHeight().heightIn(min = 40.dp),
                        onClick = {
                            haptic.performHapticFeedback(HapticFeedbackType.KeyboardTap)
                            press(key)
                        },
                    )
                }
            }
        }
    }
}

@Composable
private fun CalcButton(key: CalcKey, modifier: Modifier, onClick: () -> Unit) {
    val colors = MaterialTheme.colorScheme
    val family = ToolCategory.CALCULATIONS.colors
    val isDigit = key is CalcKey.Insert && (key.text.first().isDigit() || key.text == ",")
    val isOperator = key is CalcKey.Insert && key.text in setOf("+", "−", "×", "÷", "%", "(", ")")
    val (container: Color, content: Color) = when {
        key == CalcKey.Equals -> family.tile to family.onTile
        key == CalcKey.Clear -> colors.errorContainer to colors.onErrorContainer
        isOperator -> family.badge to family.onBadge
        isDigit -> colors.surfaceContainerHighest to colors.onSurface
        else -> colors.surfaceContainerHigh to colors.onSurfaceVariant
    }
    Surface(
        onClick = onClick,
        shape = MaterialTheme.shapes.large,
        color = container,
        contentColor = content,
        modifier = modifier.semantics { contentDescription = key.spoken },
    ) {
        Column(verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
            Text(
                key.label,
                style = if (isDigit || key == CalcKey.Equals || isOperator) MaterialTheme.typography.headlineSmall else MaterialTheme.typography.titleMedium,
                maxLines = 1,
            )
        }
    }
}
