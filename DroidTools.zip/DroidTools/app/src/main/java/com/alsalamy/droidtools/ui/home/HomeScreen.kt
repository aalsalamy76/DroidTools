package com.alsalamy.droidtools.ui.home

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyGridScope
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.grid.itemsIndexed
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.SearchOff
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.semantics.heading
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import com.alsalamy.droidtools.core.LocalAppContainer
import com.alsalamy.droidtools.data.AppSettings
import com.alsalamy.droidtools.domain.ToolCatalog
import com.alsalamy.droidtools.domain.ToolCategory
import com.alsalamy.droidtools.domain.ToolSearch
import com.alsalamy.droidtools.ui.components.DroidToolsLogo
import com.alsalamy.droidtools.ui.components.EmptyState
import com.alsalamy.droidtools.ui.components.SectionHeader
import com.alsalamy.droidtools.ui.components.ToolRow
import com.alsalamy.droidtools.ui.components.ToolTile
import com.alsalamy.droidtools.ui.components.vector
import com.alsalamy.droidtools.ui.theme.colors

/** Outils mis en avant tant que l'utilisateur n'a pas encore de favoris. */
private val suggestionIds = listOf(
    "calculator", "password_generator", "convert_length", "vat",
    "json_formatter", "ipv4_calculator", "text_counter", "date_difference",
)

@Composable
fun HomeScreen(
    settings: AppSettings,
    onOpenTool: (String) -> Unit,
    onOpenCategory: (ToolCategory) -> Unit,
    onOpenAllTools: () -> Unit,
) {
    val container = LocalAppContainer.current
    var query by rememberSaveable { mutableStateOf("") }
    val results = remember(query) { if (query.isBlank()) emptyList() else ToolSearch.search(query) }
    val favorites = settings.favorites.mapNotNull(ToolCatalog::find)
    val recents = if (settings.historyEnabled) settings.recents.mapNotNull(ToolCatalog::find) else emptyList()
    val suggestions = remember(settings.favorites) {
        suggestionIds.filter { it !in settings.favorites }.mapNotNull(ToolCatalog::find).take(4)
    }
    val categories = ToolCatalog.categories
    val focus = LocalFocusManager.current
    val toggleFavorite: (String) -> Unit = { id -> container.launch { container.settings.toggleFavorite(id) } }

    LazyVerticalGrid(
        columns = GridCells.Adaptive(minSize = 160.dp),
        modifier = Modifier.fillMaxSize().windowInsetsPadding(WindowInsets.safeDrawing),
        contentPadding = PaddingValues(start = 20.dp, end = 20.dp, top = 20.dp, bottom = 24.dp),
        horizontalArrangement = Arrangement.spacedBy(12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        fullWidth("header") {
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(top = 4.dp, bottom = 8.dp)) {
                DroidToolsLogo(size = 54.dp)
                Spacer(Modifier.width(14.dp))
                Column {
                    Text(
                        "DroidTools",
                        style = MaterialTheme.typography.displaySmall,
                        modifier = Modifier.semantics { heading() },
                    )
                    Text(
                        "Tous vos outils. Une seule application.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }
        }
        fullWidth("search") {
            Column {
                TextField(
                    value = query,
                    onValueChange = { query = it.take(100) },
                    modifier = Modifier.fillMaxWidth(),
                    placeholder = { Text("Rechercher un outil") },
                    leadingIcon = { Icon(Icons.Rounded.Search, contentDescription = null) },
                    trailingIcon = if (query.isNotEmpty()) {
                        { IconButton(onClick = { query = "" }) { Icon(Icons.Rounded.Close, contentDescription = "Effacer la recherche") } }
                    } else {
                        null
                    },
                    singleLine = true,
                    shape = MaterialTheme.shapes.extraLarge,
                    colors = TextFieldDefaults.colors(
                        focusedContainerColor = MaterialTheme.colorScheme.surfaceContainerHigh,
                        unfocusedContainerColor = MaterialTheme.colorScheme.surfaceContainerHigh,
                        focusedIndicatorColor = Color.Transparent,
                        unfocusedIndicatorColor = Color.Transparent,
                    ),
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                    keyboardActions = KeyboardActions(onSearch = { focus.clearFocus() }),
                )
                Text(
                    "${ToolCatalog.all.size} outils, tous utilisables hors ligne",
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(start = 20.dp, top = 8.dp),
                )
            }
        }

        if (query.isNotBlank()) {
            if (results.isEmpty()) {
                fullWidth("no-result") {
                    EmptyState(Icons.Rounded.SearchOff, "Aucun outil trouvé", "Essayez un autre mot : « ip », « json », « mot de passe », « tva »…")
                }
            } else {
                fullWidth("results-title") { SectionHeader(if (results.size > 1) "${results.size} résultats" else "1 résultat") }
                results.forEach { tool ->
                    fullWidth("result-${tool.id}") {
                        ToolRow(
                            tool = tool,
                            isFavorite = tool.id in settings.favorites,
                            onClick = { onOpenTool(tool.id) },
                            onToggleFavorite = { toggleFavorite(tool.id) },
                        )
                    }
                }
            }
            return@LazyVerticalGrid
        }

        if (favorites.isNotEmpty()) {
            fullWidth("favorites-title") { SectionHeader("Favoris") }
            fullWidth("favorites-row") { ToolStrip(favorites, onOpenTool) }
        }

        if (recents.isNotEmpty()) {
            fullWidth("recents-title") { SectionHeader("Récemment utilisés") }
            fullWidth("recents-row") { ToolStrip(recents, onOpenTool) }
        }

        fullWidth("categories-title") {
            SectionHeader("Catégories") {
                TextButton(onClick = onOpenAllTools) { Text("Tous les outils") }
            }
        }
        itemsIndexed(
            categories,
            key = { _, category -> "category-${category.name}" },
            // La dernière tuile d'une ligne incomplète occupe la place restante.
            span = { index, _ -> GridItemSpan(if (index == categories.lastIndex) maxCurrentLineSpan else 1) },
        ) { _, category ->
            CategoryTile(category, ToolCatalog.byCategory(category).size, onClick = { onOpenCategory(category) })
        }

        if (favorites.isEmpty() && suggestions.isNotEmpty()) {
            fullWidth("suggestions-title") { SectionHeader("Pour commencer") }
            fullWidth("suggestions-hint") {
                Text(
                    "Touchez l'étoile d'un outil pour l'épingler en haut de cet écran.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
            items(suggestions, key = { "suggestion-${it.id}" }) { tool ->
                ToolTile(tool, onClick = { onOpenTool(tool.id) })
            }
        }
        fullWidth("bottom-space") { Spacer(Modifier.height(8.dp)) }
    }
}

private fun LazyGridScope.fullWidth(key: String, content: @Composable () -> Unit) {
    item(key = key, span = { GridItemSpan(maxLineSpan) }) { content() }
}

@Composable
private fun ToolStrip(tools: List<com.alsalamy.droidtools.domain.ToolDefinition>, onOpenTool: (String) -> Unit) {
    LazyRow(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        items(tools, key = { it.id }) { tool ->
            ToolTile(tool, onClick = { onOpenTool(tool.id) }, modifier = Modifier.width(150.dp))
        }
    }
}

/** Tuile pleine d'une famille d'outils, dans sa couleur (élément signature de l'interface). */
@Composable
private fun CategoryTile(category: ToolCategory, count: Int, onClick: () -> Unit) {
    val colors = category.colors
    Surface(
        onClick = onClick,
        shape = MaterialTheme.shapes.large,
        color = colors.tile,
        contentColor = colors.onTile,
        modifier = Modifier.fillMaxWidth().height(128.dp),
    ) {
        Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.SpaceBetween) {
            Box(
                Modifier.size(44.dp).clip(CircleShape).background(colors.onTile.copy(alpha = 0.16f)),
                contentAlignment = Alignment.Center,
            ) {
                Icon(category.icon.vector(), contentDescription = null, modifier = Modifier.size(24.dp))
            }
            Column {
                Text(category.label, style = MaterialTheme.typography.titleLarge, maxLines = 1)
                Text(if (count > 1) "$count outils" else "1 outil", style = MaterialTheme.typography.labelMedium)
            }
        }
    }
}
