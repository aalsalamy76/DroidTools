package com.alsalamy.droidtools.data

import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.emptyPreferences
import androidx.datastore.preferences.core.stringPreferencesKey
import com.alsalamy.droidtools.core.Outcome
import com.alsalamy.droidtools.tools.daily.Checklist
import com.alsalamy.droidtools.tools.daily.ChecklistItem
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map
import java.io.IOException

/** Checklist stockée localement (non chiffrée) dans l'espace privé de l'application. */
class ChecklistRepository(private val store: DataStore<Preferences>) {

    private val key = stringPreferencesKey("items")

    val items: Flow<List<ChecklistItem>> = store.data
        .catch { e -> if (e is IOException) emit(emptyPreferences()) else throw e }
        .map { Checklist.decode(it[key]) }

    /** Ajoute un élément ; retourne un message d'erreur lisible, ou null en cas de succès. */
    suspend fun add(text: String): String? {
        var error: String? = null
        store.edit { p ->
            when (val r = Checklist.add(Checklist.decode(p[key]), text)) {
                is Outcome.Ok -> p[key] = Checklist.encode(r.value)
                is Outcome.Err -> error = r.message
            }
        }
        return error
    }

    suspend fun update(transform: (List<ChecklistItem>) -> List<ChecklistItem>) {
        store.edit { p -> p[key] = Checklist.encode(transform(Checklist.decode(p[key]))) }
    }

    suspend fun clear() {
        store.edit { it.remove(key) }
    }
}
