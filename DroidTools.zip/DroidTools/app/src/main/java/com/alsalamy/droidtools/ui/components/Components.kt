package com.alsalamy.droidtools.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.calculateEndPadding
import androidx.compose.foundation.layout.calculateStartPadding
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.Error
import androidx.compose.material.icons.rounded.Info
import androidx.compose.material.icons.rounded.Star
import androidx.compose.material.icons.rounded.StarBorder
import androidx.compose.material.icons.rounded.Warning
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.IconToggleButton
import androidx.compose.material3.ListItem
import androidx.compose.material3.ListItemDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.Stable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.semantics.heading
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.alsalamy.droidtools.domain.ToolCategory
import com.alsalamy.droidtools.domain.ToolDefinition
import com.alsalamy.droidtools.domain.ToolStatus
import com.alsalamy.droidtools.forms.NoticeLevel
import com.alsalamy.droidtools.ui.theme.LocalExtraColors
import com.alsalamy.droidtools.ui.theme.colors
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.launch

// ------------------------------------------------------------------ Messages éphémères

/** Affiche des messages courts (Snackbar) depuis n'importe quel écran. */
@Stable
class Messenger(private val host: SnackbarHostState, private val scope: CoroutineScope) {
    fun show(message: String) {
        scope.launch {
            host.currentSnackbarData?.dismiss()
            host.showSnackbar(message = message, withDismissAction = true)
        }
    }
}

val LocalMessenger = staticCompositionLocalOf<Messenger> { error("Messenger non fourni") }

// ------------------------------------------------------------------ Mise en page

/** Largeur maximale du contenu sur tablette, pour garder des lignes lisibles. */
val ContentMaxWidth: Dp = 720.dp

/** Ajoute des marges intérieures aux marges imposées par le Scaffold. */
@Composable
fun PaddingValues.withInner(horizontal: Dp = 16.dp, top: Dp = 8.dp, bottom: Dp = 24.dp): PaddingValues {
    val direction = LocalLayoutDirection.current
    return PaddingValues(
        start = calculateStartPadding(direction) + horizontal,
        top = calculateTopPadding() + top,
        end = calculateEndPadding(direction) + horizontal,
        bottom = calculateBottomPadding() + bottom,
    )
}

/** Centre une colonne de contenu avec une largeur maximale. */
@Composable
fun CenteredContent(modifier: Modifier = Modifier, content: @Composable () -> Unit) {
    Box(modifier.fillMaxSize(), contentAlignment = Alignment.TopCenter) {
        Box(Modifier.widthIn(max = ContentMaxWidth).fillMaxSize()) { content() }
    }
}

@Composable
fun BackButton(onBack: () -> Unit) {
    IconButton(onClick = onBack) {
        Icon(Icons.AutoMirrored.Rounded.ArrowBack, contentDescription = "Retour")
    }
}

@Composable
fun SectionHeader(title: String, modifier: Modifier = Modifier, trailing: (@Composable () -> Unit)? = null) {
    Row(
        modifier.fillMaxWidth().padding(top = 16.dp, bottom = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(
            title,
            style = MaterialTheme.typography.titleLarge,
            color = MaterialTheme.colorScheme.onSurface,
            modifier = Modifier.weight(1f).semantics { heading() },
        )
        trailing?.invoke()
    }
}

@Composable
fun EmptyState(icon: ImageVector, title: String, text: String, modifier: Modifier = Modifier) {
    Column(
        modifier.fillMaxWidth().padding(vertical = 32.dp, horizontal = 24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        Icon(icon, contentDescription = null, modifier = Modifier.size(48.dp), tint = MaterialTheme.colorScheme.primary)
        Text(title, style = MaterialTheme.typography.titleLarge)
        Text(text, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

/** Bloc de contenu sur une surface arrondie. */
@Composable
fun InfoCard(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    Card(
        modifier = modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLow),
        shape = MaterialTheme.shapes.large,
    ) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp), content = content)
    }
}

// ------------------------------------------------------------------ Messages (jamais la couleur seule)

private data class NoticeStyle(val icon: ImageVector, val container: Color, val content: Color, val spoken: String)

@Composable
fun NoticeCard(text: String, level: NoticeLevel, modifier: Modifier = Modifier) {
    val colors = MaterialTheme.colorScheme
    val extra = LocalExtraColors.current
    val style = when (level) {
        NoticeLevel.INFO -> NoticeStyle(Icons.Rounded.Info, colors.secondaryContainer, colors.onSecondaryContainer, "Information")
        NoticeLevel.SUCCESS -> NoticeStyle(Icons.Rounded.CheckCircle, colors.primaryContainer, colors.onPrimaryContainer, "Succès")
        NoticeLevel.WARNING -> NoticeStyle(Icons.Rounded.Warning, extra.warningContainer, extra.onWarningContainer, "Avertissement")
        NoticeLevel.ERROR -> NoticeStyle(Icons.Rounded.Error, colors.errorContainer, colors.onErrorContainer, "Erreur")
    }
    Surface(color = style.container, contentColor = style.content, shape = MaterialTheme.shapes.medium, modifier = modifier.fillMaxWidth()) {
        Row(Modifier.padding(horizontal = 16.dp, vertical = 12.dp), verticalAlignment = Alignment.Top) {
            Icon(style.icon, contentDescription = style.spoken, modifier = Modifier.size(20.dp))
            Spacer(Modifier.width(12.dp))
            Text(text, style = MaterialTheme.typography.bodyMedium)
        }
    }
}

// ------------------------------------------------------------------ Outils

@Composable
fun FavoriteButton(isFavorite: Boolean, toolName: String, onToggle: () -> Unit) {
    val haptic = LocalHapticFeedback.current
    IconToggleButton(
        checked = isFavorite,
        onCheckedChange = {
            haptic.performHapticFeedback(if (it) HapticFeedbackType.ToggleOn else HapticFeedbackType.ToggleOff)
            onToggle()
        },
    ) {
        Icon(
            if (isFavorite) Icons.Rounded.Star else Icons.Rounded.StarBorder,
            contentDescription = if (isFavorite) "Retirer $toolName des favoris" else "Ajouter $toolName aux favoris",
            tint = if (isFavorite) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
        )
    }
}

/** Pastille d'icône, dans la couleur de la famille de l'outil. */
@Composable
fun ToolIconBadge(tool: ToolDefinition, size: Dp = 44.dp) {
    val colors = tool.category.colors
    Surface(
        shape = RoundedCornerShape(size * 0.32f),
        color = colors.badge,
        contentColor = colors.onBadge,
        modifier = Modifier.size(size),
    ) {
        Box(contentAlignment = Alignment.Center) {
            Icon(tool.icon.vector(), contentDescription = null, modifier = Modifier.size(size * 0.52f))
        }
    }
}

/** Libellé textuel (le statut n'est jamais transmis par la seule couleur). */
@Composable
fun LabelTag(text: String, container: Color, content: Color, icon: ImageVector? = null) {
    Surface(color = container, contentColor = content, shape = MaterialTheme.shapes.extraSmall) {
        Row(Modifier.padding(horizontal = 8.dp, vertical = 2.dp), verticalAlignment = Alignment.CenterVertically) {
            if (icon != null) {
                Icon(icon, contentDescription = null, modifier = Modifier.size(12.dp))
                Spacer(Modifier.width(4.dp))
            }
            Text(text, style = MaterialTheme.typography.labelSmall)
        }
    }
}

/** Signale un outil PARTIEL (utilisable, avec des limites indiquées dans sa fiche). */
@Composable
fun ToolTags(tool: ToolDefinition) {
    if (tool.status != ToolStatus.PARTIAL) return
    val extra = LocalExtraColors.current
    Row(Modifier.padding(top = 4.dp)) {
        LabelTag(tool.status.displayName, extra.warningContainer, extra.onWarningContainer)
    }
}

@Composable
fun ToolRow(
    tool: ToolDefinition,
    isFavorite: Boolean,
    onClick: () -> Unit,
    onToggleFavorite: () -> Unit,
    modifier: Modifier = Modifier,
) {
    ListItem(
        headlineContent = { Text(tool.name, style = MaterialTheme.typography.titleMedium, maxLines = 2, overflow = TextOverflow.Ellipsis) },
        supportingContent = {
            Column {
                Text(tool.description, maxLines = 2, overflow = TextOverflow.Ellipsis)
                ToolTags(tool)
            }
        },
        leadingContent = { ToolIconBadge(tool) },
        trailingContent = { FavoriteButton(isFavorite, tool.name, onToggleFavorite) },
        colors = ListItemDefaults.colors(containerColor = Color.Transparent),
        modifier = modifier
            .clip(MaterialTheme.shapes.medium)
            .clickable(onClickLabel = "Ouvrir ${tool.name}", onClick = onClick)
            .heightIn(min = 64.dp),
    )
}

/** Carte compacte d'un outil (accueil : favoris, récents, suggestions). */
@Composable
fun ToolTile(tool: ToolDefinition, onClick: () -> Unit, modifier: Modifier = Modifier) {
    Card(
        onClick = onClick,
        modifier = modifier.height(120.dp),
        shape = MaterialTheme.shapes.large,
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLow),
    ) {
        Column(Modifier.fillMaxSize().padding(14.dp), verticalArrangement = Arrangement.SpaceBetween) {
            ToolIconBadge(tool, size = 40.dp)
            Text(tool.name, style = MaterialTheme.typography.titleSmall, maxLines = 2, overflow = TextOverflow.Ellipsis)
        }
    }
}

// ------------------------------------------------------------------ Identité

/** Encre de la marque : fond du logo et de l'icône de l'application. */
val BrandInk = Color(0xFF17104F)

/**
 * Logo DroidTools : quatre pièces aux couleurs de quatre familles d'outils (calculs, conversions,
 * texte et dev, quotidien) sur l'encre de la marque. Dessin original.
 */
@Composable
fun DroidToolsLogo(size: Dp, modifier: Modifier = Modifier) {
    val pieces = listOf(
        ToolCategory.CALCULATIONS.colors.tile,
        ToolCategory.CONVERSIONS.colors.tile,
        ToolCategory.TEXT_DEV.colors.tile,
        ToolCategory.DAILY.colors.tile,
    )
    Canvas(modifier.size(size)) {
        val unit = this.size.minDimension / 108f
        drawRoundRect(BrandInk, cornerRadius = CornerRadius(30 * unit))
        val tileSize = Size(18 * unit, 18 * unit)
        val radius = CornerRadius(5 * unit)
        drawRoundRect(pieces[0], topLeft = Offset(33 * unit, 33 * unit), size = tileSize, cornerRadius = radius)
        drawRoundRect(pieces[1], topLeft = Offset(57 * unit, 33 * unit), size = tileSize, cornerRadius = radius)
        drawRoundRect(pieces[2], topLeft = Offset(33 * unit, 57 * unit), size = tileSize, cornerRadius = radius)
        drawCircle(pieces[3], radius = 9 * unit, center = Offset(66 * unit, 66 * unit))
    }
}
