package com.alsalamy.droidtools.ui.custom

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.consumeWindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.selection.toggleable
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Checklist
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.FilledIconButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import com.alsalamy.droidtools.core.LocalAppContainer
import com.alsalamy.droidtools.data.ChecklistRepository
import com.alsalamy.droidtools.forms.NoticeLevel
import com.alsalamy.droidtools.domain.ToolCategory
import com.alsalamy.droidtools.ui.theme.colors
import androidx.compose.material3.IconButtonDefaults
import com.alsalamy.droidtools.tools.daily.Checklist
import com.alsalamy.droidtools.tools.daily.ChecklistItem
import com.alsalamy.droidtools.ui.components.CenteredContent
import com.alsalamy.droidtools.ui.components.EmptyState
import com.alsalamy.droidtools.ui.components.NoticeCard
import com.alsalamy.droidtools.ui.components.withInner
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class ChecklistViewModel(private val repository: ChecklistRepository) : ViewModel() {

    /** null pendant le chargement initial (évite d'afficher « liste vide » à tort). */
    val items: StateFlow<List<ChecklistItem>?> = repository.items
        .map<List<ChecklistItem>, List<ChecklistItem>?> { it }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), null)

    private val _error = MutableStateFlow<String?>(null)
    val error: StateFlow<String?> = _error.asStateFlow()

    fun add(text: String, onAdded: () -> Unit) {
        viewModelScope.launch {
            val message = repository.add(text)
            _error.value = message
            if (message == null) onAdded()
        }
    }

    fun toggle(id: Long) = viewModelScope.launch { repository.update { Checklist.toggle(it, id) } }
    fun remove(id: Long) = viewModelScope.launch { repository.update { Checklist.remove(it, id) } }
    fun clearDone() = viewModelScope.launch { repository.update { Checklist.clearDone(it) } }
}

@Composable
fun ChecklistContent(padding: PaddingValues) {
    val container = LocalAppContainer.current
    val viewModel: ChecklistViewModel = viewModel { ChecklistViewModel(container.checklist) }
    val items by viewModel.items.collectAsStateWithLifecycle()
    val error by viewModel.error.collectAsStateWithLifecycle()
    var draft by rememberSaveable { mutableStateOf("") }
    val submit = { if (draft.isNotBlank()) viewModel.add(draft) { draft = "" } }

    CenteredContent {
        LazyColumn(
            modifier = Modifier.fillMaxSize().consumeWindowInsets(padding).imePadding(),
            contentPadding = padding.withInner(),
            verticalArrangement = Arrangement.spacedBy(4.dp),
        ) {
            item(key = "notice") {
                NoticeCard(
                    "Enregistrée uniquement sur cet appareil, sans chiffrement et hors sauvegardes Android. N'y notez pas d'informations secrètes.",
                    NoticeLevel.INFO,
                )
            }
            item(key = "input") {
                Row(Modifier.fillMaxWidth().padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                    OutlinedTextField(
                        value = draft,
                        onValueChange = { draft = it.take(Checklist.MAX_TEXT_LENGTH) },
                        label = { Text("Nouvel élément") },
                        singleLine = true,
                        isError = error != null,
                        supportingText = error?.let { message -> { Text(message) } },
                        keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.Sentences, imeAction = ImeAction.Done),
                        keyboardActions = KeyboardActions(onDone = { submit() }),
                        modifier = Modifier.weight(1f),
                    )
                    Spacer(Modifier.width(8.dp))
                    FilledIconButton(
                        onClick = { submit() },
                        enabled = draft.isNotBlank(),
                        colors = IconButtonDefaults.filledIconButtonColors(
                            containerColor = ToolCategory.DAILY.colors.tile,
                            contentColor = ToolCategory.DAILY.colors.onTile,
                        ),
                    ) {
                        Icon(Icons.Rounded.Add, contentDescription = "Ajouter l'élément")
                    }
                }
            }
            val list = items
            when {
                list == null -> Unit
                list.isEmpty() -> item(key = "empty") {
                    EmptyState(Icons.Rounded.Checklist, "Liste vide", "Ajoutez votre premier élément ci-dessus.")
                }
                else -> {
                    val done = list.count { it.done }
                    item(key = "summary") {
                        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                "$done sur ${list.size} terminé${if (done > 1) "s" else ""}",
                                style = MaterialTheme.typography.labelLarge,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.weight(1f),
                            )
                            if (done > 0) TextButton(onClick = { viewModel.clearDone() }) { Text("Retirer les éléments cochés") }
                        }
                    }
                    items(list, key = { it.id }) { item -> ChecklistRow(item, onToggle = { viewModel.toggle(item.id) }, onDelete = { viewModel.remove(item.id) }) }
                }
            }
        }
    }
}

@Composable
private fun ChecklistRow(item: ChecklistItem, onToggle: () -> Unit, onDelete: () -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .clip(MaterialTheme.shapes.medium)
            .toggleable(value = item.done, role = Role.Checkbox, onValueChange = { onToggle() })
            .heightIn(min = 52.dp)
            .padding(start = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Checkbox(
            checked = item.done,
            onCheckedChange = null,
            colors = CheckboxDefaults.colors(checkedColor = ToolCategory.DAILY.colors.accent),
        )
        Spacer(Modifier.width(12.dp))
        Text(
            item.text,
            style = MaterialTheme.typography.bodyLarge,
            textDecoration = if (item.done) TextDecoration.LineThrough else null,
            color = if (item.done) MaterialTheme.colorScheme.onSurfaceVariant else MaterialTheme.colorScheme.onSurface,
            modifier = Modifier.weight(1f),
        )
        IconButton(onClick = onDelete) {
            Icon(Icons.Rounded.Delete, contentDescription = "Supprimer « ${item.text} »")
        }
    }
}
