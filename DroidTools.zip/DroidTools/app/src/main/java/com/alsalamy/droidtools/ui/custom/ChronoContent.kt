package com.alsalamy.droidtools.ui.custom

import com.alsalamy.droidtools.ui.theme.CodeFont
import android.media.AudioManager
import android.media.ToneGenerator
import android.os.SystemClock
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.consumeWindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ContentCopy
import androidx.compose.material.icons.rounded.Flag
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.RestartAlt
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.ViewModel
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.repeatOnLifecycle
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import com.alsalamy.droidtools.core.Outcome
import com.alsalamy.droidtools.domain.ToolCategory
import com.alsalamy.droidtools.ui.theme.colors
import androidx.compose.material3.ButtonColors
import androidx.compose.material3.ButtonDefaults
import com.alsalamy.droidtools.forms.NoticeLevel
import com.alsalamy.droidtools.security.rememberCopyAction
import com.alsalamy.droidtools.tools.daily.CountdownTimer
import com.alsalamy.droidtools.tools.daily.Durations
import com.alsalamy.droidtools.tools.daily.Stopwatch
import com.alsalamy.droidtools.ui.components.CenteredContent
import com.alsalamy.droidtools.ui.components.NoticeCard
import com.alsalamy.droidtools.ui.components.withInner
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

/** Boutons principaux aux couleurs de la famille « Quotidien ». */
@Composable
private fun dailyButtonColors(): ButtonColors {
    val family = ToolCategory.DAILY.colors
    return ButtonDefaults.buttonColors(containerColor = family.tile, contentColor = family.onTile)
}

/** Horloge monotone : insensible aux changements d'heure ou de fuseau. */
private fun monotonicNow(): Long = SystemClock.elapsedRealtime()

// ------------------------------------------------------------------ Chronomètre

class StopwatchViewModel : ViewModel() {
    private val _state = MutableStateFlow(Stopwatch())
    val state: StateFlow<Stopwatch> = _state.asStateFlow()

    fun start() = _state.update { it.start(monotonicNow()) }
    fun pause() = _state.update { it.pause(monotonicNow()) }
    fun lap() = _state.update { it.lap(monotonicNow()) }
    fun reset() = _state.update { it.reset() }
}

@Composable
fun StopwatchContent(padding: PaddingValues) {
    val viewModel: StopwatchViewModel = viewModel()
    val stopwatch by viewModel.state.collectAsStateWithLifecycle()
    var now by remember { mutableLongStateOf(monotonicNow()) }
    val haptic = LocalHapticFeedback.current
    val copy = rememberCopyAction()

    // Rafraîchissement de l'affichage uniquement pendant la mesure et quand l'écran est visible.
    val lifecycleOwner = LocalLifecycleOwner.current
    LaunchedEffect(stopwatch.running, lifecycleOwner) {
        now = monotonicNow()
        if (stopwatch.running) {
            lifecycleOwner.repeatOnLifecycle(Lifecycle.State.STARTED) {
                while (true) {
                    now = monotonicNow()
                    delay(33)
                }
            }
        }
    }
    val elapsed = stopwatch.elapsed(now)
    val laps = stopwatch.lapDetails()
    val fastest = laps.minByOrNull { it.lapMs }?.number
    val slowest = laps.maxByOrNull { it.lapMs }?.number

    CenteredContent {
        LazyColumn(
            modifier = Modifier.fillMaxSize().consumeWindowInsets(padding),
            contentPadding = padding.withInner(),
            verticalArrangement = Arrangement.spacedBy(8.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            item(key = "time") {
                Text(
                    Durations.format(elapsed),
                    style = MaterialTheme.typography.displayLarge,
                    fontFamily = CodeFont,
                    modifier = Modifier.padding(vertical = 32.dp).semantics { contentDescription = "Temps écoulé : ${Durations.spoken(elapsed)}" },
                )
            }
            item(key = "buttons") {
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    when {
                        stopwatch.running -> {
                            OutlinedButton(onClick = { viewModel.lap(); haptic.performHapticFeedback(HapticFeedbackType.ContextClick) }, modifier = Modifier.heightIn(min = 52.dp)) {
                                Icon(Icons.Rounded.Flag, contentDescription = null)
                                Text("  Tour")
                            }
                            Button(onClick = viewModel::pause, modifier = Modifier.heightIn(min = 52.dp), colors = dailyButtonColors()) {
                                Icon(Icons.Rounded.Pause, contentDescription = null)
                                Text("  Pause")
                            }
                        }
                        elapsed > 0 -> {
                            OutlinedButton(onClick = viewModel::reset, modifier = Modifier.heightIn(min = 52.dp)) {
                                Icon(Icons.Rounded.RestartAlt, contentDescription = null)
                                Text("  Réinitialiser")
                            }
                            Button(onClick = viewModel::start, modifier = Modifier.heightIn(min = 52.dp), colors = dailyButtonColors()) {
                                Icon(Icons.Rounded.PlayArrow, contentDescription = null)
                                Text("  Reprendre")
                            }
                        }
                        else -> Button(onClick = viewModel::start, modifier = Modifier.heightIn(min = 52.dp), colors = dailyButtonColors()) {
                            Icon(Icons.Rounded.PlayArrow, contentDescription = null)
                            Text("  Démarrer")
                        }
                    }
                }
            }
            if (laps.isNotEmpty()) {
                item(key = "laps-header") {
                    Row(Modifier.fillMaxWidth().padding(top = 16.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text("Tours", style = MaterialTheme.typography.titleMedium, modifier = Modifier.weight(1f))
                        IconButton(onClick = {
                            val text = laps.reversed().joinToString("\n") { "Tour ${it.number}\t${Durations.format(it.lapMs)}\t${Durations.format(it.totalMs)}" }
                            copy("Tours", text, false)
                        }) {
                            Icon(Icons.Rounded.ContentCopy, contentDescription = "Copier les tours")
                        }
                    }
                }
                items(laps, key = { it.number }) { lap ->
                    val tag = when {
                        laps.size < 3 -> ""
                        lap.number == fastest -> " · le plus rapide"
                        lap.number == slowest -> " · le plus lent"
                        else -> ""
                    }
                    Row(Modifier.fillMaxWidth().padding(vertical = 6.dp)) {
                        Text("Tour ${lap.number}$tag", modifier = Modifier.weight(1f), fontWeight = if (tag.isNotEmpty()) FontWeight.SemiBold else null)
                        Text(Durations.format(lap.lapMs), fontFamily = CodeFont, modifier = Modifier.weight(0.8f))
                        Text(Durations.format(lap.totalMs), fontFamily = CodeFont, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
        }
    }
}

// ------------------------------------------------------------------ Minuteur

class TimerViewModel : ViewModel() {
    private val _timer = MutableStateFlow<CountdownTimer?>(null)
    val timer: StateFlow<CountdownTimer?> = _timer.asStateFlow()

    private val _finished = MutableStateFlow(false)
    val finished: StateFlow<Boolean> = _finished.asStateFlow()

    fun startNew(durationMs: Long) {
        _finished.value = false
        _timer.value = CountdownTimer(durationMs).start(monotonicNow())
    }

    fun pause() = _timer.update { it?.pause(monotonicNow()) }
    fun resume() = _timer.update { it?.start(monotonicNow()) }

    fun restart() {
        _finished.value = false
        _timer.update { it?.reset()?.start(monotonicNow()) }
    }

    fun clear() {
        _finished.value = false
        _timer.value = null
    }

    /** Appelé uniquement quand l'outil est visible : l'alerte n'est jamais émise en arrière-plan. */
    fun checkFinished(): Boolean {
        val t = _timer.value ?: return false
        if (t.running && t.isFinished(monotonicNow())) {
            _timer.value = t.pause(monotonicNow())
            _finished.value = true
            beep()
            return true
        }
        return false
    }

    /** Bip généré localement par Android (aucune permission, aucun fichier). */
    private fun beep() {
        viewModelScope.launch {
            val generator = try {
                ToneGenerator(AudioManager.STREAM_ALARM, 90)
            } catch (e: RuntimeException) {
                return@launch // Sortie audio indisponible : le message visuel suffit.
            }
            try {
                repeat(3) {
                    generator.startTone(ToneGenerator.TONE_PROP_BEEP2, 400)
                    delay(700)
                }
            } finally {
                generator.release()
            }
        }
    }
}

private val presetsMinutes = listOf(1, 3, 5, 10, 15, 30, 60)

@Composable
fun TimerContent(padding: PaddingValues) {
    val viewModel: TimerViewModel = viewModel()
    val timer by viewModel.timer.collectAsStateWithLifecycle()
    val finished by viewModel.finished.collectAsStateWithLifecycle()
    var now by remember { mutableLongStateOf(monotonicNow()) }
    val haptic = LocalHapticFeedback.current
    val lifecycleOwner = LocalLifecycleOwner.current
    val running = timer?.running == true

    LaunchedEffect(running, lifecycleOwner) {
        now = monotonicNow()
        if (running) {
            lifecycleOwner.repeatOnLifecycle(Lifecycle.State.STARTED) {
                while (true) {
                    now = monotonicNow()
                    if (viewModel.checkFinished()) haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                    delay(100)
                }
            }
        }
    }

    // Garde l'écran allumé pendant le décompte (le minuteur ne fonctionne qu'au premier plan).
    val view = LocalView.current
    DisposableEffect(running) {
        view.keepScreenOn = running
        onDispose { view.keepScreenOn = false }
    }

    CenteredContent {
        Column(
            Modifier.fillMaxSize().consumeWindowInsets(padding).imePadding().padding(padding.withInner()),
            verticalArrangement = Arrangement.spacedBy(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            val current = timer
            if (current == null) {
                TimerSetup(onStart = viewModel::startNew)
            } else {
                val remaining = current.remaining(now)
                Box(contentAlignment = Alignment.Center, modifier = Modifier.padding(top = 24.dp)) {
                    CircularProgressIndicator(
                        progress = { current.fractionRemaining(now) },
                        modifier = Modifier.size(240.dp),
                        color = ToolCategory.DAILY.colors.accent,
                        strokeWidth = 12.dp,
                        trackColor = MaterialTheme.colorScheme.surfaceContainerHighest,
                    )
                    Text(
                        Durations.format(remaining, hundredths = false),
                        style = MaterialTheme.typography.displayMedium,
                        fontFamily = CodeFont,
                        modifier = Modifier.semantics { contentDescription = "Temps restant : ${Durations.spoken(remaining)}" },
                    )
                }
                if (finished) NoticeCard("Temps écoulé !", NoticeLevel.SUCCESS)
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    OutlinedButton(onClick = viewModel::clear, modifier = Modifier.heightIn(min = 52.dp)) { Text("Nouvelle durée") }
                    when {
                        current.running -> Button(onClick = viewModel::pause, modifier = Modifier.heightIn(min = 52.dp), colors = dailyButtonColors()) {
                            Icon(Icons.Rounded.Pause, contentDescription = null)
                            Text("  Pause")
                        }
                        remaining > 0 -> Button(onClick = viewModel::resume, modifier = Modifier.heightIn(min = 52.dp), colors = dailyButtonColors()) {
                            Icon(Icons.Rounded.PlayArrow, contentDescription = null)
                            Text("  Reprendre")
                        }
                        else -> FilledTonalButton(onClick = viewModel::restart, modifier = Modifier.heightIn(min = 52.dp)) {
                            Icon(Icons.Rounded.RestartAlt, contentDescription = null)
                            Text("  Relancer")
                        }
                    }
                }
            }
            NoticeCard(
                "Pas de notification ni d'alarme système : gardez l'outil ouvert. En arrière-plan, le décompte continue " +
                    "mais l'alerte n'est émise qu'à votre retour. L'écran reste allumé pendant le décompte.",
                NoticeLevel.INFO,
            )
        }
    }
}

@Composable
private fun TimerSetup(onStart: (Long) -> Unit) {
    var hours by rememberSaveable { mutableStateOf("") }
    var minutes by rememberSaveable { mutableStateOf("5") }
    var seconds by rememberSaveable { mutableStateOf("") }
    val parsed = CountdownTimer.parseDuration(hours, minutes, seconds)

    Text("Durée", style = MaterialTheme.typography.titleMedium, modifier = Modifier.fillMaxWidth())
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        DurationField("Heures", hours, Modifier.weight(1f)) { hours = it }
        DurationField("Minutes", minutes, Modifier.weight(1f)) { minutes = it }
        DurationField("Secondes", seconds, Modifier.weight(1f)) { seconds = it }
    }
    FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
        presetsMinutes.forEach { m ->
            AssistChip(
                onClick = { hours = ""; minutes = m.toString(); seconds = "" },
                label = { Text(if (m == 60) "1 h" else "$m min") },
            )
        }
    }
    if (parsed is Outcome.Err && (hours + minutes + seconds).isNotBlank()) NoticeCard(parsed.message, NoticeLevel.ERROR)
    Button(
        onClick = { (parsed as? Outcome.Ok)?.let { onStart(it.value) } },
        enabled = parsed is Outcome.Ok,
        modifier = Modifier.fillMaxWidth().heightIn(min = 52.dp),
        colors = dailyButtonColors(),
    ) {
        Icon(Icons.Rounded.PlayArrow, contentDescription = null)
        Text("  Démarrer")
    }
}

@Composable
private fun DurationField(label: String, value: String, modifier: Modifier, onChange: (String) -> Unit) {
    OutlinedTextField(
        value = value,
        onValueChange = { onChange(it.filter(Char::isDigit).take(2)) },
        label = { Text(label) },
        singleLine = true,
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
        modifier = modifier,
    )
}
