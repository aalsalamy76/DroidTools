package com.alsalamy.droidtools.ui.form

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.consumeWindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.selection.toggleable
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.CalendarMonth
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.ContentCopy
import androidx.compose.material.icons.rounded.ExpandMore
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Remove
import androidx.compose.material.icons.rounded.Visibility
import androidx.compose.material.icons.rounded.VisibilityOff
import androidx.compose.material3.Button
import androidx.compose.material3.DatePicker
import androidx.compose.material3.DatePickerDialog
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.LocalTextStyle
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedCard
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberDatePickerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.heading
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.alsalamy.droidtools.core.LocalAppContainer
import com.alsalamy.droidtools.domain.ToolDefinition
import com.alsalamy.droidtools.domain.ToolStatus
import com.alsalamy.droidtools.forms.ChoiceInput
import com.alsalamy.droidtools.forms.Field
import com.alsalamy.droidtools.forms.FormOutcome
import com.alsalamy.droidtools.forms.FormValues
import com.alsalamy.droidtools.forms.InputKind
import com.alsalamy.droidtools.forms.NoticeLevel
import com.alsalamy.droidtools.forms.ResultHeader
import com.alsalamy.droidtools.forms.ResultItem
import com.alsalamy.droidtools.forms.ResultMeter
import com.alsalamy.droidtools.forms.ResultNotice
import com.alsalamy.droidtools.forms.ResultRow
import com.alsalamy.droidtools.forms.ResultText
import com.alsalamy.droidtools.forms.SliderInput
import com.alsalamy.droidtools.forms.TextInput
import com.alsalamy.droidtools.forms.ToggleInput
import com.alsalamy.droidtools.forms.ToolForm
import com.alsalamy.droidtools.forms.Trigger
import com.alsalamy.droidtools.security.SecureScreenEffect
import com.alsalamy.droidtools.security.rememberCopyAction
import com.alsalamy.droidtools.ui.components.CenteredContent
import com.alsalamy.droidtools.ui.components.NoticeCard
import com.alsalamy.droidtools.ui.components.withInner
import com.alsalamy.droidtools.ui.theme.LocalExtraColors
import com.alsalamy.droidtools.ui.theme.CodeFont
import com.alsalamy.droidtools.ui.theme.colors
import com.alsalamy.droidtools.ui.components.vector
import com.alsalamy.droidtools.domain.ToolCategory
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.ButtonDefaults
import kotlinx.coroutines.delay
import java.time.Instant
import java.time.ZoneOffset
import java.time.format.DateTimeFormatter
import kotlin.math.roundToInt

/** Longueur maximale d'un champ : protège la fluidité de l'interface. */
private const val MAX_FIELD_LENGTH = 200_000

/** Au-delà, un texte de résultat est tronqué à l'écran (la copie reste complète). */
private const val MAX_DISPLAYED_CHARS = 20_000

@Composable
fun FormToolContent(tool: ToolDefinition, form: ToolForm, padding: PaddingValues) {
    val container = LocalAppContainer.current
    val viewModel: FormViewModel = viewModel(key = "form-${tool.id}") {
        FormViewModel(form) { container.newFormContext() }
    }
    val values by viewModel.values.collectAsStateWithLifecycle()
    val outcome by viewModel.outcome.collectAsStateWithLifecycle()
    val computing by viewModel.computing.collectAsStateWithLifecycle()

    if (form.secureScreen) SecureScreenEffect()

    // L'indicateur n'apparaît que pour un calcul long, pour éviter un clignotement.
    var showProgress by remember { mutableStateOf(false) }
    LaunchedEffect(computing) {
        if (computing) {
            delay(300)
            showProgress = true
        } else {
            showProgress = false
        }
    }

    CenteredContent {
        LazyColumn(
            modifier = Modifier.fillMaxSize().consumeWindowInsets(padding).imePadding(),
            contentPadding = padding.withInner(),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            item(key = "header") { ToolHeader(tool, form) }
            items(form.visibleFields(values), key = { "field-${it.key}" }) { field ->
                FieldView(field, values, viewModel::update)
            }
            if (form.trigger != Trigger.LIVE) {
                item(key = "action") {
                    Button(
                        onClick = viewModel::runAction,
                        modifier = Modifier.fillMaxWidth().heightIn(min = 56.dp),
                        shape = MaterialTheme.shapes.large,
                        colors = ButtonDefaults.buttonColors(containerColor = tool.category.colors.tile, contentColor = tool.category.colors.onTile),
                    ) {
                        Icon(Icons.Rounded.PlayArrow, contentDescription = null)
                        Spacer(Modifier.width(8.dp))
                        Text(form.actionLabel)
                    }
                }
            }
            if (showProgress) {
                item(key = "progress") { LinearProgressIndicator(Modifier.fillMaxWidth()) }
            }
            when (val o = outcome) {
                null -> Unit
                is FormOutcome.Waiting -> item(key = "waiting") {
                    Text(
                        o.hint ?: "Le résultat s'affichera ici dès que les champs seront remplis.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
                is FormOutcome.Invalid -> item(key = "error") { NoticeCard(o.message, NoticeLevel.ERROR) }
                is FormOutcome.Success -> itemsIndexed(o.result.items, key = { i, _ -> "result-$i" }) { _, item ->
                    ResultItemView(item, tool.category)
                }
            }
        }
    }
}

/** En-tête aux couleurs de la famille de l'outil : icône et rôle de l'outil en une phrase. */
@Composable
private fun ToolHeader(tool: ToolDefinition, form: ToolForm) {
    val colors = tool.category.colors
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Surface(color = colors.tile, contentColor = colors.onTile, shape = MaterialTheme.shapes.large, modifier = Modifier.fillMaxWidth()) {
            Row(Modifier.padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(
                    Modifier.size(48.dp).clip(CircleShape).background(colors.onTile.copy(alpha = 0.16f)),
                    contentAlignment = Alignment.Center,
                ) {
                    Icon(tool.icon.vector(), contentDescription = null, modifier = Modifier.size(26.dp))
                }
                Spacer(Modifier.width(14.dp))
                Column {
                    Text(tool.category.label, style = MaterialTheme.typography.labelMedium)
                    Text(tool.description, style = MaterialTheme.typography.titleMedium)
                }
            }
        }
        form.intro?.let { Text(it, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant) }
        form.warning?.let { NoticeCard(it, NoticeLevel.WARNING) }
        if (tool.status == ToolStatus.PARTIAL && tool.limitations.isNotEmpty()) {
            NoticeCard("Outil partiel. " + tool.limitations.joinToString(" "), NoticeLevel.INFO)
        }
    }
}

// ------------------------------------------------------------------ Champs

@Composable
private fun FieldView(field: Field, values: FormValues, onChange: (String, String) -> Unit) {
    when (field) {
        is TextInput -> TextFieldView(field, values[field.key]) { onChange(field.key, it) }
        is ChoiceInput -> ChoiceFieldView(field, values[field.key]) { onChange(field.key, it) }
        is ToggleInput -> ToggleFieldView(field, values.flag(field.key)) { onChange(field.key, it.toString()) }
        is SliderInput -> SliderFieldView(field, values.int(field.key, field.default)) { onChange(field.key, it.toString()) }
    }
}

private fun keyboardFor(kind: InputKind): KeyboardOptions = when (kind) {
    InputKind.TEXT, InputKind.MULTILINE -> KeyboardOptions(capitalization = KeyboardCapitalization.Sentences)
    InputKind.CODE, InputKind.CODE_BLOCK -> KeyboardOptions(autoCorrectEnabled = false, keyboardType = KeyboardType.Ascii)
    InputKind.NUMBER, InputKind.INTEGER -> KeyboardOptions(keyboardType = KeyboardType.Decimal)
    InputKind.DATE, InputKind.DATE_TIME -> KeyboardOptions(autoCorrectEnabled = false, keyboardType = KeyboardType.Ascii)
    // Type « mot de passe » : les claviers ne proposent pas de suggestions et ne mémorisent pas la saisie.
    InputKind.SECRET -> KeyboardOptions(autoCorrectEnabled = false, keyboardType = KeyboardType.Password)
}

@Composable
private fun TextFieldView(field: TextInput, value: String, onChange: (String) -> Unit) {
    var revealed by rememberSaveable { mutableStateOf(false) }
    var pickingDate by remember { mutableStateOf(false) }
    val multiline = field.kind == InputKind.MULTILINE || field.kind == InputKind.CODE_BLOCK
    val monospace = field.kind == InputKind.CODE || field.kind == InputKind.CODE_BLOCK
    val baseStyle = LocalTextStyle.current
    OutlinedTextField(
        value = value,
        onValueChange = { if (it.length <= MAX_FIELD_LENGTH) onChange(it) },
        modifier = Modifier.fillMaxWidth(),
        label = { Text(field.label) },
        placeholder = if (field.placeholder.isNotEmpty()) {
            { Text(field.placeholder, maxLines = 2) }
        } else {
            null
        },
        supportingText = field.supportingText?.let { text -> { Text(text) } },
        suffix = field.suffix?.let { text -> { Text(text) } },
        singleLine = !multiline,
        minLines = if (multiline) 3 else 1,
        maxLines = if (multiline) 10 else 1,
        textStyle = if (monospace) baseStyle.copy(fontFamily = CodeFont) else baseStyle,
        visualTransformation = if (field.kind == InputKind.SECRET && !revealed) PasswordVisualTransformation() else VisualTransformation.None,
        keyboardOptions = keyboardFor(field.kind),
        trailingIcon = when {
            field.kind == InputKind.SECRET -> {
                {
                    IconButton(onClick = { revealed = !revealed }) {
                        Icon(
                            if (revealed) Icons.Rounded.VisibilityOff else Icons.Rounded.Visibility,
                            contentDescription = if (revealed) "Masquer le mot de passe" else "Afficher le mot de passe",
                        )
                    }
                }
            }
            field.kind == InputKind.DATE || field.kind == InputKind.DATE_TIME -> {
                {
                    IconButton(onClick = { pickingDate = true }) {
                        Icon(Icons.Rounded.CalendarMonth, contentDescription = "Choisir une date dans le calendrier")
                    }
                }
            }
            value.isNotEmpty() -> {
                {
                    IconButton(onClick = { onChange("") }) {
                        Icon(Icons.Rounded.Close, contentDescription = "Effacer « ${field.label} »")
                    }
                }
            }
            else -> null
        },
    )
    if (pickingDate) {
        DatePickerDialogView(
            onDismiss = { pickingDate = false },
            onPicked = { date ->
                // Conserve l'heure déjà saisie pour un champ date et heure.
                val time = if (field.kind == InputKind.DATE_TIME) value.trim().substringAfter(' ', "").trim() else ""
                onChange(if (time.isNotEmpty()) "$date $time" else date)
            },
        )
    }
}

@Composable
private fun DatePickerDialogView(onDismiss: () -> Unit, onPicked: (String) -> Unit) {
    val state = rememberDatePickerState()
    DatePickerDialog(
        onDismissRequest = onDismiss,
        confirmButton = {
            TextButton(
                onClick = {
                    state.selectedDateMillis?.let { millis ->
                        // Le sélecteur renvoie minuit UTC du jour choisi.
                        val date = Instant.ofEpochMilli(millis).atZone(ZoneOffset.UTC).toLocalDate()
                        onPicked(date.format(DateTimeFormatter.ofPattern("dd/MM/uuuu")))
                    }
                    onDismiss()
                },
            ) { Text("Valider") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Annuler") } },
    ) {
        DatePicker(state = state)
    }
}

@Composable
private fun ChoiceFieldView(field: ChoiceInput, value: String, onChange: (String) -> Unit) {
    val selected = field.options.firstOrNull { it.id == value } ?: field.options.first()
    if (field.options.size <= 6) {
        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text(field.label, style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.onSurfaceVariant)
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                field.options.forEach { option ->
                    val isSelected = option.id == selected.id
                    FilterChip(
                        selected = isSelected,
                        onClick = { onChange(option.id) },
                        label = { Text(option.label) },
                        leadingIcon = if (isSelected) {
                            { Icon(Icons.Rounded.Check, contentDescription = null, modifier = Modifier.size(FilterChipDefaults.IconSize)) }
                        } else {
                            null
                        },
                    )
                }
            }
        }
    } else {
        var expanded by remember { mutableStateOf(false) }
        Box {
            OutlinedCard(onClick = { expanded = true }, modifier = Modifier.fillMaxWidth()) {
                Row(Modifier.padding(horizontal = 16.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(field.label, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Text(selected.label, style = MaterialTheme.typography.bodyLarge)
                    }
                    Icon(Icons.Rounded.ExpandMore, contentDescription = "Choisir ${field.label}")
                }
            }
            DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }, modifier = Modifier.heightIn(max = 420.dp)) {
                field.options.forEach { option ->
                    DropdownMenuItem(
                        text = { Text(option.label) },
                        onClick = {
                            onChange(option.id)
                            expanded = false
                        },
                        leadingIcon = if (option.id == selected.id) {
                            { Icon(Icons.Rounded.Check, contentDescription = "Sélectionné") }
                        } else {
                            null
                        },
                    )
                }
            }
        }
    }
}

@Composable
private fun ToggleFieldView(field: ToggleInput, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .clip(MaterialTheme.shapes.medium)
            .toggleable(value = checked, role = Role.Switch, onValueChange = onChange)
            .heightIn(min = 56.dp)
            .padding(horizontal = 4.dp, vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(Modifier.weight(1f)) {
            Text(field.label, style = MaterialTheme.typography.bodyLarge)
            field.supportingText?.let {
                Text(it, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
        Spacer(Modifier.width(12.dp))
        Switch(checked = checked, onCheckedChange = null)
    }
}

@Composable
private fun SliderFieldView(field: SliderInput, value: Int, onChange: (Int) -> Unit) {
    val current = value.coerceIn(field.min, field.max)
    val unit = if (field.unit.isNotEmpty()) " ${field.unit}" else ""
    Column {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(field.label, style = MaterialTheme.typography.bodyLarge, modifier = Modifier.weight(1f))
            Text("$current$unit", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = { onChange((current - 1).coerceAtLeast(field.min)) }, enabled = current > field.min) {
                Icon(Icons.Rounded.Remove, contentDescription = "Diminuer ${field.label}")
            }
            Slider(
                value = current.toFloat(),
                onValueChange = { onChange(it.roundToInt()) },
                valueRange = field.min.toFloat()..field.max.toFloat(),
                modifier = Modifier.weight(1f).semantics { contentDescription = "${field.label} : $current$unit" },
            )
            IconButton(onClick = { onChange((current + 1).coerceAtMost(field.max)) }, enabled = current < field.max) {
                Icon(Icons.Rounded.Add, contentDescription = "Augmenter ${field.label}")
            }
        }
    }
}

// ------------------------------------------------------------------ Résultats

@Composable
fun ResultItemView(item: ResultItem, category: ToolCategory? = null) {
    when (item) {
        is ResultHeader -> Text(
            item.title,
            style = MaterialTheme.typography.titleSmall,
            fontWeight = FontWeight.SemiBold,
            color = MaterialTheme.colorScheme.primary,
            modifier = Modifier.padding(top = 8.dp).semantics { heading() },
        )
        is ResultRow -> ResultRowView(item, category)
        is ResultText -> ResultTextView(item)
        is ResultNotice -> NoticeCard(item.text, item.level)
        is ResultMeter -> MeterView(item)
    }
}

@Composable
private fun ResultRowView(row: ResultRow, category: ToolCategory?) {
    val copy = rememberCopyAction()
    val colors = MaterialTheme.colorScheme
    // Le résultat principal reprend la couleur de la famille de l'outil.
    val emphasisColors = category?.colors
    Surface(
        shape = if (row.emphasis) MaterialTheme.shapes.large else MaterialTheme.shapes.medium,
        color = if (row.emphasis) emphasisColors?.tile ?: colors.primaryContainer else colors.surfaceContainerLow,
        contentColor = if (row.emphasis) emphasisColors?.onTile ?: colors.onPrimaryContainer else colors.onSurface,
        modifier = Modifier.fillMaxWidth(),
    ) {
        Row(Modifier.padding(start = 16.dp, top = 12.dp, bottom = 12.dp, end = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            row.swatchArgb?.let { argb ->
                Box(
                    Modifier
                        .size(44.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(Color(argb))
                        .border(1.dp, colors.outline, RoundedCornerShape(12.dp)),
                )
                Spacer(Modifier.width(12.dp))
            }
            Column(Modifier.weight(1f)) {
                Text(row.label, style = MaterialTheme.typography.labelMedium)
                SelectionContainer {
                    Text(
                        row.value,
                        style = when {
                            row.emphasis && row.monospace -> MaterialTheme.typography.titleLarge.copy(fontFamily = CodeFont, fontWeight = FontWeight.Bold)
                            row.emphasis -> MaterialTheme.typography.headlineMedium
                            row.monospace -> MaterialTheme.typography.bodyLarge.copy(fontFamily = CodeFont)
                            else -> MaterialTheme.typography.bodyLarge
                        },
                    )
                }
            }
            if (row.copyable) {
                IconButton(onClick = { copy(row.label, row.value, row.sensitive) }) {
                    Icon(Icons.Rounded.ContentCopy, contentDescription = "Copier « ${row.label} »")
                }
            } else {
                Spacer(Modifier.width(12.dp))
            }
        }
    }
}

@Composable
private fun ResultTextView(result: ResultText) {
    val copy = rememberCopyAction()
    val truncated = result.text.length > MAX_DISPLAYED_CHARS
    Surface(shape = MaterialTheme.shapes.medium, color = MaterialTheme.colorScheme.surfaceContainerLow, modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(start = 16.dp, end = 4.dp, top = 8.dp, bottom = 16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(result.label, style = MaterialTheme.typography.labelLarge, modifier = Modifier.weight(1f))
                IconButton(onClick = { copy(result.label, result.text, result.sensitive) }) {
                    Icon(Icons.Rounded.ContentCopy, contentDescription = "Copier « ${result.label} »")
                }
            }
            SelectionContainer(Modifier.padding(end = 12.dp)) {
                Text(
                    if (truncated) result.text.take(MAX_DISPLAYED_CHARS) + "…" else result.text,
                    style = MaterialTheme.typography.bodyMedium,
                    fontFamily = if (result.monospace) CodeFont else null,
                )
            }
            if (truncated) {
                Spacer(Modifier.height(8.dp))
                Text(
                    "Aperçu limité à ${MAX_DISPLAYED_CHARS / 1000} 000 caractères. Le bouton Copier copie le texte complet.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }
    }
}

@Composable
private fun MeterView(meter: ResultMeter) {
    val colors = MaterialTheme.colorScheme
    val barColor = when (meter.level) {
        NoticeLevel.ERROR -> colors.error
        NoticeLevel.WARNING -> LocalExtraColors.current.onWarningContainer
        NoticeLevel.SUCCESS -> colors.primary
        NoticeLevel.INFO -> colors.secondary
    }
    Column(
        Modifier.fillMaxWidth().semantics(mergeDescendants = true) { contentDescription = "${meter.label} : ${meter.valueText}" },
        verticalArrangement = Arrangement.spacedBy(6.dp),
    ) {
        Row {
            Text(meter.label, style = MaterialTheme.typography.labelLarge, modifier = Modifier.weight(1f))
            Text(meter.valueText, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
        }
        LinearProgressIndicator(
            progress = { meter.fraction },
            modifier = Modifier.fillMaxWidth().height(8.dp).clip(RoundedCornerShape(4.dp)),
            color = barColor,
            trackColor = colors.surfaceContainerHighest,
        )
    }
}
