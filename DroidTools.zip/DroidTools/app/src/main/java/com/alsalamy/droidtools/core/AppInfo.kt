package com.alsalamy.droidtools.core

import android.content.Context
import android.content.pm.PackageInfo
import android.content.pm.PackageManager
import android.os.Build

/** Informations lues dynamiquement auprès d'Android (jamais codées en dur). */
object AppInfo {

    data class Version(val name: String, val code: Long)

    data class PermissionState(val name: String, val granted: Boolean) {
        val label: String get() = permissionLabel(name)
    }

    fun version(context: Context): Version {
        val info = packageInfo(context, 0)
        val code = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            info.longVersionCode
        } else {
            @Suppress("DEPRECATION")
            info.versionCode.toLong()
        }
        return Version(info.versionName ?: "inconnue", code)
    }

    /** Permissions déclarées dans le manifeste final (y compris celles ajoutées par les bibliothèques). */
    fun requestedPermissions(context: Context): List<PermissionState> {
        val info = packageInfo(context, PackageManager.GET_PERMISSIONS)
        val names = info.requestedPermissions ?: return emptyList()
        val flags = info.requestedPermissionsFlags ?: IntArray(0)
        return names.mapIndexed { index, name ->
            PermissionState(name, (flags.getOrElse(index) { 0 } and PackageInfo.REQUESTED_PERMISSION_GRANTED) != 0)
        }
    }

    private fun packageInfo(context: Context, flags: Int): PackageInfo =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            context.packageManager.getPackageInfo(context.packageName, PackageManager.PackageInfoFlags.of(flags.toLong()))
        } else {
            @Suppress("DEPRECATION")
            context.packageManager.getPackageInfo(context.packageName, flags)
        }

    fun permissionLabel(name: String): String = when {
        name == "android.permission.INTERNET" -> "Accès à Internet"
        name == "android.permission.ACCESS_NETWORK_STATE" -> "État du réseau"
        name == "android.permission.CAMERA" -> "Caméra"
        name == "android.permission.RECORD_AUDIO" -> "Microphone"
        name == "android.permission.ACCESS_FINE_LOCATION" -> "Localisation précise"
        name == "android.permission.ACCESS_COARSE_LOCATION" -> "Localisation approximative"
        name == "android.permission.VIBRATE" -> "Vibration"
        name == "android.permission.POST_NOTIFICATIONS" -> "Notifications"
        name.endsWith(".DYNAMIC_RECEIVER_NOT_EXPORTED_PERMISSION") ->
            "Permission interne (signature), ajoutée par AndroidX : réservée à l'application elle-même, sans accès à vos données"
        else -> name
    }
}
