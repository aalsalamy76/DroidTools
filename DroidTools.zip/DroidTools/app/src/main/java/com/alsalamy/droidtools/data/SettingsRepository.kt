package com.alsalamy.droidtools.data

import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.emptyPreferences
import androidx.datastore.preferences.core.stringPreferencesKey
import com.alsalamy.droidtools.domain.ToolCatalog
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map
import java.io.IOException

enum class ThemeMode(val label: String) {
    SYSTEM("Système"),
    LIGHT("Clair"),
    DARK("Sombre"),
}

data class AppSettings(
    val themeMode: ThemeMode = ThemeMode.SYSTEM,
    val dynamicColor: Boolean = false,
    /** Mémorise les outils ouverts récemment (identifiants d'outils uniquement, jamais leur contenu). */
    val historyEnabled: Boolean = true,
    val favorites: List<String> = emptyList(),
    val recents: List<String> = emptyList(),
)

/**
 * Réglages, favoris et outils récents, stockés localement avec Jetpack DataStore.
 * Seuls des identifiants d'outils sont enregistrés : aucune donnée saisie dans un outil.
 */
class SettingsRepository(private val store: DataStore<Preferences>) {

    private object Keys {
        val THEME = stringPreferencesKey("theme_mode")
        val DYNAMIC = booleanPreferencesKey("dynamic_color")
        val HISTORY = booleanPreferencesKey("history_enabled")
        val FAVORITES = stringPreferencesKey("favorites")
        val RECENTS = stringPreferencesKey("recents")
    }

    val settings: Flow<AppSettings> = store.data
        .catch { e -> if (e is IOException) emit(emptyPreferences()) else throw e }
        .map { p ->
            AppSettings(
                themeMode = ThemeMode.entries.firstOrNull { it.name == p[Keys.THEME] } ?: ThemeMode.SYSTEM,
                dynamicColor = p[Keys.DYNAMIC] ?: false,
                historyEnabled = p[Keys.HISTORY] ?: true,
                favorites = decodeIds(p[Keys.FAVORITES]),
                recents = decodeIds(p[Keys.RECENTS]),
            )
        }

    /** Ignore les identifiants inconnus (outil retiré d'une version à l'autre). */
    private fun decodeIds(raw: String?): List<String> =
        raw.orEmpty().split(',').filter { it.isNotEmpty() && ToolCatalog.find(it) != null }.distinct()

    suspend fun setThemeMode(mode: ThemeMode) {
        store.edit { it[Keys.THEME] = mode.name }
    }

    suspend fun setDynamicColor(enabled: Boolean) {
        store.edit { it[Keys.DYNAMIC] = enabled }
    }

    /** Désactiver l'historique efface aussi les outils récents déjà enregistrés. */
    suspend fun setHistoryEnabled(enabled: Boolean) {
        store.edit {
            it[Keys.HISTORY] = enabled
            if (!enabled) it.remove(Keys.RECENTS)
        }
    }

    suspend fun toggleFavorite(id: String) {
        store.edit { p ->
            val current = decodeIds(p[Keys.FAVORITES])
            val next = if (id in current) current - id else current + id
            p[Keys.FAVORITES] = next.joinToString(",")
        }
    }

    suspend fun recordRecent(id: String) {
        store.edit { p ->
            if (p[Keys.HISTORY] == false) return@edit
            val next = (listOf(id) + decodeIds(p[Keys.RECENTS]).filter { it != id }).take(MAX_RECENTS)
            p[Keys.RECENTS] = next.joinToString(",")
        }
    }

    suspend fun clearRecents() {
        store.edit { it.remove(Keys.RECENTS) }
    }

    suspend fun clearAll() {
        store.edit { it.clear() }
    }

    companion object {
        const val MAX_RECENTS = 12
    }
}
