package com.alsalamy.droidtools.ui.custom

import android.content.ContentResolver
import android.net.Uri
import android.provider.OpenableColumns
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.consumeWindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.FolderOpen
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import com.alsalamy.droidtools.core.ByteFormat
import com.alsalamy.droidtools.core.Outcome
import com.alsalamy.droidtools.domain.ToolCategory
import com.alsalamy.droidtools.ui.theme.colors
import androidx.compose.material3.ButtonDefaults
import com.alsalamy.droidtools.forms.NoticeLevel
import com.alsalamy.droidtools.forms.ResultRow
import com.alsalamy.droidtools.security.HashAlgorithm
import com.alsalamy.droidtools.security.HashComparison
import com.alsalamy.droidtools.security.HashResult
import com.alsalamy.droidtools.security.Hashing
import com.alsalamy.droidtools.ui.components.CenteredContent
import com.alsalamy.droidtools.ui.components.InfoCard
import com.alsalamy.droidtools.ui.components.NoticeCard
import com.alsalamy.droidtools.ui.components.withInner
import com.alsalamy.droidtools.ui.form.ResultItemView
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.FileNotFoundException
import java.io.IOException

/**
 * Empreinte d'un fichier choisi par l'utilisateur dans le sélecteur système (Storage Access Framework).
 * Aucune permission de stockage : l'accès est limité au fichier choisi, en lecture, le temps du calcul.
 */
class FileHashViewModel(private val resolver: ContentResolver) : ViewModel() {

    data class FileInfo(val name: String, val size: Long?)

    sealed interface Status {
        data object Idle : Status
        data object Running : Status
        data class Done(val results: Map<HashAlgorithm, HashResult>) : Status
        data class Failed(val message: String) : Status
        data object Cancelled : Status
    }

    private val _selected = MutableStateFlow(setOf(HashAlgorithm.SHA256))
    val selected: StateFlow<Set<HashAlgorithm>> = _selected.asStateFlow()

    private val _file = MutableStateFlow<FileInfo?>(null)
    val file: StateFlow<FileInfo?> = _file.asStateFlow()

    private val _status = MutableStateFlow<Status>(Status.Idle)
    val status: StateFlow<Status> = _status.asStateFlow()

    private val _progress = MutableStateFlow(0L)
    val progress: StateFlow<Long> = _progress.asStateFlow()

    private var uri: Uri? = null
    private var job: Job? = null

    fun onFilePicked(picked: Uri) {
        uri = picked
        compute()
    }

    fun toggle(algorithm: HashAlgorithm) {
        _selected.update { current ->
            when {
                algorithm !in current -> current + algorithm
                current.size > 1 -> current - algorithm
                else -> current // au moins un algorithme
            }
        }
        if (uri != null) compute()
    }

    fun cancel() {
        job?.cancel()
        _status.value = Status.Cancelled
    }

    private fun compute() {
        val target = uri ?: return
        val algorithms = HashAlgorithm.entries.filter { it in _selected.value }
        job?.cancel()
        job = viewModelScope.launch {
            _status.value = Status.Running
            _progress.value = 0
            try {
                val results = withContext(Dispatchers.IO) {
                    _file.value = queryInfo(target)
                    val input = resolver.openInputStream(target) ?: throw FileNotFoundException()
                    input.use { stream ->
                        Hashing.stream(
                            stream,
                            algorithms,
                            onProgress = { _progress.value = it },
                            isCancelled = { !isActive },
                        )
                    }
                }
                _status.value = Status.Done(results)
            } catch (e: CancellationException) {
                throw e
            } catch (e: FileNotFoundException) {
                _status.value = Status.Failed("Fichier introuvable ou inaccessible.")
            } catch (e: SecurityException) {
                _status.value = Status.Failed("Accès au fichier refusé par Android.")
            } catch (e: IOException) {
                _status.value = Status.Failed("Lecture du fichier impossible (fichier corrompu ou stockage indisponible).")
            }
        }
    }

    private fun queryInfo(target: Uri): FileInfo {
        var name = "Fichier sans nom"
        var size: Long? = null
        try {
            resolver.query(target, arrayOf(OpenableColumns.DISPLAY_NAME, OpenableColumns.SIZE), null, null, null)?.use { cursor ->
                if (cursor.moveToFirst()) {
                    val nameIndex = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    val sizeIndex = cursor.getColumnIndex(OpenableColumns.SIZE)
                    if (nameIndex >= 0 && !cursor.isNull(nameIndex)) name = cursor.getString(nameIndex)
                    if (sizeIndex >= 0 && !cursor.isNull(sizeIndex)) size = cursor.getLong(sizeIndex)
                }
            }
        } catch (e: RuntimeException) {
            // Métadonnées indisponibles : le calcul reste possible.
        }
        return FileInfo(name, size)
    }
}

@Composable
fun FileHashContent(padding: PaddingValues) {
    val resolver = LocalContext.current.contentResolver
    val viewModel: FileHashViewModel = viewModel { FileHashViewModel(resolver) }
    val selected by viewModel.selected.collectAsStateWithLifecycle()
    val file by viewModel.file.collectAsStateWithLifecycle()
    val status by viewModel.status.collectAsStateWithLifecycle()
    val progress by viewModel.progress.collectAsStateWithLifecycle()
    var expected by rememberSaveable { mutableStateOf("") }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) viewModel.onFilePicked(uri)
    }

    CenteredContent {
        Column(
            Modifier.fillMaxSize().consumeWindowInsets(padding).imePadding().verticalScroll(rememberScrollState()).padding(padding.withInner()),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            Text(
                "Calcule l'empreinte d'un fichier pour vérifier qu'il n'a pas été altéré (comparez-la à celle publiée par l'éditeur).",
                style = MaterialTheme.typography.bodyLarge,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Text("Algorithmes", style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.onSurfaceVariant)
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                HashAlgorithm.entries.forEach { algorithm ->
                    val isSelected = algorithm in selected
                    FilterChip(
                        selected = isSelected,
                        onClick = { viewModel.toggle(algorithm) },
                        label = { Text(algorithm.label) },
                        leadingIcon = if (isSelected) {
                            { Icon(Icons.Rounded.Check, contentDescription = null, modifier = Modifier.size(FilterChipDefaults.IconSize)) }
                        } else {
                            null
                        },
                    )
                }
            }
            if (selected.any { !it.secure }) {
                NoticeCard("SHA-1 et MD5 ne protègent pas contre une falsification volontaire : utilisez-les seulement pour comparer une somme publiée dans ce format.", NoticeLevel.WARNING)
            }
            Button(
                onClick = { picker.launch(arrayOf("*/*")) },
                modifier = Modifier.fillMaxWidth().heightIn(min = 56.dp),
                shape = MaterialTheme.shapes.large,
                colors = ButtonDefaults.buttonColors(
                    containerColor = ToolCategory.SECURITY.colors.tile,
                    contentColor = ToolCategory.SECURITY.colors.onTile,
                ),
            ) {
                Icon(Icons.Rounded.FolderOpen, contentDescription = null)
                Spacer(Modifier.width(8.dp))
                Text(if (file == null) "Choisir un fichier" else "Choisir un autre fichier")
            }
            Text(
                "Le fichier est lu par blocs, sans être copié ni modifié. Aucune permission de stockage n'est demandée.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )

            file?.let { info ->
                InfoCard {
                    Text(info.name, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
                    Text(info.size?.let { ByteFormat.format(it) } ?: "Taille inconnue", style = MaterialTheme.typography.bodyMedium)
                }
            }

            when (val s = status) {
                FileHashViewModel.Status.Idle -> Unit
                FileHashViewModel.Status.Running -> {
                    val total = file?.size
                    if (total != null && total > 0) {
                        LinearProgressIndicator(progress = { (progress.toFloat() / total).coerceIn(0f, 1f) }, modifier = Modifier.fillMaxWidth())
                        Text("${ByteFormat.format(progress)} sur ${ByteFormat.format(total)}", style = MaterialTheme.typography.bodySmall)
                    } else {
                        LinearProgressIndicator(Modifier.fillMaxWidth())
                        Text("${ByteFormat.format(progress)} lus", style = MaterialTheme.typography.bodySmall)
                    }
                    OutlinedButton(onClick = viewModel::cancel) { Text("Annuler") }
                }
                FileHashViewModel.Status.Cancelled -> NoticeCard("Calcul annulé.", NoticeLevel.INFO)
                is FileHashViewModel.Status.Failed -> NoticeCard(s.message, NoticeLevel.ERROR)
                is FileHashViewModel.Status.Done -> {
                    s.results.forEach { (algorithm, result) ->
                        ResultItemView(ResultRow(algorithm.label, result.hex, monospace = true), ToolCategory.SECURITY)
                    }
                    OutlinedTextField(
                        value = expected,
                        onValueChange = { expected = it.take(300) },
                        label = { Text("Empreinte attendue (facultatif)") },
                        placeholder = { Text("Collez l'empreinte publiée") },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(autoCorrectEnabled = false, keyboardType = KeyboardType.Ascii),
                        modifier = Modifier.fillMaxWidth(),
                    )
                    if (expected.isNotBlank()) {
                        val wanted = Hashing.normalize(expected)
                        val match = s.results.values.any { r ->
                            val outcome = Hashing.compare(wanted, r.hex)
                            outcome is Outcome.Ok && outcome.value == HashComparison.EQUAL
                        }
                        if (match) {
                            NoticeCard("L'empreinte correspond : le fichier est identique à celui attendu.", NoticeLevel.SUCCESS)
                        } else {
                            NoticeCard(
                                "Aucune empreinte calculée ne correspond. Vérifiez l'algorithme sélectionné et la valeur collée ; sinon, le fichier diffère.",
                                NoticeLevel.ERROR,
                            )
                        }
                    }
                }
            }
        }
    }
}
