package com.alsalamy.droidtools.ui.favorites

import androidx.compose.foundation.layout.consumeWindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.StarBorder
import androidx.compose.material3.Button
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.alsalamy.droidtools.core.LocalAppContainer
import com.alsalamy.droidtools.data.AppSettings
import com.alsalamy.droidtools.domain.ToolCatalog
import com.alsalamy.droidtools.ui.components.CenteredContent
import com.alsalamy.droidtools.ui.components.EmptyState
import com.alsalamy.droidtools.ui.components.ToolRow
import com.alsalamy.droidtools.ui.components.withInner

@Composable
fun FavoritesScreen(settings: AppSettings, onOpenTool: (String) -> Unit, onBrowse: () -> Unit) {
    val container = LocalAppContainer.current
    val favorites = settings.favorites.mapNotNull(ToolCatalog::find)
    Scaffold(topBar = { TopAppBar(title = { Text("Favoris") }) }) { padding ->
        CenteredContent {
            LazyColumn(
                modifier = Modifier.fillMaxSize().consumeWindowInsets(padding),
                contentPadding = padding.withInner(horizontal = 12.dp),
            ) {
                if (favorites.isEmpty()) {
                    item {
                        EmptyState(
                            Icons.Rounded.StarBorder,
                            "Aucun favori",
                            "Touchez l'étoile ☆ à côté d'un outil pour l'ajouter ici. Vos favoris restent sur cet appareil.",
                        )
                    }
                    item { Button(onClick = onBrowse) { Text("Parcourir les outils") } }
                } else {
                    items(favorites, key = { it.id }) { tool ->
                        ToolRow(
                            tool = tool,
                            isFavorite = true,
                            onClick = { onOpenTool(tool.id) },
                            onToggleFavorite = { container.launch { container.settings.toggleFavorite(tool.id) } },
                        )
                    }
                }
            }
        }
    }
}
