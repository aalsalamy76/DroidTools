package com.alsalamy.droidtools

import android.graphics.Color
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.alsalamy.droidtools.core.LocalAppContainer
import com.alsalamy.droidtools.data.AppSettings
import com.alsalamy.droidtools.data.ThemeMode
import com.alsalamy.droidtools.navigation.DroidToolsRoot
import com.alsalamy.droidtools.ui.theme.DroidToolsTheme

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge()
        super.onCreate(savedInstanceState)
        val container = (application as DroidToolsApplication).container

        setContent {
            val loaded by container.settings.settings.collectAsStateWithLifecycle<AppSettings?>(initialValue = null)
            val systemDark = isSystemInDarkTheme()
            // Rien n'est dessiné tant que les réglages ne sont pas lus (quelques millisecondes) : évite un flash de thème.
            loaded?.let { settings ->
                val dark = when (settings.themeMode) {
                    ThemeMode.SYSTEM -> systemDark
                    ThemeMode.LIGHT -> false
                    ThemeMode.DARK -> true
                }
                // enableEdgeToEdge (activity 1.13) : à remplacer par WindowCompat.enableEdgeToEdge(window)
                // et WindowInsetsControllerCompat lors du passage à activity 1.14, qui le déprécie.
                DisposableEffect(dark) {
                    enableEdgeToEdge(
                        statusBarStyle = SystemBarStyle.auto(Color.TRANSPARENT, Color.TRANSPARENT) { dark },
                        navigationBarStyle = SystemBarStyle.auto(LIGHT_SCRIM, DARK_SCRIM) { dark },
                    )
                    onDispose { }
                }
                CompositionLocalProvider(LocalAppContainer provides container) {
                    DroidToolsTheme(darkTheme = dark, dynamicColor = settings.dynamicColor) {
                        DroidToolsRoot(settings)
                    }
                }
            }
        }
    }

    private companion object {
        // Voiles par défaut d'androidx.activity pour la navigation à trois boutons.
        val LIGHT_SCRIM = Color.argb(0xE6, 0xFF, 0xFF, 0xFF)
        val DARK_SCRIM = Color.argb(0x80, 0x1B, 0x1B, 0x1B)
    }
}
