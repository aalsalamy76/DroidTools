package com.alsalamy.droidtools.ui.settings

import android.content.Context
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.consumeWindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.alsalamy.droidtools.ui.components.BackButton
import com.alsalamy.droidtools.ui.components.CenteredContent
import com.alsalamy.droidtools.ui.components.InfoCard
import com.alsalamy.droidtools.ui.components.SectionHeader
import com.alsalamy.droidtools.ui.components.withInner
import com.alsalamy.droidtools.ui.theme.CodeFont
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.IOException

private data class Library(
    val name: String,
    val artifacts: String,
    val license: String,
    val usage: String,
    /** Texte complet de la licence, intégré à l'application. */
    val licenseAsset: String,
)

private const val APACHE = "licenses/apache-2.0.txt"

/**
 * Composants tiers réellement inclus dans l'application.
 * L'inventaire complet des dépendances transitives est publié par l'intégration continue (dependencies-release.txt).
 */
private val bundledFonts = listOf(
    Library("Bricolage Grotesque", "Copyright 2022 The Bricolage Grotesque Project Authors", "SIL Open Font License 1.1",
        "Police des titres (graisses statiques extraites et allégées)", "licenses/ofl-bricolagegrotesque.txt"),
    Library("Atkinson Hyperlegible Next", "Copyright 2020-2024 The Atkinson Hyperlegible Next Project Authors", "SIL Open Font License 1.1",
        "Police du texte (graisses statiques extraites et allégées)", "licenses/ofl-atkinsonhyperlegiblenext.txt"),
    Library("Atkinson Hyperlegible Mono", "Copyright 2020-2024 The Atkinson Hyperlegible Mono Project Authors", "SIL Open Font License 1.1",
        "Police des codes et mots de passe (graisses statiques extraites et allégées)", "licenses/ofl-atkinsonhyperlegiblemono.txt"),
)

private val libraries = listOf(
    Library("Jetpack Compose (UI, Foundation, Material 3)", "androidx.compose.*", "Apache 2.0", "Interface graphique", APACHE),
    Library("Material Icons Extended", "androidx.compose.material:material-icons-extended", "Apache 2.0", "Icônes", APACHE),
    Library("AndroidX Activity Compose", "androidx.activity:activity-compose", "Apache 2.0", "Activité principale, sélecteur de fichiers", APACHE),
    Library("AndroidX Lifecycle", "androidx.lifecycle:lifecycle-runtime-compose, lifecycle-viewmodel-compose", "Apache 2.0", "ViewModel, cycle de vie", APACHE),
    Library("AndroidX Navigation Compose", "androidx.navigation:navigation-compose", "Apache 2.0", "Navigation entre écrans", APACHE),
    Library("AndroidX DataStore", "androidx.datastore:datastore-preferences", "Apache 2.0", "Stockage local des réglages et de la checklist", APACHE),
    Library("Kotlin Standard Library", "org.jetbrains.kotlin:kotlin-stdlib", "Apache 2.0", "Langage Kotlin", APACHE),
    Library("Kotlin Coroutines", "org.jetbrains.kotlinx:kotlinx-coroutines-*", "Apache 2.0", "Traitements en arrière-plan (dépendance transitive)", APACHE),
    Library("Kotlin Serialization (core)", "org.jetbrains.kotlinx:kotlinx-serialization-core", "Apache 2.0", "Utilisée par Navigation (dépendance transitive)", APACHE),
    Library("Okio", "com.squareup.okio:okio", "Apache 2.0", "Écriture de fichiers par DataStore (dépendance transitive)", APACHE),
    Library("Autres composants AndroidX", "androidx.core, annotation, collection, savedstate, profileinstaller, startup…", "Apache 2.0", "Dépendances transitives des bibliothèques ci-dessus", APACHE),
)

private fun readAsset(context: Context, path: String): String? = try {
    context.assets.open(path).bufferedReader(Charsets.UTF_8).use { it.readText() }
} catch (e: IOException) {
    null
}

/** Lecture partagée des documents intégrés (licences, politique de confidentialité). */
internal suspend fun loadAsset(context: Context, path: String): String? = withContext(Dispatchers.IO) { readAsset(context, path) }

@Composable
fun LicensesScreen(onBack: () -> Unit) {
    Scaffold(topBar = { TopAppBar(title = { Text("Licences open source") }, navigationIcon = { BackButton(onBack) }) }) { padding ->
        CenteredContent {
            LazyColumn(
                modifier = Modifier.fillMaxSize().consumeWindowInsets(padding),
                contentPadding = padding.withInner(),
                verticalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                item {
                    Text(
                        "Composants tiers inclus dans DroidTools. Aucun ne communique avec Internet : l'application ne déclare pas cette permission.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
                item { SectionHeader("Polices") }
                items(bundledFonts, key = { it.name }) { LibraryCard(it) }
                item { SectionHeader("Bibliothèques") }
                items(libraries, key = { it.name }) { LibraryCard(it) }
            }
        }
    }
}

@Composable
private fun LibraryCard(library: Library) {
    val context = LocalContext.current
    var expanded by remember { mutableStateOf(false) }
    var text by remember { mutableStateOf<String?>(null) }
    LaunchedEffect(expanded) {
        if (expanded && text == null) text = loadAsset(context, library.licenseAsset) ?: "Texte de licence introuvable."
    }
    InfoCard {
        Text(library.name, style = MaterialTheme.typography.titleMedium)
        Text(library.artifacts, style = MaterialTheme.typography.bodySmall.copy(fontFamily = CodeFont))
        Text("Licence : ${library.license}", style = MaterialTheme.typography.bodyMedium)
        Text(library.usage, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        TextButton(onClick = { expanded = !expanded }) {
            Text(if (expanded) "Masquer le texte de la licence" else "Lire le texte de la licence")
        }
        if (expanded) {
            SelectionContainer {
                Text(text ?: "Chargement…", style = MaterialTheme.typography.bodySmall.copy(fontFamily = CodeFont))
            }
        }
    }
}
