package com.alsalamy.droidtools.core

import android.content.Context
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.preferencesDataStore
import com.alsalamy.droidtools.data.ChecklistRepository
import com.alsalamy.droidtools.data.SettingsRepository
import com.alsalamy.droidtools.forms.FormContext
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import java.io.File
import java.security.SecureRandom
import java.time.Instant
import java.time.ZoneId

private val Context.settingsStore: DataStore<Preferences> by preferencesDataStore(name = "settings")
private val Context.checklistStore: DataStore<Preferences> by preferencesDataStore(name = "checklist")

/**
 * Dépendances de l'application, créées une seule fois.
 * Tout le stockage est local (DataStore, dans l'espace privé de l'application) et exclu des sauvegardes.
 */
class AppContainer(context: Context) {

    private val appContext = context.applicationContext

    val settings = SettingsRepository(appContext.settingsStore)
    val checklist = ChecklistRepository(appContext.checklistStore)

    /** Générateur cryptographiquement sûr, partagé par tous les outils produisant de l'aléa. */
    val secureRandom: SecureRandom by lazy { SecureRandom() }

    /** Portée des écritures de réglages : elles se terminent même si l'écran qui les a demandées disparaît. */
    val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)

    fun launch(block: suspend CoroutineScope.() -> Unit) {
        scope.launch(block = block)
    }

    /** Contexte des formulaires : horloge et fuseau lus à chaque calcul (le fuseau peut changer). */
    fun newFormContext(): FormContext = FormContext(
        now = { Instant.now() },
        zone = ZoneId.systemDefault(),
        random = secureRandom,
    )

    val cacheDir: File get() = appContext.cacheDir
}

val LocalAppContainer = staticCompositionLocalOf<AppContainer> { error("AppContainer non fourni") }
