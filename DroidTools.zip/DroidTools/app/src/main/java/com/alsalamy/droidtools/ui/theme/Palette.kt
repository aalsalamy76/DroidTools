package com.alsalamy.droidtools.ui.theme

import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.ui.graphics.Color
import com.alsalamy.droidtools.domain.ToolCategory

/*
 * Palette DroidTools, générée avec material-color-utilities (schéma « Vibrant », spécification 2021,
 * couleur source indigo électrique #4F46E5), et code couleur des familles d'outils.
 * Contrastes vérifiés à la génération : texte sur tuile ≥ 5,3:1, pastilles ≥ 7:1 (WCAG AA).
 * Fichier généré : ne pas modifier les valeurs à la main.
 */

internal val LightColors = lightColorScheme(
    primary = Color(0xFF4836FF),
    onPrimary = Color(0xFFFFFFFF),
    primaryContainer = Color(0xFFE2DFFF),
    onPrimaryContainer = Color(0xFF2D00E6),
    inversePrimary = Color(0xFFC3C0FF),
    secondary = Color(0xFF65597B),
    onSecondary = Color(0xFFFFFFFF),
    secondaryContainer = Color(0xFFEADDFF),
    onSecondaryContainer = Color(0xFF4C4162),
    tertiary = Color(0xFF715381),
    onTertiary = Color(0xFFFFFFFF),
    tertiaryContainer = Color(0xFFF5D9FF),
    onTertiaryContainer = Color(0xFF583B68),
    background = Color(0xFFFCF8FF),
    onBackground = Color(0xFF1B1B25),
    surface = Color(0xFFFCF8FF),
    onSurface = Color(0xFF1B1B25),
    surfaceVariant = Color(0xFFE4E0F2),
    onSurfaceVariant = Color(0xFF464554),
    surfaceTint = Color(0xFF4836FF),
    inverseSurface = Color(0xFF302F3A),
    inverseOnSurface = Color(0xFFF2EFFE),
    error = Color(0xFFBA1A1A),
    onError = Color(0xFFFFFFFF),
    errorContainer = Color(0xFFFFDAD6),
    onErrorContainer = Color(0xFF93000A),
    outline = Color(0xFF777585),
    outlineVariant = Color(0xFFC7C4D6),
    scrim = Color(0xFF000000),
    surfaceBright = Color(0xFFFCF8FF),
    surfaceContainer = Color(0xFFF0ECFB),
    surfaceContainerHigh = Color(0xFFEAE6F5),
    surfaceContainerHighest = Color(0xFFE4E0EF),
    surfaceContainerLow = Color(0xFFF5F2FF),
    surfaceContainerLowest = Color(0xFFFFFFFF),
    surfaceDim = Color(0xFFDBD8E7),
)

internal val DarkColors = darkColorScheme(
    primary = Color(0xFFC3C0FF),
    onPrimary = Color(0xFF1D00A5),
    primaryContainer = Color(0xFF2D00E6),
    onPrimaryContainer = Color(0xFFE2DFFF),
    inversePrimary = Color(0xFF4836FF),
    secondary = Color(0xFFCFC0E8),
    onSecondary = Color(0xFF352B4B),
    secondaryContainer = Color(0xFF4C4162),
    onSecondaryContainer = Color(0xFFEADDFF),
    tertiary = Color(0xFFDEB9EF),
    onTertiary = Color(0xFF402550),
    tertiaryContainer = Color(0xFF583B68),
    onTertiaryContainer = Color(0xFFF5D9FF),
    background = Color(0xFF13121C),
    onBackground = Color(0xFFE4E0EF),
    surface = Color(0xFF13121C),
    onSurface = Color(0xFFE4E0EF),
    surfaceVariant = Color(0xFF464554),
    onSurfaceVariant = Color(0xFFC7C4D6),
    surfaceTint = Color(0xFFC3C0FF),
    inverseSurface = Color(0xFFE4E0EF),
    inverseOnSurface = Color(0xFF302F3A),
    error = Color(0xFFFFB4AB),
    onError = Color(0xFF690005),
    errorContainer = Color(0xFF93000A),
    onErrorContainer = Color(0xFFFFDAD6),
    outline = Color(0xFF918F9F),
    outlineVariant = Color(0xFF464554),
    scrim = Color(0xFF000000),
    surfaceBright = Color(0xFF393843),
    surfaceContainer = Color(0xFF1F1F29),
    surfaceContainerHigh = Color(0xFF2A2934),
    surfaceContainerHighest = Color(0xFF34343F),
    surfaceContainerLow = Color(0xFF1B1B25),
    surfaceContainerLowest = Color(0xFF0D0D17),
    surfaceDim = Color(0xFF13121C),
)

internal val LightCategoryColors: Map<ToolCategory, CategoryColors> = mapOf(
    ToolCategory.CALCULATIONS to CategoryColors(
        tile = Color(0xFF2B58FC), onTile = Color(0xFFFFFFFF),
        badge = Color(0xFFE5E7FF), onBadge = Color(0xFF002CA3), accent = Color(0xFF1349F0),
    ),
    ToolCategory.CONVERSIONS to CategoryColors(
        tile = Color(0xFFFF8D40), onTile = Color(0xFF321200),
        badge = Color(0xFFFFE3D4), onBadge = Color(0xFF632B00), accent = Color(0xFF994700),
    ),
    ToolCategory.NETWORK to CategoryColors(
        tile = Color(0xFF00758D), onTile = Color(0xFFFFFFFF),
        badge = Color(0xFFC4EFFF), onBadge = Color(0xFF004150), accent = Color(0xFF00677D),
    ),
    ToolCategory.QR to CategoryColors(
        tile = Color(0xFF00786C), onTile = Color(0xFFFFFFFF),
        badge = Color(0xFF6DFFEA), onBadge = Color(0xFF00443C), accent = Color(0xFF006B5F),
    ),
    ToolCategory.DOCUMENTS to CategoryColors(
        tile = Color(0xFFC63500), onTile = Color(0xFFFFFFFF),
        badge = Color(0xFFFFE2DA), onBadge = Color(0xFF731B00), accent = Color(0xFFB02E00),
    ),
    ToolCategory.IMAGES to CategoryColors(
        tile = Color(0xFFCA048C), onTile = Color(0xFFFFFFFF),
        badge = Color(0xFFFFE0EC), onBadge = Color(0xFF760050), accent = Color(0xFFB5007D),
    ),
    ToolCategory.TEXT_DEV to CategoryColors(
        tile = Color(0xFF007B35), onTile = Color(0xFFFFFFFF),
        badge = Color(0xFF95FFA6), onBadge = Color(0xFF00461B), accent = Color(0xFF006E2E),
    ),
    ToolCategory.SECURITY to CategoryColors(
        tile = Color(0xFFCD2727), onTile = Color(0xFFFFFFFF),
        badge = Color(0xFFFFE2DE), onBadge = Color(0xFF7D0009), accent = Color(0xFFBB171C),
    ),
    ToolCategory.SENSORS to CategoryColors(
        tile = Color(0xFF00729C), onTile = Color(0xFFFFFFFF),
        badge = Color(0xFFD1ECFF), onBadge = Color(0xFF00405A), accent = Color(0xFF00658B),
    ),
    ToolCategory.DEVICE_TESTS to CategoryColors(
        tile = Color(0xFF7657C1), onTile = Color(0xFFFFFFFF),
        badge = Color(0xFFEEE4FF), onBadge = Color(0xFF45238E), accent = Color(0xFF694BB3),
    ),
    ToolCategory.AUDIO to CategoryColors(
        tile = Color(0xFF8538F7), onTile = Color(0xFFFFFFFF),
        badge = Color(0xFFF0E3FF), onBadge = Color(0xFF4F00A6), accent = Color(0xFF7825EA),
    ),
    ToolCategory.DAILY to CategoryColors(
        tile = Color(0xFFFFB237), onTile = Color(0xFF291800),
        badge = Color(0xFFFFE4C4), onBadge = Color(0xFF543500), accent = Color(0xFF825500),
    ),
)

internal val DarkCategoryColors: Map<ToolCategory, CategoryColors> = mapOf(
    ToolCategory.CALCULATIONS to CategoryColors(
        tile = Color(0xFF2B58FC), onTile = Color(0xFFFFFFFF),
        badge = Color(0xFF0034BF), onBadge = Color(0xFFDDE1FF), accent = Color(0xFFB9C3FF),
    ),
    ToolCategory.CONVERSIONS to CategoryColors(
        tile = Color(0xFFFF8D40), onTile = Color(0xFF321200),
        badge = Color(0xFF753400), onBadge = Color(0xFFFFDBC8), accent = Color(0xFFFFB68B),
    ),
    ToolCategory.NETWORK to CategoryColors(
        tile = Color(0xFF00758D), onTile = Color(0xFFFFFFFF),
        badge = Color(0xFF004E5F), onBadge = Color(0xFFB3EBFF), accent = Color(0xFF38D7FF),
    ),
    ToolCategory.QR to CategoryColors(
        tile = Color(0xFF00786C), onTile = Color(0xFFFFFFFF),
        badge = Color(0xFF005048), onBadge = Color(0xFF46FCE5), accent = Color(0xFF00DEC9),
    ),
    ToolCategory.DOCUMENTS to CategoryColors(
        tile = Color(0xFFC63500), onTile = Color(0xFFFFFFFF),
        badge = Color(0xFF872100), onBadge = Color(0xFFFFDBD1), accent = Color(0xFFFFB5A0),
    ),
    ToolCategory.IMAGES to CategoryColors(
        tile = Color(0xFFCA048C), onTile = Color(0xFFFFFFFF),
        badge = Color(0xFF8A005F), onBadge = Color(0xFFFFD8E8), accent = Color(0xFFFFAFD5),
    ),
    ToolCategory.TEXT_DEV to CategoryColors(
        tile = Color(0xFF007B35), onTile = Color(0xFFFFFFFF),
        badge = Color(0xFF005321), onBadge = Color(0xFF85FB9B), accent = Color(0xFF68DE81),
    ),
    ToolCategory.SECURITY to CategoryColors(
        tile = Color(0xFFCD2727), onTile = Color(0xFFFFFFFF),
        badge = Color(0xFF93000D), onBadge = Color(0xFFFFDAD6), accent = Color(0xFFFFB4AC),
    ),
    ToolCategory.SENSORS to CategoryColors(
        tile = Color(0xFF00729C), onTile = Color(0xFFFFFFFF),
        badge = Color(0xFF004C6A), onBadge = Color(0xFFC4E7FF), accent = Color(0xFF7DD0FF),
    ),
    ToolCategory.DEVICE_TESTS to CategoryColors(
        tile = Color(0xFF7657C1), onTile = Color(0xFFFFFFFF),
        badge = Color(0xFF51319A), onBadge = Color(0xFFE9DDFF), accent = Color(0xFFD0BCFF),
    ),
    ToolCategory.AUDIO to CategoryColors(
        tile = Color(0xFF8538F7), onTile = Color(0xFFFFFFFF),
        badge = Color(0xFF5D00C2), onBadge = Color(0xFFEBDCFF), accent = Color(0xFFD4BBFF),
    ),
    ToolCategory.DAILY to CategoryColors(
        tile = Color(0xFFFFB237), onTile = Color(0xFF291800),
        badge = Color(0xFF633F00), onBadge = Color(0xFFFFDDB4), accent = Color(0xFFFFB952),
    ),
)
