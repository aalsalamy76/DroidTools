package com.alsalamy.droidtools.ui.tools

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.consumeWindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.SearchOff
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.Alignment
import androidx.compose.ui.draw.clip
import androidx.compose.ui.semantics.heading
import androidx.compose.ui.semantics.semantics
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import com.alsalamy.droidtools.ui.theme.colors
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.foundation.layout.size
import com.alsalamy.droidtools.core.LocalAppContainer
import com.alsalamy.droidtools.core.TextNormalizer
import com.alsalamy.droidtools.data.AppSettings
import com.alsalamy.droidtools.domain.ToolCatalog
import com.alsalamy.droidtools.domain.ToolCategory
import com.alsalamy.droidtools.domain.ToolDefinition
import com.alsalamy.droidtools.domain.ToolSearch
import com.alsalamy.droidtools.ui.components.BackButton
import com.alsalamy.droidtools.ui.components.CenteredContent
import com.alsalamy.droidtools.ui.components.EmptyState
import com.alsalamy.droidtools.ui.components.SectionHeader
import com.alsalamy.droidtools.ui.components.ToolRow
import com.alsalamy.droidtools.ui.components.withInner

private enum class SortMode { CATEGORY, ALPHABETICAL }

@Composable
fun ToolsScreen(settings: AppSettings, onOpenTool: (String) -> Unit) {
    val container = LocalAppContainer.current
    var query by rememberSaveable { mutableStateOf("") }
    var categoryName by rememberSaveable { mutableStateOf<String?>(null) }
    var favoritesOnly by rememberSaveable { mutableStateOf(false) }
    var recentsOnly by rememberSaveable { mutableStateOf(false) }
    var sortName by rememberSaveable { mutableStateOf(SortMode.CATEGORY.name) }
    val sort = SortMode.valueOf(sortName)
    val category = ToolCategory.entries.firstOrNull { it.name == categoryName }
    val focus = LocalFocusManager.current

    val filtered = remember(categoryName, favoritesOnly, recentsOnly, settings.favorites, settings.recents) {
        val base = if (recentsOnly) settings.recents.mapNotNull(ToolCatalog::find) else ToolCatalog.all
        base.filter {
            (category == null || it.category == category) &&
                (!favoritesOnly || it.id in settings.favorites)
        }
    }
    val searched = remember(query, filtered) { if (query.isBlank()) null else ToolSearch.search(query, filtered) }
    val availableCount = ToolCatalog.all.size

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Outils") },
            )
        },
    ) { padding ->
        CenteredContent {
            LazyColumn(
                modifier = Modifier.fillMaxSize().consumeWindowInsets(padding).imePadding(),
                contentPadding = padding.withInner(horizontal = 12.dp),
            ) {
                item(key = "search") {
                    OutlinedTextField(
                        value = query,
                        onValueChange = { query = it.take(100) },
                        modifier = Modifier.fillMaxWidth().padding(horizontal = 4.dp),
                        placeholder = { Text("Rechercher : wifi, pdf, ip, mot de passe…") },
                        leadingIcon = { Icon(Icons.Rounded.Search, contentDescription = null) },
                        trailingIcon = if (query.isNotEmpty()) {
                            { IconButton(onClick = { query = "" }) { Icon(Icons.Rounded.Close, contentDescription = "Effacer la recherche") } }
                        } else {
                            null
                        },
                        singleLine = true,
                        shape = MaterialTheme.shapes.extraLarge,
                        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                        keyboardActions = KeyboardActions(onSearch = { focus.clearFocus() }),
                    )
                }
                item(key = "filters") {
                    LazyRow(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        contentPadding = PaddingValues(horizontal = 4.dp, vertical = 8.dp),
                    ) {
                        item {
                            SelectableChip("Favoris", favoritesOnly) { favoritesOnly = !favoritesOnly }
                        }
                        if (settings.historyEnabled) {
                            item {
                                SelectableChip("Récents", recentsOnly) { recentsOnly = !recentsOnly }
                            }
                        }
                        item {
                            SelectableChip("Tri A → Z", sort == SortMode.ALPHABETICAL) {
                                sortName = (if (sort == SortMode.ALPHABETICAL) SortMode.CATEGORY else SortMode.ALPHABETICAL).name
                            }
                        }
                    }
                    LazyRow(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        contentPadding = PaddingValues(horizontal = 4.dp),
                    ) {
                        item { SelectableChip("Toutes", category == null) { categoryName = null } }
                        items(ToolCatalog.categories, key = { it.name }) { c ->
                            SelectableChip(c.label, category == c, c) { categoryName = if (category == c) null else c.name }
                        }
                    }
                    Text(
                        "${filtered.size} outil${if (filtered.size > 1) "s" else ""} affiché${if (filtered.size > 1) "s" else ""} sur $availableCount",
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(start = 4.dp, top = 8.dp),
                    )
                }

                val list = searched
                when {
                    list != null && list.isEmpty() -> item(key = "empty") {
                        EmptyState(Icons.Rounded.SearchOff, "Aucun outil trouvé", "Modifiez la recherche ou les filtres.")
                    }
                    list != null -> {
                        item(key = "count") { SectionHeader("${list.size} résultat${if (list.size > 1) "s" else ""}", Modifier.padding(horizontal = 4.dp)) }
                        toolItems(list, settings, onOpenTool) { id -> container.launch { container.settings.toggleFavorite(id) } }
                    }
                    filtered.isEmpty() -> item(key = "empty-filter") {
                        EmptyState(Icons.Rounded.SearchOff, "Aucun outil", "Aucun outil ne correspond à ces filtres.")
                    }
                    recentsOnly && sort == SortMode.CATEGORY -> {
                        toolItems(filtered, settings, onOpenTool) { id -> container.launch { container.settings.toggleFavorite(id) } }
                    }
                    sort == SortMode.ALPHABETICAL -> {
                        val sorted = filtered.sortedBy { TextNormalizer.normalize(it.name) }
                        toolItems(sorted, settings, onOpenTool) { id -> container.launch { container.settings.toggleFavorite(id) } }
                    }
                    else -> {
                        filtered.groupBy { it.category }.forEach { (cat, tools) ->
                            item(key = "header-${cat.name}") { CategoryHeader(cat) }
                            toolItems(tools, settings, onOpenTool) { id -> container.launch { container.settings.toggleFavorite(id) } }
                        }
                    }
                }
            }
        }
    }
}

private fun androidx.compose.foundation.lazy.LazyListScope.toolItems(
    tools: List<ToolDefinition>,
    settings: AppSettings,
    onOpenTool: (String) -> Unit,
    onToggleFavorite: (String) -> Unit,
) {
    items(tools, key = { it.id }) { tool ->
        ToolRow(
            tool = tool,
            isFavorite = tool.id in settings.favorites,
            onClick = { onOpenTool(tool.id) },
            onToggleFavorite = { onToggleFavorite(tool.id) },
        )
    }
}

/** Titre de groupe : la pastille rappelle la couleur de la famille. */
@Composable
private fun CategoryHeader(category: ToolCategory) {
    Row(
        Modifier.fillMaxWidth().padding(start = 8.dp, top = 20.dp, bottom = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(Modifier.size(width = 6.dp, height = 22.dp).clip(RoundedCornerShape(3.dp)).background(category.colors.tile))
        Spacer(Modifier.width(10.dp))
        Text(category.label, style = MaterialTheme.typography.titleLarge, modifier = Modifier.semantics { heading() })
    }
}

@Composable
private fun SelectableChip(label: String, selected: Boolean, category: ToolCategory? = null, onClick: () -> Unit) {
    val colors = category?.colors
    FilterChip(
        selected = selected,
        onClick = onClick,
        label = { Text(label) },
        colors = if (colors != null) {
            FilterChipDefaults.filterChipColors(
                selectedContainerColor = colors.tile,
                selectedLabelColor = colors.onTile,
                selectedLeadingIconColor = colors.onTile,
            )
        } else {
            FilterChipDefaults.filterChipColors()
        },
        leadingIcon = if (selected) {
            { Icon(Icons.Rounded.Check, contentDescription = null, modifier = Modifier.size(FilterChipDefaults.IconSize)) }
        } else {
            null
        },
    )
}

@Composable
fun CategoryScreen(category: ToolCategory?, settings: AppSettings, onOpenTool: (String) -> Unit, onBack: () -> Unit) {
    val container = LocalAppContainer.current
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(category?.label ?: "Catégorie introuvable") },
                navigationIcon = { BackButton(onBack) },
            )
        },
    ) { padding ->
        CenteredContent {
            LazyColumn(
                modifier = Modifier.fillMaxSize().consumeWindowInsets(padding),
                contentPadding = padding.withInner(horizontal = 12.dp),
            ) {
                if (category == null) {
                    item { EmptyState(Icons.Rounded.SearchOff, "Catégorie introuvable", "Revenez à l'accueil.") }
                    return@LazyColumn
                }
                val tools = ToolCatalog.byCategory(category)
                item(key = "intro") {
                    Text(
                        "${category.description}.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(horizontal = 4.dp, vertical = 8.dp),
                    )
                }
                // Les outils disponibles d'abord, puis ceux qui ne sont pas encore implémentés.
                toolItems(tools, settings, onOpenTool) { id ->
                    container.launch { container.settings.toggleFavorite(id) }
                }
            }
        }
    }
}
