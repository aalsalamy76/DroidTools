package com.alsalamy.droidtools.ui.form

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.alsalamy.droidtools.forms.FormContext
import com.alsalamy.droidtools.forms.FormOutcome
import com.alsalamy.droidtools.forms.FormValues
import com.alsalamy.droidtools.forms.ToolForm
import com.alsalamy.droidtools.forms.Trigger
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * État d'un outil décrit par formulaire. Les calculs s'exécutent hors du thread principal ;
 * les valeurs saisies restent en mémoire et ne sont jamais enregistrées.
 */
class FormViewModel(
    private val form: ToolForm,
    private val contextProvider: () -> FormContext,
) : ViewModel() {

    private val _values = MutableStateFlow(FormValues.defaults(form))
    val values: StateFlow<FormValues> = _values.asStateFlow()

    private val _outcome = MutableStateFlow<FormOutcome?>(null)
    val outcome: StateFlow<FormOutcome?> = _outcome.asStateFlow()

    private val _computing = MutableStateFlow(false)
    val computing: StateFlow<Boolean> = _computing.asStateFlow()

    private var actionJob: Job? = null

    init {
        when (form.trigger) {
            Trigger.LIVE -> viewModelScope.launch {
                var first = true
                // collectLatest annule le calcul précédent à chaque frappe : effet « anti-rebond ».
                _values.collectLatest { v ->
                    if (!first) delay(DEBOUNCE_MS)
                    first = false
                    evaluate(v)
                }
            }
            Trigger.ON_ACTION_AND_OPEN -> runAction()
            Trigger.ON_ACTION -> Unit
        }
        form.refreshEveryMillis?.let { period ->
            viewModelScope.launch {
                while (isActive) {
                    // Aligné sur la seconde pour un affichage d'horloge régulier.
                    delay(period - System.currentTimeMillis() % period)
                    if (form.trigger == Trigger.LIVE || _outcome.value is FormOutcome.Success) evaluate(_values.value)
                }
            }
        }
    }

    fun update(key: String, value: String) {
        _values.value = _values.value.with(key, value)
    }

    fun runAction() {
        actionJob?.cancel()
        actionJob = viewModelScope.launch { evaluate(_values.value) }
    }

    private suspend fun evaluate(values: FormValues) {
        _computing.value = true
        try {
            val result = withContext(Dispatchers.Default) {
                try {
                    form.evaluate(values, contextProvider())
                } catch (e: CancellationException) {
                    throw e
                } catch (e: Exception) {
                    // Filet de sécurité : jamais de trace technique affichée à l'utilisateur.
                    FormOutcome.Invalid(UNEXPECTED_ERROR)
                } catch (e: StackOverflowError) {
                    FormOutcome.Invalid("Entrée trop complexe.")
                } catch (e: OutOfMemoryError) {
                    FormOutcome.Invalid("Entrée trop volumineuse pour être traitée.")
                }
            }
            _outcome.value = result
        } finally {
            _computing.value = false
        }
    }

    companion object {
        const val DEBOUNCE_MS = 150L
        const val UNEXPECTED_ERROR = "Une erreur inattendue est survenue avec ces valeurs. Vérifiez la saisie et réessayez."
    }
}
