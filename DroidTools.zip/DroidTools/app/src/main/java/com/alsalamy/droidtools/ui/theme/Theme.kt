package com.alsalamy.droidtools.ui.theme

import android.os.Build
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.ColorScheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.Typography
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.ReadOnlyComposable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.alsalamy.droidtools.R
import com.alsalamy.droidtools.domain.ToolCategory

// ------------------------------------------------------------------ Polices (SIL Open Font License 1.1)

/** Titres : Bricolage Grotesque, un nom qui convient à une caisse à outils. */
val Bricolage = FontFamily(
    Font(R.font.bricolage_grotesque_semibold, FontWeight.SemiBold),
    Font(R.font.bricolage_grotesque_bold, FontWeight.Bold),
    Font(R.font.bricolage_grotesque_extrabold, FontWeight.ExtraBold),
)

/** Texte : Atkinson Hyperlegible Next, dessinée pour la lisibilité (Braille Institute). */
val Atkinson = FontFamily(
    Font(R.font.atkinson_next_regular, FontWeight.Normal),
    Font(R.font.atkinson_next_medium, FontWeight.Medium),
    Font(R.font.atkinson_next_semibold, FontWeight.SemiBold),
    Font(R.font.atkinson_next_bold, FontWeight.Bold),
)

/** Codes, mots de passe, empreintes : chasse fixe, 0/O et 1/l/I bien distincts. */
val CodeFont = FontFamily(
    Font(R.font.atkinson_mono_regular, FontWeight.Normal),
    Font(R.font.atkinson_mono_bold, FontWeight.Bold),
)

private fun TextStyle.styled(family: FontFamily, weight: FontWeight, spacing: Float? = null) =
    copy(fontFamily = family, fontWeight = weight, letterSpacing = spacing?.sp ?: letterSpacing)

private val DroidTypography: Typography = Typography().let { base ->
    Typography(
        displayLarge = base.displayLarge.styled(Bricolage, FontWeight.ExtraBold, -1.5f),
        displayMedium = base.displayMedium.styled(Bricolage, FontWeight.ExtraBold, -1f),
        displaySmall = base.displaySmall.styled(Bricolage, FontWeight.ExtraBold, -0.75f),
        headlineLarge = base.headlineLarge.styled(Bricolage, FontWeight.Bold, -0.5f),
        headlineMedium = base.headlineMedium.styled(Bricolage, FontWeight.Bold, -0.25f),
        headlineSmall = base.headlineSmall.styled(Bricolage, FontWeight.Bold),
        titleLarge = base.titleLarge.styled(Bricolage, FontWeight.Bold),
        titleMedium = base.titleMedium.styled(Atkinson, FontWeight.SemiBold),
        titleSmall = base.titleSmall.styled(Atkinson, FontWeight.SemiBold),
        bodyLarge = base.bodyLarge.styled(Atkinson, FontWeight.Normal),
        bodyMedium = base.bodyMedium.styled(Atkinson, FontWeight.Normal),
        bodySmall = base.bodySmall.styled(Atkinson, FontWeight.Normal),
        labelLarge = base.labelLarge.styled(Atkinson, FontWeight.SemiBold),
        labelMedium = base.labelMedium.styled(Atkinson, FontWeight.Medium),
        labelSmall = base.labelSmall.styled(Atkinson, FontWeight.SemiBold),
    )
}

// ------------------------------------------------------------------ Couleurs

/** Code couleur d'une famille d'outils. */
@Immutable
data class CategoryColors(
    /** Tuile pleine (accueil, en-tête d'outil, résultat principal). */
    val tile: Color,
    val onTile: Color,
    /** Pastille d'icône sur fond clair ou sombre. */
    val badge: Color,
    val onBadge: Color,
    /** Texte ou trait coloré posé directement sur la surface. */
    val accent: Color,
)

/** Couleurs d'avertissement (ambre), absentes du schéma Material 3 standard. */
@Immutable
data class ExtraColors(val warningContainer: Color, val onWarningContainer: Color)

private val LightExtra = ExtraColors(warningContainer = Color(0xFFFFE08A), onWarningContainer = Color(0xFF261A00))
private val DarkExtra = ExtraColors(warningContainer = Color(0xFF574500), onWarningContainer = Color(0xFFFFE08A))

val LocalExtraColors = staticCompositionLocalOf { LightExtra }
val LocalDarkTheme = staticCompositionLocalOf { false }

/** Couleurs de la famille de l'outil, adaptées au thème clair ou sombre. */
val ToolCategory.colors: CategoryColors
    @Composable
    @ReadOnlyComposable
    get() = (if (LocalDarkTheme.current) DarkCategoryColors else LightCategoryColors).getValue(this)

private val DroidShapes = Shapes(
    extraSmall = RoundedCornerShape(8.dp),
    small = RoundedCornerShape(12.dp),
    medium = RoundedCornerShape(18.dp),
    large = RoundedCornerShape(26.dp),
    extraLarge = RoundedCornerShape(34.dp),
)

@Composable
fun DroidToolsTheme(
    darkTheme: Boolean,
    dynamicColor: Boolean,
    content: @Composable () -> Unit,
) {
    val context = LocalContext.current
    val colors: ColorScheme = when {
        dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S ->
            if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
        darkTheme -> DarkColors
        else -> LightColors
    }
    CompositionLocalProvider(
        LocalExtraColors provides if (darkTheme) DarkExtra else LightExtra,
        LocalDarkTheme provides darkTheme,
    ) {
        MaterialTheme(colorScheme = colors, typography = DroidTypography, shapes = DroidShapes, content = content)
    }
}
