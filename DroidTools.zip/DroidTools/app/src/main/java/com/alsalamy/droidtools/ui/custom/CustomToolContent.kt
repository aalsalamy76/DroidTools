package com.alsalamy.droidtools.ui.custom

import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.runtime.Composable
import com.alsalamy.droidtools.domain.ToolDefinition
import com.alsalamy.droidtools.ui.tool.NotImplementedContent

/** Écrans dédiés des outils qui ne se résument pas à un formulaire (voir ToolForms.customScreens). */
@Composable
fun CustomToolContent(tool: ToolDefinition, padding: PaddingValues) {
    when (tool.id) {
        "calculator" -> CalculatorContent(scientific = false, padding = padding)
        "scientific_calculator" -> CalculatorContent(scientific = true, padding = padding)
        "file_hash" -> FileHashContent(padding)
        "stopwatch" -> StopwatchContent(padding)
        "timer" -> TimerContent(padding)
        "checklist" -> ChecklistContent(padding)
        else -> NotImplementedContent(tool, padding)
    }
}
