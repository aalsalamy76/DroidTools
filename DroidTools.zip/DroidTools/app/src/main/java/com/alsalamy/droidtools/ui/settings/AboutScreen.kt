package com.alsalamy.droidtools.ui.settings

import android.content.ActivityNotFoundException
import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.consumeWindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.OpenInNew
import androidx.compose.material.icons.rounded.Gavel
import androidx.compose.material.icons.rounded.Policy
import androidx.compose.material.icons.rounded.Shield
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.semantics.heading
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.alsalamy.droidtools.core.AppInfo
import com.alsalamy.droidtools.domain.ToolCatalog
import com.alsalamy.droidtools.domain.ToolStatus
import com.alsalamy.droidtools.ui.components.BackButton
import com.alsalamy.droidtools.ui.components.CenteredContent
import com.alsalamy.droidtools.ui.components.DroidToolsLogo
import com.alsalamy.droidtools.ui.components.InfoCard
import com.alsalamy.droidtools.ui.components.LocalMessenger
import com.alsalamy.droidtools.ui.components.SectionHeader
import com.alsalamy.droidtools.ui.components.withInner

private const val DEVELOPER = "Abdullah AL-SALAMY"
private const val LINKEDIN_URL = "https://www.linkedin.com/in/abdullah-a-2982451a6"

@Composable
fun AboutScreen(
    onBack: () -> Unit,
    onOpenPrivacyCenter: () -> Unit,
    onOpenLicenses: () -> Unit,
    onOpenPrivacyPolicy: () -> Unit,
) {
    val context = LocalContext.current
    val messenger = LocalMessenger.current
    val version = remember { AppInfo.version(context) }
    val counts = remember { ToolStatus.entries.associateWith { status -> ToolCatalog.all.count { it.status == status } } }

    Scaffold(topBar = { TopAppBar(title = { Text("À propos") }, navigationIcon = { BackButton(onBack) }) }) { padding ->
        CenteredContent {
            Column(
                Modifier.fillMaxSize().consumeWindowInsets(padding).verticalScroll(rememberScrollState()).padding(padding.withInner()),
                verticalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                Column(Modifier.fillMaxWidth().padding(vertical = 16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    DroidToolsLogo(size = 88.dp)
                    Text(
                        "DroidTools",
                        style = MaterialTheme.typography.headlineMedium,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(top = 12.dp).semantics { heading() },
                    )
                    Text("Ultimate tools. Private by design.", style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.primary)
                    Text("Tous vos outils. Une seule application.", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text("Version ${version.name} (${version.code})", style = MaterialTheme.typography.labelLarge, modifier = Modifier.padding(top = 8.dp))
                }

                SectionHeader("À propos")
                InfoCard {
                    Text(
                        "DroidTools rassemble des utilitaires pratiques (calculs, conversions, texte, développement, réseau, sécurité, vie quotidienne) " +
                            "dans une seule application, en traitant vos données localement.",
                        style = MaterialTheme.typography.bodyMedium,
                    )
                    Text(
                        "Cette version propose ${ToolCatalog.all.size} outils, tous utilisables hors ligne. " +
                            "${counts[ToolStatus.PARTIAL]} d'entre eux ont des limites connues, indiquées dans leur fiche.",
                        style = MaterialTheme.typography.bodyMedium,
                    )
                }

                SectionHeader("Développeur")
                InfoCard {
                    Text(DEVELOPER, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                    SelectionContainer {
                        Text("LinkedIn : $LINKEDIN_URL", style = MaterialTheme.typography.bodyMedium)
                    }
                    FilledTonalButton(
                        onClick = {
                            // Ouverture uniquement sur action explicite, dans le navigateur de l'utilisateur.
                            try {
                                context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(LINKEDIN_URL)))
                            } catch (e: ActivityNotFoundException) {
                                messenger.show("Aucune application ne peut ouvrir ce lien.")
                            }
                        },
                        modifier = Modifier.heightIn(min = 48.dp),
                    ) {
                        Icon(Icons.AutoMirrored.Rounded.OpenInNew, contentDescription = null)
                        Spacer(Modifier.width(8.dp))
                        Text("Ouvrir le profil LinkedIn")
                    }
                    Text(
                        "Le lien s'ouvre dans votre navigateur, uniquement si vous touchez ce bouton. DroidTools lui-même n'a pas accès à Internet.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }

                SectionHeader("Informations")
                NavRow(Icons.Rounded.Shield, "Confidentialité", "Centre de confidentialité et de sécurité", onOpenPrivacyCenter)
                NavRow(Icons.Rounded.Gavel, "Licences open source", "Bibliothèques tierces utilisées", onOpenLicenses)
                NavRow(Icons.Rounded.Policy, "Politique de confidentialité", null, onOpenPrivacyPolicy)
                InfoCard {
                    Text("Version", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
                    Text(
                        "Version ${version.name} · code ${version.code}\n" +
                            "Identifiant : ${context.packageName}\n" +
                            "Android 8.0 (API 26) minimum",
                        style = MaterialTheme.typography.bodyMedium,
                    )
                }
            }
        }
    }
}
