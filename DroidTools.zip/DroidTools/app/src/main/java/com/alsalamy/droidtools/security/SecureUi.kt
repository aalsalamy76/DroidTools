package com.alsalamy.droidtools.security

import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.ContextWrapper
import android.os.Build
import android.os.PersistableBundle
import android.view.WindowManager
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import com.alsalamy.droidtools.ui.components.LocalMessenger

tailrec fun Context.findActivity(): Activity? = when (this) {
    is Activity -> this
    is ContextWrapper -> baseContext.findActivity()
    else -> null
}

/**
 * Copie dans le presse-papiers, uniquement sur action de l'utilisateur.
 * Les valeurs sensibles sont marquées comme telles : Android 13+ masque alors leur aperçu.
 */
object SecureClipboard {
    /** Au-delà, la copie échoue (limite des transactions Binder) : on prévient plutôt que de planter. */
    const val MAX_COPY_CHARS = 400_000

    // Valeur de ClipDescription.EXTRA_IS_SENSITIVE (constante API 33, comprise par Android 13+ et ignorée avant).
    private const val EXTRA_IS_SENSITIVE = "android.content.extra.IS_SENSITIVE"

    fun copy(context: Context, label: String, text: String, sensitive: Boolean): Boolean {
        if (text.length > MAX_COPY_CHARS) return false
        val manager = context.getSystemService(ClipboardManager::class.java) ?: return false
        val clip = ClipData.newPlainText(label, text)
        if (sensitive) {
            clip.description.extras = PersistableBundle().apply { putBoolean(EXTRA_IS_SENSITIVE, true) }
        }
        return try {
            manager.setPrimaryClip(clip)
            true
        } catch (e: RuntimeException) {
            false
        }
    }
}

/** Action de copie avec retour haptique et message de confirmation. */
@Composable
fun rememberCopyAction(): (label: String, text: String, sensitive: Boolean) -> Unit {
    val context = LocalContext.current
    val messenger = LocalMessenger.current
    val haptic = LocalHapticFeedback.current
    return remember(context, messenger, haptic) {
        { label, text, sensitive ->
            if (SecureClipboard.copy(context, label, text, sensitive)) {
                haptic.performHapticFeedback(HapticFeedbackType.ContextClick)
                when {
                    sensitive -> messenger.show("Copié. Collez-le où vous en avez besoin, puis ne le laissez pas dans le presse-papiers.")
                    // Android 13+ affiche déjà sa propre confirmation de copie.
                    Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU -> messenger.show("« $label » copié.")
                }
            } else {
                messenger.show("Copie impossible : texte trop volumineux pour le presse-papiers.")
            }
        }
    }
}

/** Compteur partagé : l'écran reste protégé tant qu'au moins un écran sensible est affiché. */
private object SecureFlagCounter {
    var count = 0
}

/**
 * Bloque captures d'écran, enregistrement d'écran et aperçu dans les applications récentes
 * (FLAG_SECURE) tant que l'écran appelant est affiché.
 */
@Composable
fun SecureScreenEffect() {
    val activity = LocalContext.current.findActivity()
    if (activity != null) {
        DisposableEffect(activity) {
            SecureFlagCounter.count++
            activity.window.addFlags(WindowManager.LayoutParams.FLAG_SECURE)
            onDispose {
                SecureFlagCounter.count = (SecureFlagCounter.count - 1).coerceAtLeast(0)
                if (SecureFlagCounter.count == 0) activity.window.clearFlags(WindowManager.LayoutParams.FLAG_SECURE)
            }
        }
    }
}
