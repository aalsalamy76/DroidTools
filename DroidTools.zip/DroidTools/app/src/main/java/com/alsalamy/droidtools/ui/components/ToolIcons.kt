package com.alsalamy.droidtools.ui.components

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.InsertDriveFile
import androidx.compose.material.icons.automirrored.rounded.MergeType
import androidx.compose.material.icons.automirrored.rounded.RotateRight
import androidx.compose.material.icons.rounded.AccessTime
import androidx.compose.material.icons.rounded.Air
import androidx.compose.material.icons.rounded.Architecture
import androidx.compose.material.icons.rounded.AspectRatio
import androidx.compose.material.icons.rounded.Audiotrack
import androidx.compose.material.icons.rounded.AvTimer
import androidx.compose.material.icons.rounded.Balance
import androidx.compose.material.icons.rounded.BarChart
import androidx.compose.material.icons.rounded.BatteryFull
import androidx.compose.material.icons.rounded.Bolt
import androidx.compose.material.icons.rounded.Cake
import androidx.compose.material.icons.rounded.Calculate
import androidx.compose.material.icons.rounded.Casino
import androidx.compose.material.icons.rounded.Checklist
import androidx.compose.material.icons.rounded.CleaningServices
import androidx.compose.material.icons.rounded.Code
import androidx.compose.material.icons.rounded.Colorize
import androidx.compose.material.icons.rounded.Compare
import androidx.compose.material.icons.rounded.Compress
import androidx.compose.material.icons.rounded.ContactPage
import androidx.compose.material.icons.rounded.ContentCut
import androidx.compose.material.icons.rounded.Crop
import androidx.compose.material.icons.rounded.DataObject
import androidx.compose.material.icons.rounded.Description
import androidx.compose.material.icons.rounded.Devices
import androidx.compose.material.icons.rounded.Dns
import androidx.compose.material.icons.rounded.DocumentScanner
import androidx.compose.material.icons.rounded.EnhancedEncryption
import androidx.compose.material.icons.rounded.Event
import androidx.compose.material.icons.rounded.Explore
import androidx.compose.material.icons.rounded.FiberManualRecord
import androidx.compose.material.icons.rounded.FilterAlt
import androidx.compose.material.icons.rounded.FindReplace
import androidx.compose.material.icons.rounded.Fingerprint
import androidx.compose.material.icons.rounded.Functions
import androidx.compose.material.icons.rounded.GraphicEq
import androidx.compose.material.icons.rounded.Group
import androidx.compose.material.icons.rounded.Hearing
import androidx.compose.material.icons.rounded.HideImage
import androidx.compose.material.icons.rounded.History
import androidx.compose.material.icons.rounded.HorizontalRule
import androidx.compose.material.icons.rounded.HourglassTop
import androidx.compose.material.icons.rounded.Http
import androidx.compose.material.icons.rounded.Hub
import androidx.compose.material.icons.rounded.Image
import androidx.compose.material.icons.rounded.Info
import androidx.compose.material.icons.rounded.Key
import androidx.compose.material.icons.rounded.Lan
import androidx.compose.material.icons.rounded.LightMode
import androidx.compose.material.icons.rounded.Link
import androidx.compose.material.icons.rounded.LocalDrink
import androidx.compose.material.icons.rounded.LocalOffer
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.Mic
import androidx.compose.material.icons.rounded.MyLocation
import androidx.compose.material.icons.rounded.NetworkCheck
import androidx.compose.material.icons.rounded.Numbers
import androidx.compose.material.icons.rounded.Palette
import androidx.compose.material.icons.rounded.Password
import androidx.compose.material.icons.rounded.Pattern
import androidx.compose.material.icons.rounded.Percent
import androidx.compose.material.icons.rounded.PhoneAndroid
import androidx.compose.material.icons.rounded.PictureAsPdf
import androidx.compose.material.icons.rounded.Pin
import androidx.compose.material.icons.rounded.PlayCircle
import androidx.compose.material.icons.rounded.Power
import androidx.compose.material.icons.rounded.QrCode
import androidx.compose.material.icons.rounded.QrCodeScanner
import androidx.compose.material.icons.rounded.Receipt
import androidx.compose.material.icons.rounded.RecordVoiceOver
import androidx.compose.material.icons.rounded.Reorder
import androidx.compose.material.icons.rounded.Router
import androidx.compose.material.icons.rounded.Scale
import androidx.compose.material.icons.rounded.Schedule
import androidx.compose.material.icons.rounded.Sensors
import androidx.compose.material.icons.rounded.Shield
import androidx.compose.material.icons.rounded.Shuffle
import androidx.compose.material.icons.rounded.SignalCellularAlt
import androidx.compose.material.icons.rounded.Smartphone
import androidx.compose.material.icons.rounded.SortByAlpha
import androidx.compose.material.icons.rounded.Speaker
import androidx.compose.material.icons.rounded.Speed
import androidx.compose.material.icons.rounded.Splitscreen
import androidx.compose.material.icons.rounded.SquareFoot
import androidx.compose.material.icons.rounded.Storage
import androidx.compose.material.icons.rounded.Straighten
import androidx.compose.material.icons.rounded.SwapHoriz
import androidx.compose.material.icons.rounded.SwapVert
import androidx.compose.material.icons.rounded.Tag
import androidx.compose.material.icons.rounded.TextFields
import androidx.compose.material.icons.rounded.TextFormat
import androidx.compose.material.icons.rounded.Thermostat
import androidx.compose.material.icons.rounded.Timer
import androidx.compose.material.icons.rounded.Today
import androidx.compose.material.icons.rounded.Toll
import androidx.compose.material.icons.rounded.TouchApp
import androidx.compose.material.icons.rounded.Translate
import androidx.compose.material.icons.rounded.Vibration
import androidx.compose.material.icons.rounded.ViewWeek
import androidx.compose.material.icons.rounded.Wifi
import androidx.compose.material.icons.rounded.ZoomIn
import androidx.compose.ui.graphics.vector.ImageVector
import com.alsalamy.droidtools.domain.ToolIcon

/** Correspondance entre les icônes symboliques du catalogue et les icônes Material (style arrondi). */
fun ToolIcon.vector(): ImageVector = when (this) {
    ToolIcon.CALCULATE -> Icons.Rounded.Calculate
    ToolIcon.FUNCTIONS -> Icons.Rounded.Functions
    ToolIcon.PERCENT -> Icons.Rounded.Percent
    ToolIcon.RECEIPT -> Icons.Rounded.Receipt
    ToolIcon.OFFER -> Icons.Rounded.LocalOffer
    ToolIcon.BALANCE -> Icons.Rounded.Balance
    ToolIcon.GROUP -> Icons.Rounded.Group
    ToolIcon.CHART -> Icons.Rounded.BarChart
    ToolIcon.COMPARE -> Icons.Rounded.Compare
    ToolIcon.RULER -> Icons.Rounded.Straighten
    ToolIcon.AREA -> Icons.Rounded.SquareFoot
    ToolIcon.VOLUME -> Icons.Rounded.LocalDrink
    ToolIcon.MASS -> Icons.Rounded.Scale
    ToolIcon.TEMPERATURE -> Icons.Rounded.Thermostat
    ToolIcon.SPEED -> Icons.Rounded.Speed
    ToolIcon.PRESSURE -> Icons.Rounded.Compress
    ToolIcon.ENERGY -> Icons.Rounded.Bolt
    ToolIcon.POWER -> Icons.Rounded.Power
    ToolIcon.TIME -> Icons.Rounded.Schedule
    ToolIcon.ANGLE -> Icons.Rounded.Architecture
    ToolIcon.STORAGE -> Icons.Rounded.Storage
    ToolIcon.NUMBERS -> Icons.Rounded.Numbers
    ToolIcon.SWAP -> Icons.Rounded.SwapHoriz
    ToolIcon.WIFI -> Icons.Rounded.Wifi
    ToolIcon.SIGNAL -> Icons.Rounded.SignalCellularAlt
    ToolIcon.LAN -> Icons.Rounded.Lan
    ToolIcon.ROUTER -> Icons.Rounded.Router
    ToolIcon.DNS -> Icons.Rounded.Dns
    ToolIcon.NETWORK_CHECK -> Icons.Rounded.NetworkCheck
    ToolIcon.HUB -> Icons.Rounded.Hub
    ToolIcon.HTTP -> Icons.Rounded.Http
    ToolIcon.LOCK -> Icons.Rounded.Lock
    ToolIcon.DEVICES -> Icons.Rounded.Devices
    ToolIcon.QR_CODE -> Icons.Rounded.QrCode
    ToolIcon.QR_SCAN -> Icons.Rounded.QrCodeScanner
    ToolIcon.BARCODE -> Icons.Rounded.ViewWeek
    ToolIcon.HISTORY -> Icons.Rounded.History
    ToolIcon.CONTACT -> Icons.Rounded.ContactPage
    ToolIcon.LINK -> Icons.Rounded.Link
    ToolIcon.DOCUMENT_SCAN -> Icons.Rounded.DocumentScanner
    ToolIcon.PDF -> Icons.Rounded.PictureAsPdf
    ToolIcon.MERGE -> Icons.AutoMirrored.Rounded.MergeType
    ToolIcon.SPLIT -> Icons.Rounded.Splitscreen
    ToolIcon.CUT -> Icons.Rounded.ContentCut
    ToolIcon.REORDER -> Icons.Rounded.Reorder
    ToolIcon.ROTATE -> Icons.AutoMirrored.Rounded.RotateRight
    ToolIcon.COMPRESS -> Icons.Rounded.Compress
    ToolIcon.TEXT_SNIPPET -> Icons.Rounded.Description
    ToolIcon.IMAGE -> Icons.Rounded.Image
    ToolIcon.RESIZE -> Icons.Rounded.AspectRatio
    ToolIcon.CROP -> Icons.Rounded.Crop
    ToolIcon.COLORIZE -> Icons.Rounded.Colorize
    ToolIcon.PALETTE -> Icons.Rounded.Palette
    ToolIcon.INFO -> Icons.Rounded.Info
    ToolIcon.HIDE_IMAGE -> Icons.Rounded.HideImage
    ToolIcon.ZOOM -> Icons.Rounded.ZoomIn
    ToolIcon.CODE -> Icons.Rounded.Code
    ToolIcon.TEXT_FIELDS -> Icons.Rounded.TextFields
    ToolIcon.CASE -> Icons.Rounded.TextFormat
    ToolIcon.CLEAN -> Icons.Rounded.CleaningServices
    ToolIcon.FILTER -> Icons.Rounded.FilterAlt
    ToolIcon.SORT -> Icons.Rounded.SortByAlpha
    ToolIcon.REVERSE -> Icons.Rounded.SwapVert
    ToolIcon.FIND_REPLACE -> Icons.Rounded.FindReplace
    ToolIcon.DATA_OBJECT -> Icons.Rounded.DataObject
    ToolIcon.REGEX -> Icons.Rounded.Pattern
    ToolIcon.UNICODE -> Icons.Rounded.Translate
    ToolIcon.CLOCK -> Icons.Rounded.AccessTime
    ToolIcon.FINGERPRINT -> Icons.Rounded.Fingerprint
    ToolIcon.KEY -> Icons.Rounded.Key
    ToolIcon.SHIELD -> Icons.Rounded.Shield
    ToolIcon.PASSWORD -> Icons.Rounded.Password
    ToolIcon.PIN -> Icons.Rounded.Pin
    ToolIcon.DICE -> Icons.Rounded.Casino
    ToolIcon.HASH -> Icons.Rounded.Tag
    ToolIcon.VAULT -> Icons.Rounded.EnhancedEncryption
    ToolIcon.FILE -> Icons.AutoMirrored.Rounded.InsertDriveFile
    ToolIcon.SENSORS -> Icons.Rounded.Sensors
    ToolIcon.LEVEL -> Icons.Rounded.HorizontalRule
    ToolIcon.COMPASS -> Icons.Rounded.Explore
    ToolIcon.VIBRATION -> Icons.Rounded.Vibration
    ToolIcon.LIGHT -> Icons.Rounded.LightMode
    ToolIcon.BAROMETER -> Icons.Rounded.Air
    ToolIcon.MIC -> Icons.Rounded.Mic
    ToolIcon.GPS -> Icons.Rounded.MyLocation
    ToolIcon.PHONE -> Icons.Rounded.PhoneAndroid
    ToolIcon.BATTERY -> Icons.Rounded.BatteryFull
    ToolIcon.SCREEN -> Icons.Rounded.Smartphone
    ToolIcon.TOUCH -> Icons.Rounded.TouchApp
    ToolIcon.SPEAKER -> Icons.Rounded.Speaker
    ToolIcon.AUDIO -> Icons.Rounded.Audiotrack
    ToolIcon.RECORD -> Icons.Rounded.FiberManualRecord
    ToolIcon.SPEECH -> Icons.Rounded.RecordVoiceOver
    ToolIcon.TTS -> Icons.Rounded.Hearing
    ToolIcon.TONE -> Icons.Rounded.GraphicEq
    ToolIcon.PLAY -> Icons.Rounded.PlayCircle
    ToolIcon.TODAY -> Icons.Rounded.Today
    ToolIcon.STOPWATCH -> Icons.Rounded.Timer
    ToolIcon.TIMER -> Icons.Rounded.AvTimer
    ToolIcon.HOURGLASS -> Icons.Rounded.HourglassTop
    ToolIcon.EVENT -> Icons.Rounded.Event
    ToolIcon.CAKE -> Icons.Rounded.Cake
    ToolIcon.SHUFFLE -> Icons.Rounded.Shuffle
    ToolIcon.COIN -> Icons.Rounded.Toll
    ToolIcon.CHECKLIST -> Icons.Rounded.Checklist
}
