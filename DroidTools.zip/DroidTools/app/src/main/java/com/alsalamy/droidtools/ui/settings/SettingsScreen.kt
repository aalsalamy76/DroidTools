package com.alsalamy.droidtools.ui.settings

import android.os.Build
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.consumeWindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.selection.toggleable
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Gavel
import androidx.compose.material.icons.rounded.History
import androidx.compose.material.icons.rounded.Info
import androidx.compose.material.icons.rounded.Palette
import androidx.compose.material.icons.rounded.Policy
import androidx.compose.material.icons.rounded.Shield
import androidx.compose.material3.Icon
import androidx.compose.material3.ListItem
import androidx.compose.material3.ListItemDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SegmentedButton
import androidx.compose.material3.SegmentedButtonDefaults
import androidx.compose.material3.SingleChoiceSegmentedButtonRow
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.unit.dp
import com.alsalamy.droidtools.core.LocalAppContainer
import com.alsalamy.droidtools.data.AppSettings
import com.alsalamy.droidtools.data.ThemeMode
import com.alsalamy.droidtools.ui.components.CenteredContent
import com.alsalamy.droidtools.ui.components.SectionHeader
import com.alsalamy.droidtools.ui.components.withInner

@Composable
fun SettingsScreen(
    settings: AppSettings,
    onOpenPrivacyCenter: () -> Unit,
    onOpenAbout: () -> Unit,
    onOpenLicenses: () -> Unit,
    onOpenPrivacyPolicy: () -> Unit,
) {
    val container = LocalAppContainer.current
    val dynamicAvailable = Build.VERSION.SDK_INT >= Build.VERSION_CODES.S
    Scaffold(topBar = { TopAppBar(title = { Text("Réglages") }) }) { padding ->
        CenteredContent {
            Column(
                Modifier.fillMaxSize().consumeWindowInsets(padding).verticalScroll(rememberScrollState()).padding(padding.withInner()),
            ) {
                SectionHeader("Apparence")
                Text("Thème", style = MaterialTheme.typography.bodyLarge, modifier = Modifier.padding(bottom = 8.dp))
                SingleChoiceSegmentedButtonRow(Modifier.fillMaxWidth()) {
                    ThemeMode.entries.forEachIndexed { index, mode ->
                        SegmentedButton(
                            selected = settings.themeMode == mode,
                            onClick = { container.launch { container.settings.setThemeMode(mode) } },
                            shape = SegmentedButtonDefaults.itemShape(index = index, count = ThemeMode.entries.size),
                        ) { Text(mode.label) }
                    }
                }
                SwitchRow(
                    icon = Icons.Rounded.Palette,
                    title = "Couleurs dynamiques",
                    subtitle = if (dynamicAvailable) "Utiliser les couleurs de votre fond d'écran (Material You)" else "Disponible à partir d'Android 12",
                    checked = settings.dynamicColor && dynamicAvailable,
                    enabled = dynamicAvailable,
                    onChange = { enabled -> container.launch { container.settings.setDynamicColor(enabled) } },
                )

                SectionHeader("Confidentialité")
                NavRow(Icons.Rounded.Shield, "Confidentialité et sécurité", "Permissions, données stockées, effacement", onOpenPrivacyCenter)
                SwitchRow(
                    icon = Icons.Rounded.History,
                    title = "Mémoriser les outils récents",
                    subtitle = "Seuls les noms d'outils ouverts sont gardés sur l'appareil, jamais ce que vous saisissez",
                    checked = settings.historyEnabled,
                    enabled = true,
                    onChange = { enabled -> container.launch { container.settings.setHistoryEnabled(enabled) } },
                )

                SectionHeader("Informations")
                NavRow(Icons.Rounded.Info, "À propos de DroidTools", "Version, développeur", onOpenAbout)
                NavRow(Icons.Rounded.Gavel, "Licences open source", "Bibliothèques utilisées", onOpenLicenses)
                NavRow(Icons.Rounded.Policy, "Politique de confidentialité", "Ce que fait DroidTools de vos données", onOpenPrivacyPolicy)
            }
        }
    }
}

@Composable
internal fun NavRow(icon: ImageVector, title: String, subtitle: String?, onClick: () -> Unit) {
    ListItem(
        headlineContent = { Text(title) },
        supportingContent = subtitle?.let { text -> { Text(text) } },
        leadingContent = { Icon(icon, contentDescription = null) },
        colors = ListItemDefaults.colors(containerColor = Color.Transparent),
        modifier = Modifier.clip(MaterialTheme.shapes.medium).clickable(onClick = onClick),
    )
}

@Composable
internal fun SwitchRow(icon: ImageVector, title: String, subtitle: String?, checked: Boolean, enabled: Boolean, onChange: (Boolean) -> Unit) {
    ListItem(
        headlineContent = { Text(title) },
        supportingContent = subtitle?.let { text -> { Text(text) } },
        leadingContent = { Icon(icon, contentDescription = null) },
        trailingContent = { Switch(checked = checked, onCheckedChange = null, enabled = enabled) },
        colors = ListItemDefaults.colors(containerColor = Color.Transparent),
        modifier = Modifier
            .clip(MaterialTheme.shapes.medium)
            .toggleable(value = checked, enabled = enabled, role = Role.Switch, onValueChange = onChange),
    )
}
