package com.alsalamy.droidtools

import android.app.Application
import com.alsalamy.droidtools.core.AppContainer

class DroidToolsApplication : Application() {

    lateinit var container: AppContainer
        private set

    override fun onCreate() {
        super.onCreate()
        container = AppContainer(this)
    }
}
