package com.alsalamy.droidtools.navigation

import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.consumeWindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Apps
import androidx.compose.material.icons.rounded.Home
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material.icons.rounded.Star
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.dp
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.alsalamy.droidtools.data.AppSettings
import com.alsalamy.droidtools.domain.ToolCategory
import com.alsalamy.droidtools.ui.components.LocalMessenger
import com.alsalamy.droidtools.ui.components.Messenger
import com.alsalamy.droidtools.ui.favorites.FavoritesScreen
import com.alsalamy.droidtools.ui.home.HomeScreen
import com.alsalamy.droidtools.ui.settings.AboutScreen
import com.alsalamy.droidtools.ui.settings.LicensesScreen
import com.alsalamy.droidtools.ui.settings.PrivacyCenterScreen
import com.alsalamy.droidtools.ui.settings.PrivacyPolicyScreen
import com.alsalamy.droidtools.ui.settings.SettingsScreen
import com.alsalamy.droidtools.ui.tool.ToolPrivacyScreen
import com.alsalamy.droidtools.ui.tool.ToolScreen
import com.alsalamy.droidtools.ui.tools.CategoryScreen
import com.alsalamy.droidtools.ui.tools.ToolsScreen

/** Routes de navigation. Les outils sont adressés par leur identifiant du catalogue : aucun « when » géant. */
object Routes {
    const val HOME = "home"
    const val TOOLS = "tools"
    const val FAVORITES = "favorites"
    const val SETTINGS = "settings"
    const val CATEGORY = "category/{categoryId}"
    const val TOOL = "tool/{toolId}"
    const val TOOL_PRIVACY = "tool/{toolId}/privacy"
    const val PRIVACY_CENTER = "privacy"
    const val ABOUT = "about"
    const val LICENSES = "licenses"
    const val PRIVACY_POLICY = "privacy_policy"

    fun category(category: ToolCategory) = "category/${category.name}"
    fun tool(id: String) = "tool/$id"
    fun toolPrivacy(id: String) = "tool/$id/privacy"
}

private enum class TopLevel(val route: String, val label: String, val icon: ImageVector) {
    HOME(Routes.HOME, "Accueil", Icons.Rounded.Home),
    TOOLS(Routes.TOOLS, "Outils", Icons.Rounded.Apps),
    FAVORITES(Routes.FAVORITES, "Favoris", Icons.Rounded.Star),
    SETTINGS(Routes.SETTINGS, "Réglages", Icons.Rounded.Settings),
}

private fun NavHostController.navigateTopLevel(route: String) {
    navigate(route) {
        popUpTo(graph.findStartDestination().id) { saveState = true }
        launchSingleTop = true
        restoreState = true
    }
}

@Composable
fun DroidToolsRoot(settings: AppSettings) {
    val navController = rememberNavController()
    val backStack by navController.currentBackStackEntryAsState()
    val currentRoute = backStack?.destination?.route
    val current = TopLevel.entries.firstOrNull { it.route == currentRoute }
    val snackbarHost = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()
    val messenger = remember(snackbarHost, scope) { Messenger(snackbarHost, scope) }

    val openTool: (String) -> Unit = { navController.navigate(Routes.tool(it)) }
    val back: () -> Unit = { navController.navigateUp() }

    CompositionLocalProvider(LocalMessenger provides messenger) {
        BoxWithConstraints {
            // Tablette ou mode paysage large : rail de navigation latéral au lieu de la barre inférieure.
            val wide = maxWidth >= 600.dp
            Scaffold(
                bottomBar = {
                    if (!wide && current != null) {
                        NavigationBar {
                            TopLevel.entries.forEach { dest ->
                                NavigationBarItem(
                                    selected = current == dest,
                                    onClick = { navController.navigateTopLevel(dest.route) },
                                    icon = { Icon(dest.icon, contentDescription = null) },
                                    label = { Text(dest.label) },
                                )
                            }
                        }
                    }
                },
                snackbarHost = { SnackbarHost(snackbarHost) },
                contentWindowInsets = WindowInsets(0, 0, 0, 0),
            ) { padding ->
                Row(Modifier.fillMaxSize().padding(padding).consumeWindowInsets(padding)) {
                    if (wide) {
                        NavigationRail {
                            Spacer(Modifier.height(12.dp))
                            TopLevel.entries.forEach { dest ->
                                NavigationRailItem(
                                    selected = current == dest,
                                    onClick = { navController.navigateTopLevel(dest.route) },
                                    icon = { Icon(dest.icon, contentDescription = null) },
                                    label = { Text(dest.label) },
                                )
                            }
                        }
                    }
                    NavHost(navController, startDestination = Routes.HOME, modifier = Modifier.weight(1f)) {
                        composable(Routes.HOME) {
                            HomeScreen(
                                settings = settings,
                                onOpenTool = openTool,
                                onOpenCategory = { navController.navigate(Routes.category(it)) },
                                onOpenAllTools = { navController.navigateTopLevel(Routes.TOOLS) },
                            )
                        }
                        composable(Routes.TOOLS) {
                            ToolsScreen(settings = settings, onOpenTool = openTool)
                        }
                        composable(
                            Routes.CATEGORY,
                            arguments = listOf(navArgument("categoryId") { type = NavType.StringType }),
                        ) { entry ->
                            val category = ToolCategory.entries.firstOrNull { it.name == entry.arguments?.getString("categoryId") }
                            CategoryScreen(category = category, settings = settings, onOpenTool = openTool, onBack = back)
                        }
                        composable(Routes.FAVORITES) {
                            FavoritesScreen(settings = settings, onOpenTool = openTool, onBrowse = { navController.navigateTopLevel(Routes.TOOLS) })
                        }
                        composable(Routes.SETTINGS) {
                            SettingsScreen(
                                settings = settings,
                                onOpenPrivacyCenter = { navController.navigate(Routes.PRIVACY_CENTER) },
                                onOpenAbout = { navController.navigate(Routes.ABOUT) },
                                onOpenLicenses = { navController.navigate(Routes.LICENSES) },
                                onOpenPrivacyPolicy = { navController.navigate(Routes.PRIVACY_POLICY) },
                            )
                        }
                        composable(
                            Routes.TOOL,
                            arguments = listOf(navArgument("toolId") { type = NavType.StringType }),
                        ) { entry ->
                            val id = entry.arguments?.getString("toolId").orEmpty()
                            ToolScreen(
                                toolId = id,
                                settings = settings,
                                onBack = back,
                                onOpenPrivacy = { navController.navigate(Routes.toolPrivacy(id)) },
                            )
                        }
                        composable(
                            Routes.TOOL_PRIVACY,
                            arguments = listOf(navArgument("toolId") { type = NavType.StringType }),
                        ) { entry ->
                            ToolPrivacyScreen(toolId = entry.arguments?.getString("toolId").orEmpty(), onBack = back)
                        }
                        composable(Routes.PRIVACY_CENTER) {
                            PrivacyCenterScreen(settings = settings, onBack = back, onOpenTool = openTool)
                        }
                        composable(Routes.ABOUT) {
                            AboutScreen(
                                onBack = back,
                                onOpenPrivacyCenter = { navController.navigate(Routes.PRIVACY_CENTER) },
                                onOpenLicenses = { navController.navigate(Routes.LICENSES) },
                                onOpenPrivacyPolicy = { navController.navigate(Routes.PRIVACY_POLICY) },
                            )
                        }
                        composable(Routes.LICENSES) { LicensesScreen(onBack = back) }
                        composable(Routes.PRIVACY_POLICY) { PrivacyPolicyScreen(onBack = back) }
                    }
                }
            }
        }
    }
}
