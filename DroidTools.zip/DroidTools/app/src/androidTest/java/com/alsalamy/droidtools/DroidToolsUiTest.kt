package com.alsalamy.droidtools

import androidx.compose.ui.test.ExperimentalTestApi
import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.hasSetTextAction
import androidx.compose.ui.test.hasText
import androidx.compose.ui.test.junit4.createAndroidComposeRule
import androidx.compose.ui.test.onAllNodesWithText
import androidx.compose.ui.test.onFirst
import androidx.compose.ui.test.onNodeWithText
import androidx.compose.ui.test.performClick
import androidx.compose.ui.test.performTextInput
import androidx.test.ext.junit.runners.AndroidJUnit4
import org.junit.Before
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith

/** Parcours essentiels (exécutés sur émulateur par l'intégration continue, à la demande). */
@OptIn(ExperimentalTestApi::class)
@RunWith(AndroidJUnit4::class)
class DroidToolsUiTest {

    @get:Rule
    val rule = createAndroidComposeRule<MainActivity>()

    private fun waitForText(text: String, timeoutMs: Long = 5_000) {
        rule.waitUntil(timeoutMs) { rule.onAllNodesWithText(text).fetchSemanticsNodes().isNotEmpty() }
    }

    @Before
    fun waitForHome() {
        // Les réglages sont lus de façon asynchrone avant le premier affichage.
        waitForText("Tous vos outils. Une seule application.")
    }

    private fun searchAndOpen(query: String, toolName: String) {
        rule.onNode(hasSetTextAction()).performTextInput(query)
        waitForText(toolName)
        rule.onAllNodesWithText(toolName).onFirst().performClick()
    }

    @Test
    fun homeShowsBrandingAndCategories() {
        rule.onNodeWithText("DroidTools").assertIsDisplayed()
        rule.onNodeWithText("Catégories").assertIsDisplayed()
        rule.onAllNodesWithText("Calculs").onFirst().assertIsDisplayed()
    }

    @Test
    fun vatToolComputesIncludingTax() {
        searchAndOpen("tva", "TVA HT / TTC")
        rule.onNode(hasSetTextAction() and hasText("Montant")).performTextInput("100")
        waitForText("120,00")
    }

    @Test
    fun notImplementedToolsAreNotOffered() {
        // Les outils PDF font partie de la feuille de route : ils ne sont pas proposés.
        rule.onNode(hasSetTextAction()).performTextInput("pdf")
        waitForText("Aucun outil trouvé")
    }

    @Test
    fun passwordGeneratorProducesAPasswordOnOpen() {
        searchAndOpen("mot de passe", "Générateur de mots de passe")
        waitForText("Mot de passe")
        waitForText("Robustesse")
    }

    @Test
    fun privacyCenterIsReachableFromSettings() {
        rule.onAllNodesWithText("Réglages").onFirst().performClick()
        waitForText("Confidentialité et sécurité")
        rule.onAllNodesWithText("Confidentialité et sécurité").onFirst().performClick()
        waitForText("Permissions")
    }
}
