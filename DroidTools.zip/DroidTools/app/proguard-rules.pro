# Règles R8 de DroidTools.
# Aucune réflexion ni sérialisation dynamique n'est utilisée : les règles par défaut
# (proguard-android-optimize.txt) et celles fournies par les bibliothèques AndroidX suffisent.
