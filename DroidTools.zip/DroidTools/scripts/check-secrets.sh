#!/usr/bin/env bash
# Recherche de secrets évidents dans les fichiers versionnés (complément d'une revue humaine, pas une garantie).
set -euo pipefail
cd "$(dirname "$0")/.."
patterns=(
  'AKIA[0-9A-Z]{16}'                          # clé AWS
  'AIza[0-9A-Za-z_-]{35}'                     # clé Google API
  'ghp_[0-9A-Za-z]{36}'                       # jeton GitHub
  'github_pat_[0-9A-Za-z_]{40,}'
  'xox[baprs]-[0-9A-Za-z-]{10,}'              # jeton Slack
  '-----BEGIN (RSA |EC |OPENSSH |)PRIVATE KEY-----'
  '(api[_-]?key|secret|password|passwd|token)[[:space:]]*[:=][[:space:]]*"[^"]{8,}"'
)
# Analyse les fichiers présents sur le disque (et pas seulement ceux suivis par git) :
# le projet peut être extrait d'une archive par l'intégration continue.
files=$(find . -type f -not -path './.git/*' -not -path '*/build/*' -not -path '*/.gradle/*' -not -path '*/.kotlin/*' \
  -not -name '*.zip' -not -name '*.jar' -not -name '*.png' -not -name '*.webp' | sed 's|^\./||')
status=0
for p in "${patterns[@]}"; do
  if echo "$files" | grep -v -E '(^|/)(gradle-wrapper\.jar|check-secrets\.sh)$' | xargs -r grep -n -I -E -i -- "$p" 2>/dev/null; then
    echo "Motif suspect : $p" >&2
    status=1
  fi
done
for f in $files; do
  case "$f" in *.jks|*.keystore|*.p12|*.pem|local.properties|keystore.properties) echo "Fichier sensible versionné : $f" >&2; status=1 ;; esac
done
[ $status -eq 0 ] && echo "Aucun secret évident détecté."
exit $status
