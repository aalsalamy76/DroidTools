# Rapport de sécurité de DroidTools — état intermédiaire (phases 1 et 2)

Date : 3 novembre 2026. Version : 0.3.0.

## Vérifications par l'intégration continue (build GitHub Actions n° 41540065047, version 0.2.0)

- Tests unitaires du moteur et de l'application : réussis.
- APK de débogage compilé ; build release avec R8 compilé.
- Lint Android : 0 erreur, 5 avertissements. Trois sont corrigés en 0.3.0 (règles de sauvegarde pour Android 8 à 11, attribut réservé à l'API 33, version de Gradle). Deux sont conservés : une suggestion de style Kotlin et le choix de cibler l'API 36 plutôt que 37.
- Permissions de l'APK (dump `aapt2`) : uniquement `com.alsalamy.droidtools.DYNAMIC_RECEIVER_NOT_EXPORTED_PERMISSION`, permission de signature propre à l'application et ajoutée par AndroidX. **Aucune permission `INTERNET`.**

La version 0.3.0 (identité visuelle, retrait des outils non implémentés) sera vérifiée de la même façon au prochain build.

Ce rapport décrit l'état réel du projet à la fin des phases 1 (architecture) et 2 (outils locaux). L'audit final prévu en phase 7 reste à faire. Ce rapport n'affirme pas que l'application est exempte de vulnérabilités : il liste ce qui a été vérifié, comment, et ce qui reste ouvert.

## Contrôles réalisés

| Contrôle | Méthode | Résultat |
|---|---|---|
| Secrets dans le dépôt | `scripts/check-secrets.sh` (clés AWS/Google, jetons GitHub/Slack, clés privées, affectations `password=`/`token=`…) + revue | Aucun secret. Aucune clé ni aucun jeton, pas de `BuildConfig` personnalisé. Le script tourne à chaque build de l'intégration continue. |
| Permissions | Lecture du manifeste source | Aucune permission déclarée, pas même `INTERNET`. À confirmer sur le manifeste fusionné (dump `aapt2` publié par l'intégration continue). |
| Journaux | Recherche de `android.util.Log`, `println`, `printStackTrace` | Aucun appel de journalisation, ni dans l'application ni dans le moteur. |
| Réseau | Recherche de `URL`, `Socket`, `HttpURLConnection`, `WebView`, `InetAddress` | Aucun code réseau. `java.net.URLEncoder`/`URLDecoder` ne servent qu'à l'encodage de texte, sans connexion. |
| HTTP non chiffré | — | Sans objet : aucune communication réseau. |
| WebView | Recherche | Aucune WebView. |
| Aléa | Recherche de `java.util.Random`, `kotlin.random`, `Math.random` | Absents. Tous les générateurs exigent un `SecureRandom` (vérifié par le typage des fonctions). |
| Cryptographie | Revue | Aucun algorithme maison. `MessageDigest` (SHA-256/512, SHA-1, MD5) ; MD5 et SHA-1 sont signalés comme non sécuritaires dans l'interface. Comparaison d'empreintes à temps constant (`MessageDigest.isEqual`). |
| Stockage | Revue | DataStore dans l'espace privé : réglages, favoris, outils récents (identifiants d'outils uniquement), checklist (non chiffrée, signalé à l'utilisateur). Aucun mot de passe, PIN ni contenu saisi n'est enregistré. |
| Sauvegarde | Manifeste | `allowBackup="false"` et `dataExtractionRules` excluant tous les domaines, en sauvegarde cloud comme en transfert d'appareil. |
| Presse-papiers | Revue | Écriture uniquement sur action « Copier ». Valeurs sensibles marquées `IS_SENSITIVE`, avertissement affiché. Aucune lecture. |
| Captures d'écran | Revue | `FLAG_SECURE` sur les écrans de mots de passe, phrases de passe, PIN, jetons et robustesse. Un test vérifie que tout résultat sensible est affiché sur un écran sécurisé. |
| Intents | Recherche | Deux intents seulement, tous deux sur action explicite : `ACTION_VIEW` vers l'URL LinkedIn (constante HTTPS) et `ACTION_APPLICATION_DETAILS_SETTINGS`. Fichiers ouverts via `ACTION_OPEN_DOCUMENT` (Storage Access Framework), sans permission persistante. |
| Composants exportés | Manifeste source | Seule `MainActivity` (lanceur) est exportée. Les composants ajoutés par les bibliothèques (ex. `ProfileInstallReceiver`, protégé par la permission système `DUMP`) sont à confirmer sur le manifeste fusionné. |
| URL codées en dur | Recherche | Profil LinkedIn du développeur uniquement (plus les espaces de noms XML et une URL en commentaire). |
| Validation des entrées | 86 tests unitaires, dont un test de robustesse qui soumet à chaque formulaire environ 35 entrées hostiles (vides, 1e400, 5 000 caractères, caractères de contrôle, contrôles bidirectionnels, emoji, dates impossibles…) dans toutes les combinaisons d'options | Aucun plantage : chaque cas donne un résultat, une attente de saisie ou un message lisible. |
| Déni de service par regex (ReDoS) | Test avec un motif exponentiel (`^(a+)+\1b$`) | Résultat abandonné après 2 s. Voir la limite ouverte ci-dessous. |
| API Java absentes d'Android | Compilation du moteur contre l'API Java 8 (`-Xjdk-release=1.8`) | Toute méthode Java 9+ absente d'Android 8 (minSdk 26) devient une erreur de compilation. |
| Versions des dépendances | Vérification sur developer.android.com le 2 novembre 2026 | AGP 9.5.0, Compose BOM 2026.09.00, activity 1.13.0, lifecycle 2.11.0, navigation 2.10.2, datastore 1.3.0. |

## Problèmes corrigés pendant ces phases

1. **Délai des expressions régulières inopérant sous Android.** Le garde-fou initial interrompait le moteur via `charAt()`. Or, sous Android, `java.util.regex` délègue au moteur natif ICU, qui copie le texte : l'interruption n'aurait jamais eu lieu et l'interface aurait pu se bloquer. Correctif : évaluation sur un thread dédié avec attente bornée à 2 s, et refus de nouvelles évaluations tant que 2 calculs abandonnés tournent encore.
2. **Appel Java 9 qui aurait planté sur Android 8 à 13** (`LocalDate.ofInstant`). Corrigé. Le moteur est désormais compilé contre l'API Java 8 pour empêcher toute récidive.
3. **Recherche** : le tiret long et d'autres ponctuations n'étaient pas traités comme des séparateurs.
4. **Couleurs** : `rgb(30,136,229)` était mal lu (la virgule était prise pour un séparateur décimal).

## Problèmes ouverts

1. **Tests d'interface** (`DroidToolsUiTest`) : pas encore exécutés sur émulateur. On les lance à la demande depuis GitHub Actions (option « ui_tests »).
2. **Regex sous Android** : un calcul abandonné continue à consommer du processeur en arrière-plan jusqu'à sa fin (le moteur ICU ne peut pas être interrompu). Le nombre de calculs abandonnés simultanés est limité à 2, et la limite est indiquée dans la fiche de l'outil.
3. **Checklist non chiffrée** (choix assumé et signalé). Le coffre-fort chiffré (AES-GCM + Android Keystore) est NON IMPLÉMENTÉ.
4. **Manifeste fusionné** : permissions confirmées par `aapt2` (voir ci-dessus). Les composants exportés par les bibliothèques restent à inventorier en détail.
5. **Somme de contrôle de la distribution Gradle** : non épinglée dans `gradle-wrapper.properties` tant qu'elle n'a pas été vérifiée sur une source officielle (l'intégration continue la publie). Le `gradle-wrapper.jar` est, lui, validé par `gradle/actions/setup-gradle`.
6. **Inventaire des dépendances transitives** : à générer par l'intégration continue (`dependencies-release.txt`) pour compléter la page « Licences open source ».
7. **Règles R8** : la build release minifiée n'a pas encore été testée sur un appareil.

## Permissions utilisées

Aucune permission demandée à l'utilisateur. Aucune permission dangereuse. Pas de permission `INTERNET`.

## Fonctions nécessitant Internet

Aucune dans cette version. Les outils réseau prévus (Wi-Fi, DNS, ping, scanner de ports, en-têtes HTTP, certificats TLS…) sont NON IMPLÉMENTÉS : ils ne figurent pas dans l'application.

## Polices intégrées

Bricolage Grotesque, Atkinson Hyperlegible Next et Atkinson Hyperlegible Mono (SIL Open Font License 1.1, sans nom de police réservé) sont intégrées à l'APK : aucun téléchargement de police n'a lieu. Graisses statiques extraites et allégées avec fontTools ; licences consultables dans l'application.

## Fonctions 100 % locales

Les 73 outils disponibles (70 fonctionnels, 3 partiels) : calculs, conversions, calculs IPv4/CIDR/sous-réseaux (hors ligne), analyse de User-Agent, couleurs, texte et développement, timestamps, UUID/ULID, générateurs de mots de passe, de phrases de passe, de PIN et de jetons, analyse de robustesse, hachages, hash de fichier, outils du quotidien. Le détail figure dans [TOOL_STATUS.md](TOOL_STATUS.md).
