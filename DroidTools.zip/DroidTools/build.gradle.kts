// Fichier racine : déclare les plugins sans les appliquer.
// AGP 9 intègre le support Kotlin : le plugin org.jetbrains.kotlin.android n'est plus utilisé.
plugins {
    alias(libs.plugins.android.application) apply false
    alias(libs.plugins.kotlin.jvm) apply false
    alias(libs.plugins.kotlin.compose) apply false
}
