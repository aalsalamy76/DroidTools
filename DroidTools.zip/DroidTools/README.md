# DroidTools

> Tous vos outils. Une seule application. — *Ultimate tools. Private by design.*

Boîte à outils Android (Kotlin, Jetpack Compose, Material 3) : calculs, conversions, texte et développement, réseau/IT, sécurité, outils du quotidien. Tout est traité localement : l'application ne déclare pas la permission Internet.

Développeur : **Abdullah AL-SALAMY** — [LinkedIn](https://www.linkedin.com/in/abdullah-a-2982451a6)

## État (version 0.3.0)

- **73 outils, tous fonctionnels hors ligne** (70 fonctionnels, 3 partiels aux limites indiquées). Les 61 outils non implémentés du cahier des charges ont été retirés de l'application ; ils restent documentés comme feuille de route dans [TOOL_STATUS.md](TOOL_STATUS.md).
- Compilation vérifiée par GitHub Actions : tests unitaires, APK de débogage, build release (R8) et lint (0 erreur).
- Module `engine` : 86 tests unitaires.

## Identité visuelle

- **Code couleur par famille d'outils**, comme le câblage réseau : Calculs en bleu, Conversions en orange, Réseau en cyan, Couleurs en magenta, Texte et dev en vert, Sécurité en rouge, Quotidien en jaune. Les palettes sont générées avec material-color-utilities ; les contrastes sont vérifiés à la génération (texte sur tuile ≥ 5,3:1).
- **Polices intégrées** (SIL Open Font License 1.1) :
  - *Bricolage Grotesque* pour les titres ;
  - *Atkinson Hyperlegible Next* pour le texte ;
  - *Atkinson Hyperlegible Mono* pour les codes et mots de passe, qui distingue nettement 0/O et 1/l/I.
- Thème clair, sombre ou système. Les couleurs dynamiques d'Android 12 et plus restent disponibles en option.

## Architecture

```
engine/   Kotlin pur (JVM, API Java 8) : aucune dépendance Android, aucun accès réseau, testé unitairement
  core/        Outcome (erreurs lisibles), Num (nombres au format français), TextNormalizer, ByteFormat
  domain/      ToolDefinition, ToolCategory, ToolCatalog (registre central), ToolSearch, fiches de confidentialité
  forms/       Description déclarative des outils (champs, calcul, résultat) + registre ToolForms
  tools/       Logique métier : calc, convert, net, color, text, json, xml, codec, time, daily
  security/    Générateurs SecureRandom, robustesse, hachages
app/      Application Android (Compose, Material 3)
  core/        AppContainer (dépendances), AppInfo (version et permissions lues sur l'appareil)
  data/        Réglages, favoris, historique, checklist (DataStore local)
  navigation/  Routes et racine (barre inférieure sur téléphone, rail sur tablette)
  security/    Presse-papiers sensible, FLAG_SECURE
  ui/          Accueil, outils, favoris, réglages, centre de confidentialité, À propos, licences,
               moteur de rendu générique des formulaires, écrans dédiés (calculatrices, hash de fichier,
               chronomètre, minuteur, checklist)
```

**Ajouter un outil** : une entrée dans `ToolCatalog` (métadonnées, mots-clés, fiche de confidentialité), puis soit un formulaire dans `forms/` déclaré dans `ToolForms`, soit un écran dédié. Accueil, recherche, catégories, favoris, centre de confidentialité et navigation l'intègrent automatiquement. Les tests vérifient que chaque outil disponible a exactement une interface et qu'aucun outil non implémenté n'en a.

## Compiler

Prérequis : JDK 17 ou plus, SDK Android (plateforme 37).

```bash
./gradlew :engine:test            # tests du moteur
./gradlew :app:testDebugUnitTest  # tests unitaires de l'application
./gradlew :app:assembleDebug      # APK : app/build/outputs/apk/debug/
./gradlew :app:connectedDebugAndroidTest  # tests d'interface (émulateur ou appareil)
```

Versions : AGP 9.5.0, Gradle 9.8.2, Kotlin 2.4.21, Compose BOM 2026.09.00 (voir `gradle/libs.versions.toml`, sources vérifiées le 2 novembre 2026). minSdk 26, targetSdk 36, compileSdk 37.

## Intégration continue

`.github/workflows/build.yml`, à chaque push :

- recherche de secrets ;
- vérification que la politique intégrée est identique à PRIVACY.md ;
- tests unitaires, APK de débogage, build release (R8), lint ;
- dump des permissions de l'APK, inventaire des dépendances.

L'APK et les rapports sont publiés comme artefacts. Les tests d'interface sur émulateur se lancent à la demande (*Run workflow* → « ui_tests »).

## Confidentialité et sécurité

- [PRIVACY.md](PRIVACY.md) : politique de confidentialité, aussi affichée dans l'application.
- [SECURITY_REPORT.md](SECURITY_REPORT.md) : contrôles réalisés, corrections, problèmes ouverts.
