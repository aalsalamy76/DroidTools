package com.alsalamy.droidtools.forms

import com.alsalamy.droidtools.domain.ToolCatalog
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Assert.fail
import org.junit.Test
import java.security.SecureRandom
import java.time.Instant
import java.time.ZoneId

class ToolFormsTest {

    private val now = Instant.parse("2026-11-02T12:00:00Z")
    private val ctx = FormContext({ now }, ZoneId.of("Europe/Paris"), SecureRandom())

    private fun form(id: String) = ToolForms.forTool(id) ?: error("Pas de formulaire pour $id")

    private fun run(id: String, vararg values: Pair<String, String>): FormOutcome {
        val f = form(id)
        var v = FormValues.defaults(f)
        values.forEach { (k, value) -> v = v.with(k, value) }
        return f.evaluate(v, ctx)
    }

    private fun ok(id: String, vararg values: Pair<String, String>): FormResult {
        val outcome = run(id, *values)
        if (outcome !is FormOutcome.Success) fail("$id : succès attendu, obtenu $outcome")
        return (outcome as FormOutcome.Success).result
    }

    private fun FormResult.rows() = items.filterIsInstance<ResultRow>()
    private fun FormResult.row(label: String) = rows().firstOrNull { it.label == label } ?: error("Ligne « $label » absente : ${rows().map { it.label }}")
    private fun FormResult.main() = rows().first { it.emphasis }

    // ------------------------------------------------------------ Couverture du catalogue

    @Test
    fun everyAvailableToolHasExactlyOneInterface() {
        for (tool in ToolCatalog.entries) {
            val hasForm = tool.id in ToolForms.formIds
            val hasCustom = tool.id in ToolForms.customScreens
            if (tool.isAvailable) {
                assertTrue("${tool.id} disponible mais sans interface", hasForm || hasCustom)
                assertFalse("${tool.id} a deux interfaces", hasForm && hasCustom)
            } else {
                assertFalse("${tool.id} NON IMPLÉMENTÉ ne doit pas avoir d'interface", hasForm || hasCustom)
            }
        }
        val catalogIds = ToolCatalog.all.map { it.id }.toSet()
        (ToolForms.formIds + ToolForms.customScreens).forEach { assertTrue("$it absent du catalogue", it in catalogIds) }
    }

    @Test
    fun sensitiveResultsAlwaysUseASecureScreen() {
        for (id in ToolForms.formIds) {
            val f = form(id)
            val outcome = f.evaluate(FormValues.defaults(f), ctx)
            val sensitive = (outcome as? FormOutcome.Success)?.result?.items?.any {
                (it is ResultRow && it.sensitive) || (it is ResultText && it.sensitive)
            } ?: false
            if (sensitive) assertTrue("$id produit une valeur sensible sans écran sécurisé", f.secureScreen)
        }
    }

    // ------------------------------------------------------------ Robustesse

    private val hostileInputs = listOf(
        "", " ", "0", "-0", "-1", "1,5", "1.2.3", "1e400", "-1e-400", "NaN", "Infinity",
        "99999999999999999999999999999", "2147483648", "-9223372036854775809",
        "abc", "#", "((", ")", "[", "{", "\"", "\\", "/", "/33", "192.168.1.1/33", "255.255.255.255/0",
        "😀", "\u0000", "‮", "a".repeat(5000), "(?<n>a)\\k<n>", "29/02/2023", "31/12/9999 23:59", "00/00/0000",
    )

    @Test
    fun hostileInputsNeverCrash() {
        for (id in ToolForms.formIds) {
            val f = form(id)
            val base = FormValues.defaults(f)
            val variants = mutableListOf(base)
            // Chaque option de chaque liste de choix, et tous les interrupteurs activés / désactivés.
            for (field in f.fields) {
                if (field is ChoiceInput) field.options.forEach { variants += base.with(field.key, it.id) }
            }
            val toggles = f.fields.filterIsInstance<ToggleInput>()
            variants += toggles.fold(base) { acc, t -> acc.with(t.key, "true") }
            variants += toggles.fold(base) { acc, t -> acc.with(t.key, "false") }
            val textFields = f.fields.filterIsInstance<TextInput>()
            for (variant in variants) {
                assertEvaluates(id, f, variant)
                for (input in hostileInputs) {
                    assertEvaluates(id, f, textFields.fold(variant) { acc, t -> acc.with(t.key, input) })
                    // Un seul champ hostile, les autres valides par défaut.
                    textFields.forEach { t -> assertEvaluates(id, f, variant.with(t.key, input)) }
                }
            }
            // Curseurs aux bornes.
            f.fields.filterIsInstance<SliderInput>().forEach { s ->
                assertEvaluates(id, f, base.with(s.key, s.min.toString()))
                assertEvaluates(id, f, base.with(s.key, s.max.toString()))
            }
        }
    }

    private fun assertEvaluates(id: String, f: ToolForm, values: FormValues) {
        try {
            when (val o = f.evaluate(values, ctx)) {
                is FormOutcome.Invalid -> assertTrue("$id : message d'erreur vide", o.message.isNotBlank())
                is FormOutcome.Success, is FormOutcome.Waiting -> Unit
            }
        } catch (e: Throwable) {
            throw AssertionError("$id plante avec ${values.asMap()}", e)
        }
    }

    // ------------------------------------------------------------ Résultats attendus

    @Test
    fun percentagesAndVat() {
        assertEquals("12", ok("percentages", "p" to "15", "x" to "80").main().value)
        assertEquals("25 %", ok("percentages", "mode" to "share", "part" to "30", "total" to "120").main().value)
        assertEquals("+25 %", ok("percentages", "mode" to "change", "from" to "80", "to" to "100").main().value)
        assertEquals("80", ok("percentages", "mode" to "apply", "value" to "100", "rate" to "-20").main().value)
        assertTrue(run("percentages", "mode" to "share", "part" to "3", "total" to "0") is FormOutcome.Invalid)

        val vat = ok("vat", "amount" to "100")
        assertEquals("120.00", vat.row("Montant TTC").value.replace(',', '.'))
        assertEquals("20.00", vat.row("TVA à 20 %").value.replace(',', '.'))
        assertEquals("100.00", ok("vat", "from" to "ttc", "amount" to "105,5", "rate" to "5.5").row("Montant HT").value.replace(',', '.'))
        assertEquals("108.50", ok("vat", "amount" to "100", "rate" to "custom", "customRate" to "8,5").row("Montant TTC").value.replace(',', '.'))
        assertTrue(run("vat", "amount" to "") is FormOutcome.Waiting)
        val invalid = run("vat", "amount" to "abc")
        assertTrue(invalid is FormOutcome.Invalid && invalid.message.contains("Montant"))
    }

    @Test
    fun billSplitIsExactToTheCent() {
        val r = ok("bill_split", "amount" to "100", "people" to "3")
        assertEquals("33,33", r.main().value)
        val notice = r.items.filterIsInstance<ResultNotice>().single().text
        assertTrue(notice, notice.contains("1 personne paie 33,34"))
        assertTrue(notice, notice.contains("2 personnes paient 33,33"))
    }

    @Test
    fun conversionsListEveryOtherUnit() {
        val r = ok("convert_temperature", "value" to "100", "unit" to "c")
        assertTrue(r.rows().any { it.value.startsWith("212") })
        assertTrue(r.rows().any { it.value.startsWith("373,15") })
        assertTrue(run("convert_temperature", "value" to "-500", "unit" to "c") is FormOutcome.Invalid)
        val length = ok("convert_length", "value" to "1", "unit" to "km")
        assertTrue(length.rows().any { it.value.replace("\u00A0", " ").replace("\u202F", " ") == "1 000 m" })
    }

    @Test
    fun networkForms() {
        val r = ok("ipv4_calculator", "address" to "192.168.1.10/24")
        assertEquals("192.168.1.0/24", r.row("Réseau").value)
        assertEquals("254", r.row("Hôtes utilisables").value)
        assertTrue(run("ipv4_calculator", "address" to "192.168.1.10") is FormOutcome.Waiting)
        assertEquals("192.168.1.0/24", ok("ipv4_calculator", "address" to "192.168.1.10", "mask" to "255.255.255.0").row("Réseau").value)
        val split = ok("subnet_analysis", "network" to "192.168.0.0/24", "count" to "4")
        assertEquals(4, split.rows().count { it.label.startsWith("Sous-réseau") })
        val inside = ok("subnet_analysis", "mode" to "contains", "network" to "10.0.0.0/8", "address" to "10.1.2.3")
        assertEquals(NoticeLevel.SUCCESS, inside.items.filterIsInstance<ResultNotice>().first().level)
        val cidrs = ok("cidr_calculator", "mode" to "range", "start" to "10.0.0.0", "end" to "10.0.2.255")
        assertEquals(listOf("10.0.0.0/23", "10.0.2.0/24"), cidrs.rows().filter { it.label.startsWith("Bloc") }.map { it.value })
        assertEquals("192.168.1.10", ok("binary_to_ipv4", "bits" to "11000000.10101000.00000001.00001010").main().value)
    }

    @Test
    fun textAndDevForms() {
        assertEquals("BONJOUR", (ok("text_uppercase", "text" to "bonjour").items.first() as ResultText).text)
        val invalid = ok("json_validator", "text" to "{\"a\": 1,}")
        assertEquals(NoticeLevel.ERROR, (invalid.items.first() as ResultNotice).level)
        val valid = ok("json_validator", "text" to "{\"a\": [1, 2]}")
        assertEquals(NoticeLevel.SUCCESS, (valid.items.first() as ResultNotice).level)
        assertEquals("{\"a\":[1,2]}", ok("json_minifier", "text" to "{ \"a\" : [ 1 , 2 ] }").items.filterIsInstance<ResultText>().single().text)
        val regex = ok("regex_tester", "pattern" to "\\d+", "text" to "a1 b22 c333")
        assertTrue(regex.items.filterIsInstance<ResultHeader>().first().title.startsWith("3 correspondances"))
        assertEquals("SGVsbG8=", (ok("base64_encode", "text" to "Hello").items.first() as ResultText).text)
        assertEquals("a%20b", (ok("url_encode", "text" to "a b").items.first() as ResultText).text)
        val counter = ok("text_counter", "text" to "Bonjour le monde.\nDeuxième ligne")
        assertEquals("5", counter.row("Mots").value)
        assertEquals("2", counter.row("Lignes").value)
    }

    @Test
    fun securityForms() {
        val f = form("password_generator")
        assertTrue(f.secureScreen)
        assertEquals(Trigger.ON_ACTION_AND_OPEN, f.trigger)
        val pw = ok("password_generator").main()
        assertTrue(pw.sensitive)
        assertEquals(20, pw.value.length)
        assertEquals(32, ok("password_generator", "length" to "32").main().value.length)
        assertTrue(run("password_generator", "lower" to "false", "upper" to "false", "digits" to "false", "symbols" to "false") is FormOutcome.Invalid)
        assertEquals(6, ok("pin_generator").main().value.length)
        assertTrue(run("hash_sha256", "text" to "") is FormOutcome.Waiting)
        assertEquals("2cf24dba5fb0a30e26e83b2ac5b9e29e1b161e5c1fa7425e73043362938b9824", ok("hash_sha256", "text" to "hello").main().value)
        assertNotNull(form("hash_md5").warning)
        val same = ok("hash_compare", "a" to "AB:CD", "b" to "abcd")
        assertEquals(NoticeLevel.SUCCESS, (same.items.first() as ResultNotice).level)
        val strength = ok("password_strength", "password" to "azerty")
        assertEquals(NoticeLevel.ERROR, strength.items.filterIsInstance<ResultMeter>().single().level)
    }

    @Test
    fun dailyForms() {
        val age = ok("age_calculator", "birth" to "02/11/2000")
        assertEquals("26 ans", age.main().value)
        assertTrue(age.items.filterIsInstance<ResultNotice>().any { it.text.contains("Joyeux anniversaire") })
        val diff = ok("date_difference", "start" to "01/01/2026", "end" to "01/03/2026")
        assertEquals("2 mois", diff.main().value)
        assertEquals("59 jours", diff.row("Total en jours").value)
        val countdown = ok("countdown", "target" to "03/11/2026 13:00")
        assertEquals("1 jour 00 h 00 min 00 s", countdown.main().value)
        val now = ok("unix_timestamp")
        assertEquals(now.main().value, (now.main().value.toLong()).toString())
        val dice = ok("dice", "count" to "3", "faces" to "6").main().value.toInt()
        assertTrue(dice in 3..18)
        val numbers = ok("random_numbers", "min" to "1", "max" to "10", "count" to "10", "unique" to "true", "sorted" to "true")
        assertEquals("1, 2, 3, 4, 5, 6, 7, 8, 9, 10", numbers.items.filterIsInstance<ResultText>().single().text)
        assertTrue(run("random_numbers", "min" to "1", "max" to "5", "count" to "10", "unique" to "true") is FormOutcome.Invalid)
        assertTrue(ok("coin_flip").main().value in setOf("Pile", "Face"))
        val uuids = ok("uuid_generator", "count" to "3").items.filterIsInstance<ResultText>().single().text.lines()
        assertEquals(3, uuids.toSet().size)
        assertTrue(uuids.all { Regex("[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}").matches(it) })
        assertEquals(26, ok("ulid_generator").main().value.length)
    }

    @Test
    fun visibilityFollowsChoices() {
        val f = form("vat")
        val base = FormValues.defaults(f)
        assertFalse(f.visibleFields(base).any { it.key == "customRate" })
        assertTrue(f.visibleFields(base.with("rate", "custom")).any { it.key == "customRate" })
    }
}
