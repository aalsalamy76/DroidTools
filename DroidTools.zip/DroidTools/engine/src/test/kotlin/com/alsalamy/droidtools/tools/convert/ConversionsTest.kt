package com.alsalamy.droidtools.tools.convert

import com.alsalamy.droidtools.core.Outcome
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.math.BigDecimal
import java.math.MathContext

class ConversionsTest {

    private fun conv(value: String, q: Quantity, from: String, to: String): BigDecimal =
        (UnitConverter.convert(BigDecimal(value), q, from, to) as Outcome.Ok).value

    private fun assertClose(expected: String, actual: BigDecimal, digits: Int = 12) {
        val mc = MathContext(digits)
        assertEquals("attendu $expected, obtenu $actual", 0, BigDecimal(expected).round(mc).compareTo(actual.round(mc)))
    }

    @Test
    fun lengthAreaVolumeMass() {
        assertClose("1000", conv("1", Quantity.LENGTH, "km", "m"))
        assertClose("2.54", conv("1", Quantity.LENGTH, "in", "cm"))
        assertClose("1.609344", conv("1", Quantity.LENGTH, "mi", "km"))
        assertClose("10000", conv("1", Quantity.AREA, "ha", "m2"))
        assertClose("3.785411784", conv("1", Quantity.VOLUME, "gal_us", "l"))
        assertClose("1000", conv("1", Quantity.VOLUME, "m3", "l"))
        assertClose("2.20462262184878", conv("1", Quantity.MASS, "kg", "lb"))
        assertClose("5", conv("1", Quantity.MASS, "g", "ct"))
    }

    @Test
    fun temperature() {
        assertClose("32", conv("0", Quantity.TEMPERATURE, "c", "f"))
        assertClose("212", conv("100", Quantity.TEMPERATURE, "c", "f"))
        assertClose("-40", conv("-40", Quantity.TEMPERATURE, "f", "c"))
        assertClose("273.15", conv("0", Quantity.TEMPERATURE, "c", "k"))
        assertClose("491.67", conv("0", Quantity.TEMPERATURE, "c", "r"))
        assertClose("0", conv("0", Quantity.TEMPERATURE, "k", "r"))
        val below = UnitConverter.convert(BigDecimal("-300"), Quantity.TEMPERATURE, "c", "k")
        assertTrue((below as Outcome.Err).message.contains("zéro absolu"))
    }

    @Test
    fun speedPressureEnergyPower() {
        assertClose("27.7777777777778", conv("100", Quantity.SPEED, "kmh", "mps"))
        assertClose("1.852", conv("1", Quantity.SPEED, "kn", "kmh"))
        assertClose("1.01325", conv("1", Quantity.PRESSURE, "atm", "bar"))
        assertClose("760", conv("1", Quantity.PRESSURE, "atm", "torr"))
        assertClose("14.5037737730209", conv("1", Quantity.PRESSURE, "bar", "psi"))
        assertClose("3.6", conv("1", Quantity.ENERGY, "kwh", "mj"))
        assertClose("4.184", conv("1", Quantity.ENERGY, "kcal", "kj"))
        assertClose("1.35962161730390", conv("1", Quantity.POWER, "kw", "ch"))
    }

    @Test
    fun timeAngleData() {
        assertClose("86400", conv("1", Quantity.TIME, "d", "s"))
        assertClose("525600", conv("365", Quantity.TIME, "d", "min"))
        assertClose("3.14159265358979", conv("180", Quantity.ANGLE, "deg", "rad"))
        assertClose("200", conv("180", Quantity.ANGLE, "deg", "grad"))
        assertClose("1.073741824", conv("1", Quantity.DATA, "gib", "gb"))
        assertClose("8", conv("1", Quantity.DATA, "byte", "bit"))
        assertClose("1024", conv("1", Quantity.DATA, "mib", "kib"))
    }

    @Test
    fun invalidInputs() {
        assertTrue(UnitConverter.convert(BigDecimal("-1"), Quantity.LENGTH, "m", "km") is Outcome.Err)
        assertTrue(UnitConverter.convert(BigDecimal("1"), Quantity.LENGTH, "m", "inconnu") is Outcome.Err)
        // Les vitesses et durées négatives restent acceptées (sens de déplacement, décalage).
        assertTrue(UnitConverter.convert(BigDecimal("-1"), Quantity.TIME, "h", "min") is Outcome.Ok)
    }

    @Test
    fun everyUnitConvertsToItself() {
        for (q in Quantity.entries) {
            val units = Units.of(q)
            assertEquals("Unités dupliquées pour $q", units.size, units.map { it.id }.toSet().size)
            val (from, to) = Units.defaults(q)
            assertTrue(units.any { it.id == from } && units.any { it.id == to })
            for (u in units) assertClose("12.5", conv("12.5", q, u.id, u.id), 20)
        }
    }

    @Test
    fun numberBases() {
        val r = (NumberBase.convert("255", Radix.DECIMAL) as Outcome.Ok).value
        assertEquals("11111111", r.binary)
        assertEquals("FF", r.hexadecimal)
        assertEquals("377", r.octal)
        assertNull(r.twosComplement)
        val hex = (NumberBase.convert("0xff_ff", Radix.HEXADECIMAL) as Outcome.Ok).value
        assertEquals("65535", hex.decimal)
        val neg = (NumberBase.convert("-1", Radix.DECIMAL) as Outcome.Ok).value
        assertEquals("8 bits : 1111 1111", neg.twosComplement)
        val big = (NumberBase.convert("1" + "0".repeat(100), Radix.BINARY) as Outcome.Ok).value
        assertEquals(101, big.bitLength)
        assertTrue((NumberBase.convert("102", Radix.BINARY) as Outcome.Err).message.contains("« 2 »"))
        assertTrue(NumberBase.convert("", Radix.DECIMAL) is Outcome.Err)
        assertEquals("0001 0101", NumberBase.groupBinary("10101"))
    }
}
