package com.alsalamy.droidtools.tools.daily

import com.alsalamy.droidtools.core.Outcome
import com.alsalamy.droidtools.tools.calc.AngleMode
import com.alsalamy.droidtools.tools.calc.CalcKey
import com.alsalamy.droidtools.tools.calc.Calculator
import com.alsalamy.droidtools.tools.calc.CalculatorState
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class InteractiveToolsTest {

    private fun type(vararg keys: String, start: CalculatorState = CalculatorState()): CalculatorState =
        keys.fold(start) { s, k ->
            Calculator.press(
                s,
                when (k) {
                    "C" -> CalcKey.Clear
                    "⌫" -> CalcKey.Backspace
                    "=" -> CalcKey.Equals
                    "DEG" -> CalcKey.ToggleAngle
                    "Ans" -> CalcKey.Answer
                    else -> CalcKey.Insert(k)
                },
            )
        }

    // ------------------------------------------------------------ Calculatrice

    @Test
    fun calculatorBasics() {
        val s = type("1", "2", "+", "3", "×", "2")
        assertEquals("12+3×2", s.expression)
        assertEquals("18", s.preview)
        val done = Calculator.press(s, CalcKey.Equals)
        assertEquals("18", done.expression)
        assertEquals("12+3×2", done.lastExpression)
        assertTrue(done.justEvaluated)
        // Un chiffre après « = » démarre un nouveau calcul ; un opérateur continue.
        assertEquals("5", type("5", start = done).expression)
        assertEquals("18+", type("+", start = done).expression)
    }

    @Test
    fun calculatorInputRules() {
        assertEquals("0,5", type(",", "5").expression)
        assertEquals("1,5", type("1", ",", "5", ",").expression) // seconde virgule ignorée
        assertEquals("2×", type("2", "+", "×").expression) // opérateur remplacé
        assertEquals("2×−3", type("2", "×", "−", "3").expression) // nombre négatif autorisé
        assertEquals("", type("×").expression) // pas d'opérateur en tête sans résultat précédent
        assertEquals("2+", type("2", "+", "sin(", "⌫").expression) // fonction effacée d'un bloc
        assertNull(type("4", "2").preview) // pas d'aperçu pour un nombre seul
        assertEquals("200+10%", type("2", "0", "0", "+", "1", "0", "%").expression)
        assertEquals("220", type("2", "0", "0", "+", "1", "0", "%").preview)
    }

    @Test
    fun calculatorErrorsAndAngles() {
        val err = type("1", "÷", "0", "=")
        assertNotNull(err.error)
        assertEquals("1÷0", err.expression)
        assertEquals("1", type("sin(", "9", "0", ")", "=").expression)
        val rad = type("DEG", "cos(", "π", ")", "=")
        assertEquals(AngleMode.RADIANS, rad.angleMode)
        assertEquals("-1", rad.expression.replace('−', '-'))
        // Ans réinjecte le dernier résultat.
        val ans = type("C", "Ans", "+", "1", "=", start = type("4", "=") )
        assertEquals("5", ans.expression)
        val cleared = type("C", start = ans)
        assertEquals("", cleared.expression)
        assertEquals(5.0, cleared.answer!!, 0.0)
    }

    // ------------------------------------------------------------ Chronomètre et minuteur

    @Test
    fun stopwatch() {
        var sw = Stopwatch().start(1_000)
        assertEquals(500, sw.elapsed(1_500))
        sw = sw.lap(1_500).lap(2_250).pause(3_000)
        assertEquals(2_000, sw.elapsed(99_999))
        val laps = sw.lapDetails()
        assertEquals(2, laps.first().number)
        assertEquals(750, laps.first().lapMs)
        assertEquals(500, laps.last().lapMs)
        sw = sw.start(10_000)
        assertEquals(2_100, sw.elapsed(10_100))
        assertEquals(0, sw.reset().elapsed(50_000))
        assertEquals("01:02,34", Durations.format(62_345))
        assertEquals("1:00:00,00", Durations.format(3_600_000))
        assertEquals("1 minute 2 secondes", Durations.spoken(62_345))
    }

    @Test
    fun countdownTimer() {
        var t = CountdownTimer(10_000).start(0)
        assertEquals(4_000, t.remaining(6_000))
        t = t.pause(6_000)
        assertEquals(4_000, t.remaining(60_000))
        t = t.start(100_000)
        assertFalse(t.isFinished(103_999))
        assertTrue(t.isFinished(104_000))
        assertEquals(0f, t.fractionRemaining(200_000))
        assertEquals(10_000, t.reset().remaining(0))
        assertEquals(3_723_000L, (CountdownTimer.parseDuration("1", "2", "3") as Outcome.Ok).value)
        assertTrue(CountdownTimer.parseDuration("", "", "") is Outcome.Err)
        assertTrue(CountdownTimer.parseDuration("0", "60", "0") is Outcome.Err)
        assertTrue(CountdownTimer.parseDuration("x", "", "") is Outcome.Err)
    }

    // ------------------------------------------------------------ Checklist

    @Test
    fun checklistOperationsAndStorage() {
        var items = (Checklist.add(emptyList(), "  Pain  ") as Outcome.Ok).value
        items = (Checklist.add(items, "Lait \"demi-écrémé\"") as Outcome.Ok).value
        assertEquals(listOf(1L, 2L), items.map { it.id })
        assertEquals("Pain", items[0].text)
        assertTrue(Checklist.add(items, "   ") is Outcome.Err)
        items = Checklist.toggle(items, 1)
        assertTrue(items[0].done)
        val restored = Checklist.decode(Checklist.encode(items))
        assertEquals(items, restored)
        assertEquals(listOf(2L), Checklist.clearDone(items).map { it.id })
        assertEquals(listOf(1L), Checklist.remove(items, 2).map { it.id })
        // Contenu corrompu : jamais de plantage.
        assertEquals(emptyList<ChecklistItem>(), Checklist.decode("{pas du json"))
        assertEquals(emptyList<ChecklistItem>(), Checklist.decode(null))
        assertEquals(1, Checklist.decode("[{\"id\":1,\"text\":\"ok\"},{\"id\":\"x\"},{\"id\":1,\"text\":\"doublon\"},42]").size)
    }
}
