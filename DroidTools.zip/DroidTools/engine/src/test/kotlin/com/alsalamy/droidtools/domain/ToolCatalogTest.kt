package com.alsalamy.droidtools.domain

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class ToolCatalogTest {

    @Test
    fun idsAreUniqueAndSnakeCase() {
        val ids = ToolCatalog.entries.map { it.id }
        assertEquals("Identifiants dupliqués", ids.size, ids.toSet().size)
        ids.forEach { assertTrue("Identifiant invalide : $it", Regex("[a-z0-9_]+").matches(it)) }
    }

    @Test
    fun everySpecificationItemIsCoveredExactlyOnce() {
        // Traçabilité : chaque numéro est couvert par un outil disponible ou par la feuille de route.
        val items = ToolCatalog.entries.flatMap { it.specItems }
        val duplicates = items.groupBy { it }.filterValues { it.size > 1 }.keys
        assertTrue("Numéros couverts plusieurs fois : $duplicates", duplicates.isEmpty())
        val missing = (1..145).filterNot { it in items }
        assertTrue("Numéros non couverts : $missing", missing.isEmpty())
        assertTrue(items.all { it in 1..145 })
    }

    @Test
    fun implementedToolsHaveAccuratePrivacySheetsAndPlannedOnesDoNot() {
        for (tool in ToolCatalog.entries) {
            if (tool.isAvailable) {
                val sheet = tool.privacy
                assertNotNull("${tool.id} : fiche de confidentialité manquante", sheet)
                sheet!!
                assertTrue("${tool.id} : données manipulées non décrites", sheet.dataHandled.isNotBlank())
                assertTrue("${tool.id} : stockage non décrit", sheet.storage.isNotBlank())
                if (sheet.internetRequired) assertEquals(Processing.NETWORK, sheet.processing)
                if (sheet.processing == Processing.LOCAL) assertFalse("${tool.id} : local mais réseau déclaré", sheet.internetRequired)
            } else {
                assertNull("${tool.id} : un outil non implémenté ne doit pas afficher de fiche", tool.privacy)
            }
        }
    }

    @Test
    fun partialToolsDocumentTheirLimitations() {
        ToolCatalog.all.filter { it.status == ToolStatus.PARTIAL }.forEach {
            assertTrue("${it.id} : limites manquantes", it.limitations.isNotEmpty())
        }
    }

    @Test
    fun applicationOnlyOffersWorkingTools() {
        assertTrue(ToolCatalog.all.isNotEmpty())
        assertTrue("Un outil non implémenté est proposé", ToolCatalog.all.all { it.isAvailable })
        assertTrue(ToolCatalog.roadmap.none { it.isAvailable })
        assertEquals(ToolCatalog.entries.size, ToolCatalog.all.size + ToolCatalog.roadmap.size)
        ToolCatalog.roadmap.forEach { assertNull("${it.id} ne doit pas être trouvable", ToolCatalog.find(it.id)) }
    }

    @Test
    fun displayedCategoriesAreNeverEmpty() {
        assertTrue(ToolCatalog.categories.isNotEmpty())
        ToolCatalog.categories.forEach { assertTrue("${it.label} vide", ToolCatalog.byCategory(it).isNotEmpty()) }
        ToolCategory.entries.filterNot { it in ToolCatalog.categories }.forEach { assertTrue(ToolCatalog.byCategory(it).isEmpty()) }
    }

    @Test
    fun keywordsAndDescriptionsArePresent() {
        ToolCatalog.all.forEach {
            assertTrue("${it.id} : mots-clés manquants", it.keywords.isNotEmpty())
            assertTrue("${it.id} : description manquante", it.description.isNotBlank())
        }
    }
}
