package com.alsalamy.droidtools.tools.calc

import com.alsalamy.droidtools.core.Num
import com.alsalamy.droidtools.core.Outcome
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.math.BigDecimal

class CalculationsTest {

    private fun eval(expr: String, mode: AngleMode = AngleMode.DEGREES): Double =
        (ExpressionEvaluator.evaluate(expr, mode) as Outcome.Ok).value

    private fun err(expr: String): String = ExpressionEvaluator.evaluate(expr).errorOrNull()
        ?: throw AssertionError("Erreur attendue pour « $expr »")

    private fun bd(s: String) = BigDecimal(s)
    private fun assertBd(expected: String, actual: BigDecimal) =
        assertEquals("attendu $expected, obtenu $actual", 0, bd(expected).compareTo(actual))

    // ------------------------------------------------------------ Num

    @Test
    fun numParsesFrenchAndInternationalFormats() {
        assertBd("1234.5", Num.parse("1 234,5"))
        assertBd("1234.5", Num.parse("1234.5"))
        assertBd("1234.5", Num.parse("1,234.5"))
        assertBd("1234.5", Num.parse("1.234,5"))
        assertBd("-3", Num.parse("−3"))
        assertBd("200000", Num.parse("2E5"))
        assertNull(Num.parseOrNull("   "))
        assertTrue(runCatching { Num.parse("12abc") }.isFailure)
        assertTrue(runCatching { Num.parse("1E200") }.isFailure)
    }

    @Test
    fun numFormatsForDisplay() {
        assertEquals("1 234,5", Num.format(bd("1234.5")))
        assertEquals("0,3", Num.formatDouble(0.1 + 0.2))
        assertEquals("1,5 × 10¹⁸", Num.format(bd("1.5E18")))
        assertEquals("0", Num.format(bd("0.000")))
        assertEquals("12,35", Num.formatFixed(bd("12.345")))
        assertEquals("-1 000", Num.format(bd("-1000")))
    }

    // ------------------------------------------------------------ Calculatrice

    @Test
    fun basicArithmeticAndPrecedence() {
        assertEquals(14.0, eval("2+3×4"), 1e-12)
        assertEquals(20.0, eval("(2+3)*4"), 1e-12)
        assertEquals(2.5, eval("5 ÷ 2"), 1e-12)
        assertEquals(0.3, eval("0,1 + 0,2"), 1e-12)
        assertEquals(-4.0, eval("-2^2"), 1e-12)
        assertEquals(512.0, eval("2^3^2"), 1e-12)
        assertEquals(0.5, eval("2^-1"), 1e-12)
        assertEquals(6.0, eval("2x3"), 1e-12)
        assertEquals(-1.0, eval("3 − 4"), 1e-12)
    }

    @Test
    fun percentagesFollowCalculatorConventions() {
        assertEquals(220.0, eval("200 + 10%"), 1e-9)
        assertEquals(180.0, eval("200 - 10%"), 1e-9)
        assertEquals(20.0, eval("200 × 10%"), 1e-9)
        assertEquals(0.5, eval("50%"), 1e-12)
    }

    @Test
    fun scientificFunctions() {
        assertEquals(0.5, eval("sin(30)"), 1e-12)
        assertEquals(0.0, eval("sin(180)"), 0.0)
        assertEquals(1.0, eval("tan(45)"), 1e-12)
        assertEquals(0.0, eval("cos(π/2)", AngleMode.RADIANS), 0.0)
        assertEquals(90.0, eval("asin(1)"), 1e-12)
        assertEquals(3.0, eval("log(1000)"), 1e-12)
        assertEquals(1.0, eval("ln(e)"), 1e-12)
        assertEquals(10.0, eval("log2(1024)"), 1e-12)
        assertEquals(3.0, eval("√9"), 1e-12)
        assertEquals(4.0, eval("sqrt(16)"), 1e-12)
        assertEquals(120.0, eval("5!"), 1e-12)
        assertEquals(25.0, eval("5²"), 1e-12)
        assertEquals(2 * Math.PI, eval("2π"), 1e-12)
        assertEquals(2000.0, eval("2E3"), 1e-12)
        assertEquals(2 * Math.E, eval("2e"), 1e-12)
        assertEquals(15.0, eval("3(4+1)"), 1e-12)
    }

    @Test
    fun errorsAreReportedWithoutCrashing() {
        assertTrue(err("1/0").contains("Division par zéro"))
        assertTrue(err("sqrt(-1)").contains("négatif"))
        assertTrue(err("ln(0)").contains("positif"))
        assertTrue(err("tan(90)").contains("non définie"))
        assertTrue(err("(2+3").contains("Parenthèse"))
        assertTrue(err("2 3").contains("Opérateur manquant"))
        assertTrue(err("foo(2)").contains("inconnue"))
        assertTrue(err("2.5!").contains("factorielle", ignoreCase = true))
        assertTrue(err("171!").contains("trop grande"))
        assertTrue(err("").isNotEmpty())
        assertTrue(err("10^400").contains("trop grand"))
        assertTrue(err("(".repeat(200) + "1" + ")".repeat(200)).contains("imbriquée"))
        assertTrue(err("2 # 3").contains("non reconnu"))
    }

    // ------------------------------------------------------------ Calculs du quotidien

    @Test
    fun percentages() {
        assertBd("30", Percentages.percentOf(bd("15"), bd("200")))
        assertBd("25", (Percentages.share(bd("50"), bd("200")) as Outcome.Ok).value)
        assertBd("-20", (Percentages.change(bd("50"), bd("40")) as Outcome.Ok).value)
        assertBd("110", Percentages.applyChange(bd("100"), bd("10")))
        assertTrue(Percentages.share(bd("1"), bd("0")) is Outcome.Err)
        assertTrue(Percentages.change(bd("0"), bd("5")) is Outcome.Err)
    }

    @Test
    fun vat() {
        val a = (Vat.fromExcludingTax(bd("100"), bd("20")) as Outcome.Ok).value
        assertBd("20.00", a.vat); assertBd("120.00", a.includingTax)
        val b = (Vat.fromIncludingTax(bd("120"), bd("20")) as Outcome.Ok).value
        assertBd("100.00", b.excludingTax); assertBd("20.00", b.vat)
        val c = (Vat.fromIncludingTax(bd("10"), bd("5.5")) as Outcome.Ok).value
        assertBd("9.48", c.excludingTax); assertBd("0.52", c.vat)
        assertTrue(Vat.fromExcludingTax(bd("-1"), bd("20")) is Outcome.Err)
        assertTrue(Vat.fromExcludingTax(bd("1"), bd("120")) is Outcome.Err)
    }

    @Test
    fun discounts() {
        val r = (Discount.apply(bd("80"), listOf(bd("25"))) as Outcome.Ok).value
        assertBd("60.00", r.finalPrice); assertBd("20.00", r.savings)
        val successive = (Discount.apply(bd("100"), listOf(bd("50"), bd("20"))) as Outcome.Ok).value
        assertBd("40.00", successive.finalPrice); assertBd("60", successive.effectiveRate)
        assertTrue(Discount.apply(bd("100"), listOf(bd("150"))) is Outcome.Err)
    }

    @Test
    fun ruleOfThreeAndRatio() {
        assertBd("7.5", (RuleOfThree.solve(bd("4"), bd("6"), bd("5")) as Outcome.Ok).value)
        assertTrue(RuleOfThree.solve(bd("0"), bd("6"), bd("5")) is Outcome.Err)
        val ratio = (Ratio.simplify(bd("1920"), bd("1080")) as Outcome.Ok).value
        assertEquals("16:9", "${ratio.left}:${ratio.right}")
        val dec = (Ratio.simplify(bd("1.5"), bd("2")) as Outcome.Ok).value
        assertEquals("3:4", "${dec.left}:${dec.right}")
        assertTrue(Ratio.simplify(bd("0"), bd("0")) is Outcome.Err)
    }

    @Test
    fun billSplitIsExactToTheCent() {
        val r = (BillSplitter.split(bd("100"), bd("0"), 3) as Outcome.Ok).value
        assertBd("33.33", r.share)
        assertEquals(1, r.peoplePayingOneMoreCent)
        val total = r.share.multiply(BigDecimal(3)).add(BigDecimal("0.01").multiply(BigDecimal(r.peoplePayingOneMoreCent)))
        assertBd("100.00", total)
        val tip = (BillSplitter.split(bd("80"), bd("10"), 4) as Outcome.Ok).value
        assertBd("88.00", tip.total); assertBd("22.00", tip.share)
        assertTrue(BillSplitter.split(bd("10"), bd("0"), 0) is Outcome.Err)
    }

    @Test
    fun statistics() {
        val values = Stats.parseList("12 ; 15,5\n8 14", "Valeurs")
        val s = (Stats.compute(values, listOf(bd("1"), bd("2"), bd("1"), bd("1"))) as Outcome.Ok).value
        assertEquals(4, s.count)
        assertBd("12.375", s.mean)
        assertBd("13", s.median)
        assertBd("8", s.min); assertBd("15.5", s.max)
        assertBd("13", s.weightedMean!!)
        assertEquals(2.8146, s.populationStdDev, 1e-4)
        assertTrue(Stats.compute(emptyList()) is Outcome.Err)
        assertTrue(Stats.compute(values, listOf(bd("1"))) is Outcome.Err)
    }
}
