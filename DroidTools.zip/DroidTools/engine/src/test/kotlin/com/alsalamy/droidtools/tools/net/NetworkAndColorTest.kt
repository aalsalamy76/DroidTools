package com.alsalamy.droidtools.tools.net

import com.alsalamy.droidtools.core.Outcome
import com.alsalamy.droidtools.tools.color.ColorConverter
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class NetworkAndColorTest {

    private fun <T> ok(o: Outcome<T>): T = (o as? Outcome.Ok)?.value ?: throw AssertionError("Succès attendu : ${o.errorOrNull()}")
    private fun err(o: Outcome<*>): String = o.errorOrNull() ?: throw AssertionError("Erreur attendue")

    @Test
    fun ipv4SubnetCalculation() {
        val s = ok(Ipv4Calculator.calculate("192.168.1.10/24", null))
        assertEquals("192.168.1.0", s.network.toString())
        assertEquals("192.168.1.255", s.broadcast.toString())
        assertEquals("192.168.1.1", s.firstHost.toString())
        assertEquals("192.168.1.254", s.lastHost.toString())
        assertEquals("255.255.255.0", s.mask.toString())
        assertEquals("0.0.0.255", s.wildcard.toString())
        assertEquals(254L, s.usableHosts)
        assertEquals(256L, s.totalAddresses)
        assertEquals("C", s.addressClass)
        assertEquals("Privée (RFC 1918)", s.addressType)
        val withMask = ok(Ipv4Calculator.calculate("10.1.2.3", "255.255.240.0"))
        assertEquals(20, withMask.prefix)
        assertEquals("10.1.0.0", withMask.network.toString())
        assertEquals(2L, ok(Ipv4Calculator.calculate("10.0.0.0/31", null)).usableHosts)
        assertEquals(1L, ok(Ipv4Calculator.calculate("8.8.8.8/32", null)).usableHosts)
        assertEquals(4294967296L, ok(Ipv4Calculator.calculate("0.0.0.0/0", null)).totalAddresses)
        assertEquals("Publique", ok(Ipv4Calculator.calculate("8.8.8.8/32", null)).addressType)
        assertEquals("Boucle locale (loopback)", Ipv4Calculator.addressType(Ipv4.parse("127.0.0.1")))
        assertEquals("Partagée CGNAT (RFC 6598)", Ipv4Calculator.addressType(Ipv4.parse("100.64.1.1")))
    }

    @Test
    fun ipv4InputValidation() {
        assertTrue(err(Ipv4Calculator.calculate("192.168.1.256/24", null)).contains("255"))
        assertTrue(err(Ipv4Calculator.calculate("192.168.01.1/24", null)).contains("ambigu"))
        assertTrue(err(Ipv4Calculator.calculate("192.168.1/24", null)).contains("4 nombres"))
        assertTrue(err(Ipv4Calculator.calculate("192.168.1.1/33", null)).contains("0 et 32"))
        assertTrue(err(Ipv4Calculator.calculate("192.168.1.1", "255.0.255.0")).contains("non contigu"))
        assertTrue(err(Ipv4Calculator.calculate("192.168.1.1", null)).contains("préfixe"))
    }

    @Test
    fun binaryConversions() {
        val ip = Ipv4.parse("192.168.1.1")
        assertEquals("11000000.10101000.00000001.00000001", ip.toBinary())
        assertEquals("0xC0A80101", ip.toHex())
        assertEquals(3232235777L, ip.value)
        assertEquals("192.168.1.1", Ipv4.fromBinary("11000000.10101000.1.1").toString())
        assertEquals("192.168.1.1", Ipv4.fromBinary("11000000101010000000000100000001").toString())
        assertTrue(runCatching { Ipv4.fromBinary("1100") }.isFailure)
        assertTrue(runCatching { Ipv4.fromBinary("2".repeat(32)) }.isFailure)
    }

    @Test
    fun rangeToCidrAndSubnetting() {
        val a = ok(Ipv4Calculator.rangeToCidrs(Ipv4.parse("192.168.0.0"), Ipv4.parse("192.168.0.255")))
        assertEquals(listOf("192.168.0.0/24"), a.map { "${it.first}/${it.second}" })
        val b = ok(Ipv4Calculator.rangeToCidrs(Ipv4.parse("10.0.0.1"), Ipv4.parse("10.0.0.6")))
        assertEquals(listOf("10.0.0.1/32", "10.0.0.2/31", "10.0.0.4/31", "10.0.0.6/32"), b.map { "${it.first}/${it.second}" })
        val all = ok(Ipv4Calculator.rangeToCidrs(Ipv4.parse("0.0.0.0"), Ipv4.parse("255.255.255.255")))
        assertEquals(listOf("0.0.0.0/0"), all.map { "${it.first}/${it.second}" })
        assertTrue(Ipv4Calculator.rangeToCidrs(Ipv4.parse("10.0.0.2"), Ipv4.parse("10.0.0.1")) is Outcome.Err)

        val split = ok(Ipv4Calculator.split(Ipv4.parse("192.168.1.0"), 24, 26))
        assertEquals(4L, split.totalSubnets)
        assertEquals(listOf("192.168.1.0", "192.168.1.64", "192.168.1.128", "192.168.1.192"), split.subnets.map { it.network.toString() })
        assertTrue(ok(Ipv4Calculator.split(Ipv4.parse("10.0.0.0"), 8, 24)).truncated)
        assertEquals(27, ok(Ipv4Calculator.prefixForSubnetCount(24, 5)))
        assertEquals(26, ok(Ipv4Calculator.prefixForHosts(50)))
        assertEquals(30, ok(Ipv4Calculator.prefixForHosts(2)))
        assertEquals(29, ok(Ipv4Calculator.prefixForHosts(3)))
        assertEquals(32, ok(Ipv4Calculator.prefixForHosts(1)))
        assertTrue(Ipv4Calculator.prefixForHosts(0) is Outcome.Err)
        assertTrue(ok(Ipv4Calculator.contains("10.0.0.0/8", "10.200.1.1")))
        assertTrue(!ok(Ipv4Calculator.contains("10.0.0.0/8", "11.0.0.1")))
    }

    @Test
    fun userAgentParsing() {
        val chrome = UserAgentParser.parse("Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/129.0.0.0 Mobile Safari/537.36")!!
        assertEquals("Chrome", chrome.browser); assertEquals("129.0.0.0", chrome.browserVersion)
        assertEquals("Android", chrome.os); assertEquals("Mobile", chrome.deviceType); assertNull(chrome.deviceModel)
        assertEquals("Blink", chrome.engine)
        val iphone = UserAgentParser.parse("Mozilla/5.0 (iPhone; CPU iPhone OS 17_4 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.4 Mobile/15E148 Safari/604.1")!!
        assertEquals("Safari", iphone.browser); assertEquals("17.4", iphone.osVersion); assertEquals("iPhone", iphone.deviceModel)
        val edge = UserAgentParser.parse("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/129.0.0.0 Safari/537.36 Edg/129.0.2792.79")!!
        assertEquals("Microsoft Edge", edge.browser); assertEquals("Windows", edge.os); assertEquals("Ordinateur", edge.deviceType)
        val firefox = UserAgentParser.parse("Mozilla/5.0 (X11; Linux x86_64; rv:131.0) Gecko/20100101 Firefox/131.0")!!
        assertEquals("Firefox", firefox.browser); assertEquals("Gecko", firefox.engine); assertEquals("Linux", firefox.os)
        val samsung = UserAgentParser.parse("Mozilla/5.0 (Linux; Android 14; SM-S918B) AppleWebKit/537.36 (KHTML, like Gecko) SamsungBrowser/25.0 Chrome/121.0.0.0 Mobile Safari/537.36")!!
        assertEquals("Samsung Internet", samsung.browser); assertEquals("SM-S918B", samsung.deviceModel)
        val bot = UserAgentParser.parse("Mozilla/5.0 (compatible; Googlebot/2.1; +http://www.google.com/bot.html)")!!
        assertTrue(bot.isBot)
        assertNull(UserAgentParser.parse("  "))
    }

    @Test
    fun colorConversions() {
        val c = ok(ColorConverter.parse("#1E88E5"))
        assertEquals("rgb(30, 136, 229)", c.rgb)
        assertEquals("#1E88E5", ok(ColorConverter.parse("30, 136, 229")).hex)
        assertEquals("#1E88E5", ok(ColorConverter.parse("rgb(30,136,229)")).hex)
        assertEquals("#1E88E5", ok(ColorConverter.parse("1e88e5")).hex)
        assertEquals("#FFFFFF", ok(ColorConverter.parse("#fff")).hex)
        assertEquals("hsl(0, 100 %, 50 %)", ok(ColorConverter.parse("#FF0000")).hsl)
        assertEquals("cmjn(0 %, 100 %, 100 %, 0 %)", ok(ColorConverter.parse("#FF0000")).cmyk)
        assertEquals(21.0, ok(ColorConverter.parse("#000000")).contrastWithWhite, 1e-9)
        assertEquals(1.0, ok(ColorConverter.parse("#000")).contrastWithBlack, 1e-9)
        val alpha = ok(ColorConverter.parse("#1E88E580"))
        assertEquals("#1E88E580", alpha.hexWithAlpha)
        assertEquals(128, alpha.color.alpha)
        assertTrue(err(ColorConverter.parse("#12345")).contains("HEX"))
        assertTrue(err(ColorConverter.parse("300, 0, 0")).contains("0 à 255"))
        assertTrue(err(ColorConverter.parse("")).isNotEmpty())
    }
}
