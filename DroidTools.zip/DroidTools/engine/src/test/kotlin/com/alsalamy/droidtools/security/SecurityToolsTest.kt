package com.alsalamy.droidtools.security

import com.alsalamy.droidtools.core.Outcome
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.ByteArrayInputStream
import java.security.SecureRandom

class SecurityToolsTest {

    private val random = SecureRandom()
    private fun <T> ok(o: Outcome<T>): T = (o as? Outcome.Ok)?.value ?: throw AssertionError("Succès attendu : ${o.errorOrNull()}")
    private fun err(o: Outcome<*>): String = o.errorOrNull() ?: throw AssertionError("Erreur attendue")

    @Test
    fun passwordsContainEverySelectedClass() {
        repeat(200) {
            val p = ok(SecureGenerators.password(SecureGenerators.PasswordOptions(length = 12), random)).value
            assertEquals(12, p.length)
            assertTrue(p.any { it.isLowerCase() } && p.any { it.isUpperCase() } && p.any { it.isDigit() })
            assertTrue(p.any { it in SecureGenerators.SYMBOLS })
        }
        val noAmbiguous = SecureGenerators.PasswordOptions(length = 128, excludeAmbiguous = true)
        repeat(20) { assertTrue(ok(SecureGenerators.password(noAmbiguous, random)).value.none { it in SecureGenerators.AMBIGUOUS }) }
        val digitsOnly = ok(SecureGenerators.password(SecureGenerators.PasswordOptions(16, false, false, true, false), random))
        assertTrue(digitsOnly.value.all { it.isDigit() })
        assertEquals(16 * SecureGenerators.log2(10.0), digitsOnly.entropyBits, 1e-9)
        assertTrue(err(SecureGenerators.password(SecureGenerators.PasswordOptions(12, false, false, false, false), random)).contains("au moins"))
        assertTrue(err(SecureGenerators.password(SecureGenerators.PasswordOptions(length = 3), random)).contains("longueur"))
        assertEquals(500, List(500) { ok(SecureGenerators.password(SecureGenerators.PasswordOptions(), random)).value }.toSet().size)
    }

    @Test
    fun pinsAreDigitsAndTrivialOnesAreRejected() {
        repeat(300) {
            val pin = ok(SecureGenerators.pin(SecureGenerators.PinOptions(4, avoidTrivial = true), random)).value
            assertEquals(4, pin.length)
            assertTrue(pin.all { it.isDigit() })
            assertFalse(SecureGenerators.isTrivialPin(pin))
        }
        listOf("1234", "0000", "9876", "1212", "123123", "2580", "8901").forEach { assertTrue(it, SecureGenerators.isTrivialPin(it)) }
        listOf("7392", "4817", "305926").forEach { assertFalse(it, SecureGenerators.isTrivialPin(it)) }
        assertTrue(err(SecureGenerators.pin(SecureGenerators.PinOptions(3), random)).isNotEmpty())
    }

    @Test
    fun tokensHaveExpectedSize() {
        assertEquals(64, ok(SecureGenerators.token(32, SecureGenerators.TokenFormat.HEX, random)).value.length)
        val b64url = ok(SecureGenerators.token(32, SecureGenerators.TokenFormat.BASE64URL, random)).value
        assertEquals(43, b64url.length)
        assertTrue(b64url.none { it == '=' || it == '+' || it == '/' })
        assertTrue(SecureGenerators.token(4, SecureGenerators.TokenFormat.HEX, random) is Outcome.Err)
    }

    @Test
    fun uniformRandomNumbers() {
        repeat(1000) { assertTrue(SecureGenerators.uniformLong(-5, 5, random) in -5L..5L) }
        repeat(100) { SecureGenerators.uniformLong(Long.MIN_VALUE, Long.MAX_VALUE, random) }
        repeat(100) { assertTrue(SecureGenerators.uniformLong(-10, Long.MAX_VALUE, random) >= -10L) }
        val unique = ok(SecureGenerators.randomNumbers(SecureGenerators.RandomNumbersOptions(1, 49, 49, unique = true, sorted = true), random))
        assertEquals((1L..49L).toList(), unique)
        assertTrue(err(SecureGenerators.randomNumbers(SecureGenerators.RandomNumbersOptions(1, 5, 6, unique = true, sorted = false), random)).contains("distincts"))
        assertTrue(SecureGenerators.randomNumbers(SecureGenerators.RandomNumbersOptions(5, 1, 1, false, false), random) is Outcome.Err)
        // Distribution d'un d6 sur 12 000 lancers : chaque face ≈ 2 000 (écart type ≈ 41).
        val counts = IntArray(7)
        repeat(600) { ok(SecureGenerators.rollDice(20, 6, random)).forEach { counts[it]++ } }
        for (face in 1..6) assertTrue("Face $face : ${counts[face]}", counts[face] in 1750..2250)
        assertEquals(0, counts[0])
    }

    @Test
    fun passphrases() {
        assertTrue("Dictionnaire trop petit : ${Passphrase.dictionarySize}", Passphrase.dictionarySize >= 1296)
        assertEquals(Passphrase.dictionarySize, WordList.words.toSet().size)
        assertTrue(WordList.words.all { Regex("[a-z]{3,12}").matches(it) })
        val p = ok(Passphrase.generate(Passphrase.Options(words = 6, separator = "-", capitalize = true, appendDigit = true), random))
        val parts = p.value.split("-")
        assertEquals(6, parts.size)
        assertTrue(parts.all { it[0].isUpperCase() })
        assertEquals(1, parts.count { it.last().isDigit() })
        assertTrue(p.entropyBits > 6 * 10)
        assertTrue(Passphrase.generate(Passphrase.Options(words = 2), random) is Outcome.Err)
    }

    @Test
    fun passwordStrengthEstimation() {
        assertEquals(PasswordStrength.Level.VERY_WEAK, PasswordStrength.analyze("123456").level)
        assertEquals(PasswordStrength.Level.VERY_WEAK, PasswordStrength.analyze("azerty").level)
        assertEquals(PasswordStrength.Level.VERY_WEAK, PasswordStrength.analyze("P@ssw0rd").level)
        assertEquals(PasswordStrength.Level.VERY_WEAK, PasswordStrength.analyze("").level)
        assertTrue(PasswordStrength.analyze("Marseille2024!").level.score <= 2)
        assertTrue(PasswordStrength.analyze("aaaaaaaaaaaaaaaa").level.score <= 1)
        repeat(20) {
            val strong = ok(SecureGenerators.password(SecureGenerators.PasswordOptions(length = 20), random)).value
            assertTrue(strong, PasswordStrength.analyze(strong).level.score >= 3)
        }
        val phrase = ok(Passphrase.generate(Passphrase.Options(words = 7), random)).value
        assertTrue(phrase, PasswordStrength.analyze(phrase).level.score >= 3)
        assertTrue(PasswordStrength.analyze("123456").warnings.isNotEmpty())
    }

    @Test
    fun hashesMatchReferenceVectors() {
        assertEquals("ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad", Hashing.text("abc", HashAlgorithm.SHA256).hex)
        assertEquals("e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855", Hashing.text("", HashAlgorithm.SHA256).hex)
        assertTrue(Hashing.text("abc", HashAlgorithm.SHA512).hex.startsWith("ddaf35a193617abacc417349ae204131"))
        assertEquals(128, Hashing.text("abc", HashAlgorithm.SHA512).hex.length)
        assertEquals("900150983cd24fb0d6963f7d28e17f72", Hashing.text("abc", HashAlgorithm.MD5).hex)
        assertEquals("d41d8cd98f00b204e9800998ecf8427e", Hashing.text("", HashAlgorithm.MD5).hex)
        assertEquals("a9993e364706816aba3e25717850c26c9cd0d89d", Hashing.text("abc", HashAlgorithm.SHA1).hex)
    }

    @Test
    fun streamHashingMatchesInMemoryHashing() {
        val data = ByteArray(300_000) { (it * 31).toByte() }
        var lastProgress = 0L
        val result = Hashing.stream(ByteArrayInputStream(data), listOf(HashAlgorithm.SHA256, HashAlgorithm.MD5), onProgress = { lastProgress = it })
        assertEquals(Hashing.bytes(data, HashAlgorithm.SHA256), result[HashAlgorithm.SHA256])
        assertEquals(Hashing.bytes(data, HashAlgorithm.MD5), result[HashAlgorithm.MD5])
        assertEquals(300_000L, lastProgress)
        val cancelled = runCatching { Hashing.stream(ByteArrayInputStream(data), listOf(HashAlgorithm.SHA256), isCancelled = { true }) }
        assertTrue(cancelled.isFailure)
    }

    @Test
    fun hashComparison() {
        val h = Hashing.text("abc", HashAlgorithm.SHA256).hex
        assertEquals(HashComparison.EQUAL, ok(Hashing.compare(h, " " + h.uppercase().chunked(8).joinToString(" "))))
        assertEquals(HashComparison.DIFFERENT, ok(Hashing.compare(h, h.replaceRange(0, 1, "0"))))
        assertEquals(HashComparison.INVALID, ok(Hashing.compare(h, "zzz")))
        assertTrue(Hashing.compare("", h) is Outcome.Err)
        assertEquals(HashAlgorithm.SHA256, Hashing.guessAlgorithm(h))
        assertEquals(HashAlgorithm.MD5, Hashing.guessAlgorithm("D41D8CD98F00B204E9800998ECF8427E"))
        assertNull(Hashing.guessAlgorithm("xyz"))
    }
}
