package com.alsalamy.droidtools.domain

import com.alsalamy.droidtools.core.TextNormalizer
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class ToolSearchTest {

    private fun ids(query: String) = ToolSearch.search(query).map { it.id }

    @Test
    fun normalizationIgnoresAccentsCaseAndPunctuation() {
        assertEquals("securite reseau", TextNormalizer.normalize("  SÉCURITÉ — Réseau "))
        assertEquals("mot de passe", TextNormalizer.normalize("mot-de-passe"))
        assertEquals("coeur", TextNormalizer.normalize("Cœur"))
    }

    @Test
    fun notImplementedToolsAreNeverFound() {
        // Wi-Fi, PDF, QR : outils de la feuille de route, absents de l'application.
        assertTrue(ids("wifi").isEmpty())
        assertTrue(ToolSearch.search("pdf").none { !it.isAvailable })
        assertTrue(ToolSearch.search("qr").isEmpty())
    }

    @Test
    fun ipFindsNetworkTools() {
        val r = ids("ip")
        assertTrue(r.contains("ipv4_calculator"))
        assertTrue(ToolSearch.search("ip").take(6).all { it.category == ToolCategory.NETWORK })
    }

    @Test
    fun passwordQueryRanksGeneratorFirst() {
        assertEquals("password_generator", ids("mot de passe").first())
        assertEquals("password_generator", ids("Mot de passe").first())
        assertTrue(ids("mot de passe").contains("password_strength"))
    }

    @Test
    fun colorQueryFindsColorTool() {
        assertEquals("color_converter", ids("couleur").first())
        assertEquals("color_converter", ids("hex").first())
    }

    @Test
    fun accentInsensitive() {
        assertTrue(ids("securite").isNotEmpty())
        assertEquals(ids("sécurité"), ids("securite"))
        assertEquals("convert_temperature", ids("température").first())
        assertEquals("vat", ids("tva").first())
    }

    @Test
    fun allTokensMustMatch() {
        assertTrue(ids("json minifier").first() == "json_minifier")
        assertTrue(ids("zzzz inexistant").isEmpty())
        assertTrue(ids("   ").isEmpty())
    }
}
