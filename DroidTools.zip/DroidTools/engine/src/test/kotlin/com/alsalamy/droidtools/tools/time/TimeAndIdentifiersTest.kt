package com.alsalamy.droidtools.tools.time

import com.alsalamy.droidtools.core.Outcome
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.security.SecureRandom
import java.time.Instant
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.ZoneId
import java.time.ZoneOffset

class TimeAndIdentifiersTest {

    private val utc: ZoneId = ZoneOffset.UTC
    private val paris: ZoneId = ZoneId.of("Europe/Paris")
    private val now: Instant = Instant.parse("2026-11-02T12:00:00Z")
    private val random = SecureRandom()

    private fun <T> ok(o: Outcome<T>): T = (o as? Outcome.Ok)?.value ?: throw AssertionError("Succès attendu : ${o.errorOrNull()}")
    private fun err(o: Outcome<*>): String = o.errorOrNull() ?: throw AssertionError("Erreur attendue")

    @Test
    fun timestampToDateWithUnitDetection() {
        val epoch = ok(TimeTools.fromTimestamp("0", TimestampUnit.AUTO, utc, now))
        assertEquals("1970-01-01T00:00:00Z", epoch.utcIso)
        assertEquals(TimestampUnit.SECONDS, epoch.detectedUnit)
        val ms = ok(TimeTools.fromTimestamp("1700000000123", TimestampUnit.AUTO, utc, now))
        assertEquals(TimestampUnit.MILLISECONDS, ms.detectedUnit)
        assertEquals("2023-11-14T22:13:20.123Z", ms.utcIso)
        val ns = ok(TimeTools.fromTimestamp("1700000000123456789", TimestampUnit.AUTO, utc, now))
        assertEquals("2023-11-14T22:13:20.123456789Z", ns.utcIso)
        val negative = ok(TimeTools.fromTimestamp("-1", TimestampUnit.SECONDS, utc, now))
        assertEquals("1969-12-31T23:59:59Z", negative.utcIso)
        val negMs = ok(TimeTools.fromTimestamp("-1500", TimestampUnit.MILLISECONDS, utc, now))
        assertEquals("1969-12-31T23:59:58.500Z", negMs.utcIso)
        val local = ok(TimeTools.fromTimestamp("1704067200", TimestampUnit.SECONDS, paris, now))
        assertEquals("2024-01-01T01:00:00+01:00", local.localIso)
        assertEquals("Lundi 1 janvier 2024 à 01:00:00", local.localReadable)
        assertTrue(err(TimeTools.fromTimestamp("12a", TimestampUnit.AUTO, utc, now)).contains("entier"))
        assertTrue(err(TimeTools.fromTimestamp("99999999999999999", TimestampUnit.SECONDS, utc, now)).contains("plage"))
    }

    @Test
    fun relativeTimes() {
        assertEquals("il y a 3 jours", TimeTools.relative(now.minusSeconds(3 * 86_400), now))
        assertEquals("dans 2 heures", TimeTools.relative(now.plusSeconds(7_200), now))
        assertEquals("à l'instant", TimeTools.relative(now, now))
        assertEquals("il y a 1 minute", TimeTools.relative(now.minusSeconds(61), now))
    }

    @Test
    fun dateToTimestampWithDaylightSavingWarnings() {
        val r = ok(TimeTools.toTimestamp("01/01/2024 00:00", utc))
        assertEquals(1704067200L, r.epochSeconds)
        assertNull(r.dstWarning)
        assertEquals(1704067200000L, ok(TimeTools.toTimestamp("2024-01-01T00:00:00Z", paris)).epochMillis)
        assertEquals(1704063600L, ok(TimeTools.toTimestamp("2024-01-01 00:00:00", paris)).epochSeconds)
        assertNotNull(ok(TimeTools.toTimestamp("31/03/2024 02:30", paris)).dstWarning)
        assertNotNull(ok(TimeTools.toTimestamp("27/10/2024 02:30", paris)).dstWarning)
        assertTrue(err(TimeTools.toTimestamp("31/02/2024", utc)).contains("invalide"))
        assertTrue(err(TimeTools.toTimestamp("demain", utc)).contains("Formats"))
    }

    @Test
    fun dateDifferenceAndBusinessDays() {
        val d = TimeTools.difference(LocalDate.of(2024, 1, 1), LocalDate.of(2024, 12, 31))
        assertEquals(365L, d.totalDays)
        assertEquals(52L, d.weeks)
        assertEquals(1L, d.remainingDays)
        assertEquals(11, d.period.months)
        assertEquals(30, d.period.days)
        assertEquals(366L, TimeTools.difference(LocalDate.of(2024, 1, 1), LocalDate.of(2024, 12, 31), includeEndDay = true).totalDays)
        assertTrue(TimeTools.difference(LocalDate.of(2024, 5, 1), LocalDate.of(2024, 4, 1)).negative)
        // Du lundi 4 au lundi 11 mars 2024 : 5 jours ouvrés.
        assertEquals(5L, TimeTools.businessDaysBetween(LocalDate.of(2024, 3, 4), LocalDate.of(2024, 3, 11)))
        assertEquals(0L, TimeTools.businessDaysBetween(LocalDate.of(2024, 3, 9), LocalDate.of(2024, 3, 11)))
        assertEquals(261L, TimeTools.businessDaysBetween(LocalDate.of(2025, 1, 1), LocalDate.of(2026, 1, 1)))
    }

    @Test
    fun ageCalculation() {
        val a = ok(TimeTools.age(LocalDate.of(2000, 2, 29), LocalDate.of(2025, 3, 1)))
        assertEquals(25, a.years); assertEquals(0, a.months); assertEquals(1, a.days)
        assertEquals(LocalDate.of(2026, 2, 28), a.nextBirthday)
        assertEquals(26, a.nextAge)
        assertEquals("mardi", a.bornOn)
        assertFalse(a.isBirthdayToday)
        val today = ok(TimeTools.age(LocalDate.of(1990, 11, 2), LocalDate.of(2026, 11, 2)))
        assertTrue(today.isBirthdayToday)
        assertEquals(36, today.years)
        assertEquals(LocalDate.of(2027, 11, 2), today.nextBirthday)
        assertTrue(err(TimeTools.age(LocalDate.of(2030, 1, 1), LocalDate.of(2026, 1, 1))).contains("futur"))
    }

    @Test
    fun countdown() {
        val c = ok(TimeTools.countdown(LocalDateTime.of(2026, 11, 3, 13, 1, 1), utc, now))
        assertFalse(c.past)
        assertEquals(1L, c.days); assertEquals(1L, c.hours); assertEquals(1L, c.minutes); assertEquals(1L, c.seconds)
        assertTrue(ok(TimeTools.countdown(LocalDateTime.of(2020, 1, 1, 0, 0), utc, now)).past)
    }

    @Test
    fun ulidEncodingMatchesSpecification() {
        // Vecteur de la spécification ULID : ulid(1469918176385) commence par 01ARYZ6S41.
        assertEquals("01ARYZ6S410000000000000000", Ulid.encode(1469918176385L, ByteArray(10)))
        assertEquals("00000000000000000000000000", Ulid.encode(0, ByteArray(10)))
        assertEquals("7ZZZZZZZZZZZZZZZZZZZZZZZZZ", Ulid.encode(Ulid.MAX_TIMESTAMP, ByteArray(10) { -1 }))
        val generated = Ulid.generate(1700000000000L, random)
        assertEquals(26, generated.length)
        val decoded = ok(Ulid.decode(generated.lowercase()))
        assertEquals(1700000000000L, decoded.timestamp.toEpochMilli())
        assertEquals(20, decoded.randomHex.length)
        assertTrue(Ulid.generate(1L, random) < Ulid.generate(2L, random))
        assertTrue(err(Ulid.decode("8ZZZZZZZZZZZZZZZZZZZZZZZZZ")).contains("48 bits"))
        assertTrue(err(Ulid.decode("abc")).contains("26"))
        assertTrue(err(Ulid.decode("0000000000000000000000000U")).contains("invalide"))
    }

    @Test
    fun uuidVersions() {
        val v4 = Uuids.v4(random)
        assertEquals(4, v4.version()); assertEquals(2, v4.variant())
        val v7 = Uuids.v7(1700000000000L, random)
        assertEquals(7, v7.version()); assertEquals(2, v7.variant())
        assertEquals(1700000000000L, Uuids.v7Timestamp(v7))
        assertNull(Uuids.v7Timestamp(v4))
        assertTrue(Uuids.v7(1000L, random).toString() < Uuids.v7(2000L, random).toString())
        val formatted = Uuids.format(v4, uppercase = true, hyphens = false)
        assertEquals(32, formatted.length)
        assertEquals(formatted, formatted.uppercase())
        assertEquals(100, List(100) { Uuids.v4(random) }.toSet().size)
    }
}
