package com.alsalamy.droidtools.tools.text

import com.alsalamy.droidtools.core.Outcome
import com.alsalamy.droidtools.tools.codec.Base64Codec
import com.alsalamy.droidtools.tools.codec.UrlCodec
import com.alsalamy.droidtools.tools.codec.UrlEncodingMode
import com.alsalamy.droidtools.tools.json.Json
import com.alsalamy.droidtools.tools.json.JsonIndent
import com.alsalamy.droidtools.tools.json.JsonValue
import com.alsalamy.droidtools.tools.xml.XmlFormatter
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class TextAndDevToolsTest {

    private fun <T> ok(o: Outcome<T>): T = (o as? Outcome.Ok)?.value ?: throw AssertionError("Succès attendu : ${o.errorOrNull()}")
    private fun err(o: Outcome<*>): String = o.errorOrNull() ?: throw AssertionError("Erreur attendue")

    // ------------------------------------------------------------ Statistiques et transformations

    @Test
    fun textStatistics() {
        val s = TextStatistics.analyze("Bonjour le monde. Aujourd'hui, c'est l'été !\n\nDeuxième paragraphe")
        assertEquals(8, s.words)
        assertEquals(3, s.lines)
        assertEquals(2, s.nonEmptyLines)
        assertEquals(2, s.paragraphs)
        assertEquals(3, s.sentences)
        assertEquals(0, TextStatistics.analyze("").words)
        assertEquals(0, TextStatistics.analyze("").lines)
        assertEquals(1, TextStatistics.graphemeCount("e\u0301"))
        assertEquals(3, TextStatistics.graphemeCount("été"))
        assertEquals(6, TextStatistics.analyze("héllo").utf8Bytes)
    }

    @Test
    fun caseTransforms() {
        assertEquals("ÉCOLE", TextTransforms.apply("école", TextOperation.UPPERCASE).text)
        assertEquals("école", TextTransforms.apply("ÉCOLE", TextOperation.LOWERCASE).text)
        assertEquals("Jean-Pierre Aime L'été", TextTransforms.apply("jean-pierre AIME l'été", TextOperation.CAPITALIZE_WORDS).text)
        assertEquals("Bonjour. Ça va ? Oui", TextTransforms.apply("bonjour. ça va ? OUI", TextOperation.CAPITALIZE_SENTENCES).text)
    }

    @Test
    fun lineOperations() {
        assertEquals("a b\nc", TextTransforms.apply("  a   b \t\n\n\n c  ", TextOperation.CLEAN_SPACES, TransformOptions(removeEmptyLines = true)).text)
        assertEquals("a b\n\nc", TextTransforms.apply("  a   b \n\n\n c  ", TextOperation.CLEAN_SPACES).text)
        assertEquals("pomme\npoire", TextTransforms.apply("pomme\npoire\npomme", TextOperation.DEDUPE_LINES).text)
        assertEquals("Pomme\npoire", TextTransforms.apply("Pomme\npoire\npomme", TextOperation.DEDUPE_LINES, TransformOptions(ignoreCase = true)).text)
        assertEquals("eau\nécole\nfleur", TextTransforms.apply("fleur\nécole\neau", TextOperation.SORT_LINES).text)
        assertEquals("fleur\nécole\neau", TextTransforms.apply("eau\nécole\nfleur", TextOperation.SORT_LINES, TransformOptions(sortOrder = SortOrder.DESCENDING)).text)
        assertEquals("2 a\n10 b\nx", TextTransforms.apply("x\n10 b\n2 a", TextOperation.SORT_LINES, TransformOptions(sortOrder = SortOrder.NUMERIC)).text)
        assertEquals("c\nb\na", TextTransforms.apply("a\nb\nc", TextOperation.REVERSE_LINES).text)
    }

    @Test
    fun reverseKeepsCombiningMarks() {
        assertEquals("ae\u0301", TextTransforms.reverseGraphemes("e\u0301a"))
        assertEquals("ruojnob", TextTransforms.reverseGraphemes("bonjour"))
    }

    @Test
    fun findReplace() {
        assertEquals("a-b c", ok(FindReplace.run("a.b c", ".", "-", FindReplaceOptions())).output)
        val r = ok(FindReplace.run("chat chaton CHAT", "chat", "chien", FindReplaceOptions(ignoreCase = true, wholeWord = true)))
        assertEquals("chien chaton chien", r.output)
        assertEquals(2, r.replacements)
        assertEquals("2024-03-01", ok(FindReplace.run("01/03/2024", "(\\d+)/(\\d+)/(\\d+)", "$3-$2-$1", FindReplaceOptions(useRegex = true))).output)
        assertEquals("prix : $5", ok(FindReplace.run("prix : X", "X", "$5", FindReplaceOptions())).output)
        assertTrue(err(FindReplace.run("abc", "(", "x", FindReplaceOptions(useRegex = true))).contains("invalide"))
        assertTrue(err(FindReplace.run("abc", "", "x", FindReplaceOptions())).isNotEmpty())
    }

    @Test
    fun regexTesterWithNamedGroupsAndTimeout() {
        val r = ok(SafeRegex.test("(?<annee>\\d{4})-(\\d{2})", "2024-03 et 1999-12"))
        assertEquals(2, r.matches.size)
        assertEquals("annee", r.matches[0].groups[0].name)
        assertEquals("2024", r.matches[0].groups[0].value)
        assertNull(r.matches[0].groups[1].name)
        assertEquals("1999-12", r.matches[1].value)
        assertEquals(mapOf(2 to "b"), SafeRegex.groupNames("(?:x)[(](a)(?<b>c)(?=d)\\(e"))
        val started = System.nanoTime()
        // Référence arrière : reste exponentiel même avec la mémoïsation du JDK 9+.
        val timeout = SafeRegex.test("^(a+)+\\1b$", "a".repeat(34))
        val elapsedMs = (System.nanoTime() - started) / 1_000_000
        assertTrue(err(timeout).contains("interrompue"))
        assertTrue("Délai trop long : $elapsedMs ms", elapsedMs < 5000)
        assertTrue(err(SafeRegex.test("", "abc")).isNotEmpty())
        // Sur la JVM, le calcul abandonné s'arrête de lui-même : le compteur revient à zéro.
        var waited = 0
        while (SafeRegex.abandonedCount > 0 && waited < 3000) { Thread.sleep(50); waited += 50 }
        assertEquals(0, SafeRegex.abandonedCount)
        assertTrue(err(SafeRegex.test("a", "a".repeat(SafeRegex.MAX_TEXT_LENGTH + 1))).contains("trop long"))
    }

    // ------------------------------------------------------------ Encodages

    @Test
    fun base64() {
        assertEquals("SMOpbGxvIHfDtnJsZCDinJM=", Base64Codec.encode("Héllo wörld ✓"))
        assertEquals("Héllo wörld ✓", ok(Base64Codec.decode("SMOpbGxvIHfDtnJsZCDinJM=")).text)
        assertEquals("Héllo wörld ✓", ok(Base64Codec.decode("SMOpbGxvIHfDtnJsZCDinJM")).text)
        assertEquals("fn5+", Base64Codec.encode("~~~"))
        assertEquals("fn5-", Base64Codec.encode("~~~", urlSafe = true))
        assertEquals("~~~", ok(Base64Codec.decode("fn5-")).text)
        assertTrue(err(Base64Codec.decode("fn5-+")).contains("Mélange"))
        assertEquals(">?", ok(Base64Codec.decode("Pj8")).text)
        assertEquals(">?", ok(Base64Codec.decode("Pj8=")).text)
        val binary = ok(Base64Codec.decode("/w=="))
        assertNull(binary.text)
        assertEquals("ff", binary.hex)
        assertTrue(err(Base64Codec.decode("abc*")).contains("invalide"))
        assertTrue(err(Base64Codec.decode("a")).contains("tronqué"))
        assertTrue(err(Base64Codec.decode("ab=c")).contains("mal placé"))
    }

    @Test
    fun urlEncoding() {
        assertEquals("a%20b%26c%3D%C3%A9~%2A", UrlCodec.encode("a b&c=é~*", UrlEncodingMode.COMPONENT))
        assertEquals("a+b%26c%3D%C3%A9%7E*", UrlCodec.encode("a b&c=é~*", UrlEncodingMode.FORM))
        assertEquals("a b&c=é", ok(UrlCodec.decode("a%20b%26c%3D%C3%A9", UrlEncodingMode.COMPONENT)))
        assertEquals("1+1", ok(UrlCodec.decode("1+1", UrlEncodingMode.COMPONENT)))
        assertEquals("1 1", ok(UrlCodec.decode("1+1", UrlEncodingMode.FORM)))
        assertTrue(err(UrlCodec.decode("100%", UrlEncodingMode.COMPONENT)).contains("invalide"))
        assertTrue(err(UrlCodec.decode("%G1", UrlEncodingMode.FORM)).contains("invalide"))
    }

    @Test
    fun stringEscaping() {
        assertEquals("ligne\\n\\\"citation\\\" \\\\ \\u0001", StringEscaper.escape("ligne\n\"citation\" \\ \u0001", EscapeFormat.JSON))
        assertEquals("prix \\$5", StringEscaper.escape("prix $5", EscapeFormat.JAVA_KOTLIN))
        assertEquals("&lt;a href=&quot;x&quot;&gt;l&#39;été &amp;&lt;/a&gt;", StringEscaper.escape("<a href=\"x\">l'été &</a>", EscapeFormat.HTML))
        assertEquals("ligne\n\"é\" \u00e9", ok(StringEscaper.unescape("ligne\\n\\\"é\\\" \\u00e9", EscapeFormat.JSON)))
        assertEquals("<é> & € 😀", ok(StringEscaper.unescape("&lt;&eacute;&gt; &amp; &#8364; &#x1F600;", EscapeFormat.HTML)))
        assertEquals("&inconnu;", ok(StringEscaper.unescape("&inconnu;", EscapeFormat.HTML)))
        assertTrue(err(StringEscaper.unescape("\\q", EscapeFormat.JSON)).contains("inconnue"))
        assertTrue(err(StringEscaper.unescape("\\u12", EscapeFormat.JSON)).contains("incomplète"))
    }

    @Test
    fun unicodeInspector() {
        val report = UnicodeInspector.inspect("é\u200B😀")
        assertEquals(3, report.total)
        assertEquals("U+00E9", report.codePoints[0].notation)
        assertEquals("LATIN SMALL LETTER E WITH ACUTE", report.codePoints[0].name)
        assertEquals("C3 A9", report.codePoints[0].utf8)
        assertNotNull(report.codePoints[1].warning)
        assertEquals(1, report.warnings)
        assertEquals("U+1F600", report.codePoints[2].notation)
        assertEquals("D83D DE00", report.codePoints[2].utf16)
        assertEquals("F0 9F 98 80", report.codePoints[2].utf8)
    }

    // ------------------------------------------------------------ JSON

    @Test
    fun jsonFormatAndMinifyPreserveOrderAndNumbers() {
        val input = """{"b":1,"a":[true,null,1.0000000000000000001,-2E+3],"s":"é\n\"x\""}"""
        val formatted = ok(Json.format(input, JsonIndent.TWO))
        assertEquals(
            "{\n  \"b\": 1,\n  \"a\": [\n    true,\n    null,\n    1.0000000000000000001,\n    -2E+3\n  ],\n  \"s\": \"é\\n\\\"x\\\"\"\n}",
            formatted,
        )
        assertEquals(input, ok(Json.minify(formatted)))
        assertTrue(ok(Json.format(input, sortKeys = true)).indexOf("\"a\"") < ok(Json.format(input, sortKeys = true)).indexOf("\"b\""))
        assertEquals("{}", ok(Json.minify(" { } ")))
        assertEquals("\"\\u0001\"", ok(Json.minify("\"\\u0001\"")))
    }

    @Test
    fun jsonValidationReportsPosition() {
        val e1 = Json.errorOf(Json.parse("{\n  \"a\": 1,\n}"))!!
        assertTrue(e1.message.contains("Virgule finale"))
        assertEquals(3, e1.line)
        assertEquals(1, e1.column)
        assertTrue(Json.errorOf(Json.parse("{'a': 1}"))!!.message.contains("Nom de propriété"))
        assertTrue(Json.errorOf(Json.parse("['a']"))!!.message.contains("guillemets doubles"))
        assertTrue(Json.errorOf(Json.parse("[01]"))!!.message.contains("zéros"))
        assertTrue(Json.errorOf(Json.parse("[1] x"))!!.message.contains("après la fin"))
        assertTrue(Json.errorOf(Json.parse(""))!!.message.contains("vide"))
        assertTrue(Json.errorOf(Json.parse("\"a\tb\""))!!.message.contains("contrôle"))
        assertTrue(Json.errorOf(Json.parse("[".repeat(600) + "]".repeat(600)))!!.message.contains("profonde"))
        val analysis = Json.parse("{\"a\":1,\"a\":2,\"b\":{\"c\":[]}}").getOrThrow()
        assertEquals(listOf("a"), analysis.duplicateKeys)
        assertEquals(2, analysis.objectCount)
        assertEquals(1, analysis.arrayCount)
        assertEquals(JsonValue.Num("2"), (analysis.value as JsonValue.Obj).members[1].second)
    }

    // ------------------------------------------------------------ XML

    @Test
    fun xmlFormatter() {
        val xml = "<?xml version=\"1.0\"?><root a=\"1\"><!-- note --><item>texte &amp; plus</item><vide/><liste><x/><y>2</y></liste></root>"
        val expected = """
            <?xml version="1.0"?>
            <root a="1">
              <!-- note -->
              <item>texte &amp; plus</item>
              <vide/>
              <liste>
                <x/>
                <y>2</y>
              </liste>
            </root>
        """.trimIndent()
        assertEquals(expected, ok(XmlFormatter.format(xml)))
        assertEquals(xml, ok(XmlFormatter.minify(expected)))
        assertTrue(err(XmlFormatter.format("<a><b></a></b>")).contains("attendue"))
        assertTrue(err(XmlFormatter.format("<a></a><b></b>")).contains("racines"))
        assertTrue(err(XmlFormatter.format("<a>")).contains("jamais fermée"))
        assertTrue(err(XmlFormatter.format("<a x=\"1\" x=\"2\"/>")).contains("répété"))
        assertTrue(err(XmlFormatter.format("<a x=1/>")).contains("mal formé"))
        assertTrue(err(XmlFormatter.format("texte")).isNotEmpty())
        // Les entités ne sont jamais développées.
        val doctype = "<!DOCTYPE r [<!ENTITY e \"boom\">]><r>&e;</r>"
        assertTrue(ok(XmlFormatter.format(doctype)).contains("<r>&e;</r>"))
    }
}
