package com.alsalamy.droidtools.tools.calc

import com.alsalamy.droidtools.core.Num
import com.alsalamy.droidtools.core.Outcome

/** Touche du clavier de calculatrice. [spoken] est lu par TalkBack. */
sealed interface CalcKey {
    val label: String
    val spoken: String

    /** Insère [text] dans l'expression. */
    data class Insert(val text: String, override val label: String = text, override val spoken: String = label) : CalcKey

    data object Clear : CalcKey { override val label = "C"; override val spoken = "Effacer tout" }
    data object Backspace : CalcKey { override val label = "⌫"; override val spoken = "Effacer le dernier caractère" }
    data object Equals : CalcKey { override val label = "="; override val spoken = "Égal" }
    data object ToggleAngle : CalcKey { override val label = "DEG/RAD"; override val spoken = "Changer l'unité d'angle" }
    data object Answer : CalcKey { override val label = "Ans"; override val spoken = "Dernier résultat" }
}

data class CalculatorState(
    val expression: String = "",
    /** Aperçu du résultat pendant la saisie. */
    val preview: String? = null,
    val error: String? = null,
    /** Expression évaluée par le dernier « = ». */
    val lastExpression: String? = null,
    val answer: Double? = null,
    val angleMode: AngleMode = AngleMode.DEGREES,
    val justEvaluated: Boolean = false,
)

/** Logique du clavier : pure, sans état caché, testable. */
object Calculator {

    private const val BINARY_OPERATORS = "+−×÷^"
    private const val POSTFIX = "%!²³"
    private val functionSuffix = Regex("(asin|acos|atan|sinh|cosh|tanh|sin|cos|tan|ln|log2|log|sqrt|cbrt|abs|exp)\\($")
    private val lastNumber = Regex("[0-9.,]+$")

    val basicKeys: List<List<CalcKey>> = listOf(
        listOf(CalcKey.Clear, CalcKey.Insert("(", spoken = "Parenthèse ouvrante"), CalcKey.Insert(")", spoken = "Parenthèse fermante"), CalcKey.Insert("÷", spoken = "Divisé par")),
        listOf(digit("7"), digit("8"), digit("9"), CalcKey.Insert("×", spoken = "Multiplié par")),
        listOf(digit("4"), digit("5"), digit("6"), CalcKey.Insert("−", spoken = "Moins")),
        listOf(digit("1"), digit("2"), digit("3"), CalcKey.Insert("+", spoken = "Plus")),
        listOf(CalcKey.Insert("%", spoken = "Pour cent"), digit("0"), CalcKey.Insert(",", spoken = "Virgule"), CalcKey.Equals),
    )

    val scientificKeys: List<List<CalcKey>> = listOf(
        listOf(fn("sin"), fn("cos"), fn("tan"), CalcKey.ToggleAngle, CalcKey.Answer),
        listOf(fn("asin", "sin⁻¹"), fn("acos", "cos⁻¹"), fn("atan", "tan⁻¹"), CalcKey.Insert("π", spoken = "Pi"), CalcKey.Insert("e", spoken = "Constante e")),
        listOf(fn("ln"), fn("log"), CalcKey.Insert("√(", "√", "Racine carrée"), CalcKey.Insert("^", "xʸ", "Puissance"), CalcKey.Insert("²", "x²", "Au carré")),
        listOf(fn("exp"), fn("abs", "|x|"), CalcKey.Insert("!", "n!", "Factorielle"), CalcKey.Insert("³", "x³", "Au cube"), fn("cbrt", "∛")),
    )

    private fun digit(d: String) = CalcKey.Insert(d)
    private fun fn(name: String, label: String = name) = CalcKey.Insert("$name(", label, "Fonction $label")

    fun press(state: CalculatorState, key: CalcKey): CalculatorState = when (key) {
        CalcKey.Clear -> CalculatorState(answer = state.answer, angleMode = state.angleMode)
        CalcKey.Backspace -> backspace(state)
        CalcKey.Equals -> equals(state)
        CalcKey.ToggleAngle -> withPreview(
            state.copy(angleMode = if (state.angleMode == AngleMode.DEGREES) AngleMode.RADIANS else AngleMode.DEGREES),
        )
        CalcKey.Answer -> state.answer?.let { insert(state, plain(it)) } ?: state
        is CalcKey.Insert -> insert(state, key.text)
    }

    private fun plain(value: Double): String = Num.plain(value).replace('.', ',')

    private fun insert(state: CalculatorState, text: String): CalculatorState {
        var expression = state.expression
        if (state.justEvaluated) {
            val continues = text.first() in BINARY_OPERATORS || text.first() in POSTFIX
            expression = if (continues) expression else ""
        }
        when {
            text == "," -> {
                val current = lastNumber.find(expression)?.value
                if (current != null && (current.contains(',') || current.contains('.'))) return state
                if (current == null) expression += "0"
            }
            text.length == 1 && text[0] in BINARY_OPERATORS && text != "−" -> {
                if (expression.isEmpty()) {
                    // Opérateur en tête : on repart du dernier résultat s'il existe.
                    state.answer?.let { expression = plain(it) } ?: return state
                }
                if (expression.last() in BINARY_OPERATORS) expression = expression.dropLast(1)
                if (expression.isEmpty()) return state
            }
            text == "−" && expression.endsWith("−") -> return state
        }
        val next = expression + text
        if (next.length > ExpressionEvaluator.MAX_LENGTH) return state.copy(error = "Expression trop longue.")
        return withPreview(state.copy(expression = next, error = null, justEvaluated = false))
    }

    private fun backspace(state: CalculatorState): CalculatorState {
        if (state.justEvaluated) return CalculatorState(answer = state.answer, angleMode = state.angleMode)
        val e = state.expression
        if (e.isEmpty()) return state
        val fn = functionSuffix.find(e)
        val next = when {
            fn != null -> e.substring(0, fn.range.first)
            e.endsWith("√(") -> e.dropLast(2)
            else -> e.dropLast(1)
        }
        return withPreview(state.copy(expression = next, error = null))
    }

    private fun equals(state: CalculatorState): CalculatorState {
        if (state.expression.isBlank()) return state
        return when (val r = ExpressionEvaluator.evaluate(state.expression, state.angleMode)) {
            is Outcome.Ok -> CalculatorState(
                expression = plain(r.value),
                lastExpression = state.expression,
                answer = r.value,
                angleMode = state.angleMode,
                justEvaluated = true,
            )
            is Outcome.Err -> state.copy(error = r.message, preview = null)
        }
    }

    private fun withPreview(state: CalculatorState): CalculatorState {
        val e = state.expression
        // Pas d'aperçu pour un nombre seul : il n'apporterait rien.
        val worthPreview = e.isNotBlank() && !Regex("[−-]?[0-9.,]+").matches(e)
        val preview = if (worthPreview) {
            (ExpressionEvaluator.evaluate(e, state.angleMode) as? Outcome.Ok)?.value?.let { Num.formatDouble(it) }
        } else {
            null
        }
        return state.copy(preview = preview)
    }

    /** Résultat affichable avec séparateurs de milliers. */
    fun display(value: Double): String = Num.formatDouble(value, 15)
}
