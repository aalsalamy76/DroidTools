package com.alsalamy.droidtools.core

import java.math.BigDecimal

/** Tailles lisibles en unités binaires (Kio, Mio, Gio), avec séparateurs français. */
object ByteFormat {
    private val units = listOf("Kio", "Mio", "Gio", "Tio")

    fun format(bytes: Long): String {
        if (bytes < 0) return "—"
        if (bytes < 1024) return "${Num.format(BigDecimal(bytes))} octet" + if (bytes > 1) "s" else ""
        var value = BigDecimal(bytes)
        var unit = -1
        while (value >= BigDecimal(1024) && unit < units.size - 1) {
            value = value.divide(BigDecimal(1024), Num.MC)
            unit++
        }
        return Num.format(value, 3) + " " + units[unit]
    }
}
