package com.alsalamy.droidtools.domain

/** Catégories d'outils, dans l'ordre d'affichage. */
enum class ToolCategory(
    val label: String,
    val description: String,
    val icon: ToolIcon,
    /** Mots-clés génériques de la catégorie (recherche). */
    val keywords: List<String>,
) {
    CALCULATIONS("Calculs", "Calculatrices, pourcentages, TVA, moyennes", ToolIcon.CALCULATE, listOf("calcul", "calculatrice", "math", "maths")),
    CONVERSIONS("Conversions", "Unités, températures, bases numériques", ToolIcon.SWAP, listOf("conversion", "convertir", "unite", "unit")),
    NETWORK("Réseau / IT", "IPv4, CIDR, sous-réseaux, User-Agent", ToolIcon.LAN, listOf("reseau", "network", "it", "informatique")),
    QR("QR & codes-barres", "Lecture et génération de codes", ToolIcon.QR_CODE, listOf("qr", "qrcode", "code barre", "barcode")),
    DOCUMENTS("PDF & documents", "Numérisation et manipulation de PDF", ToolIcon.PDF, listOf("pdf", "document", "documents")),
    IMAGES("Couleurs", "HEX, RGB, HSL, CMJN et contraste", ToolIcon.PALETTE, listOf("couleur", "couleurs", "image", "images", "photo", "color")),
    TEXT_DEV("Texte & dev", "Texte, encodages, JSON, regex, dates", ToolIcon.CODE, listOf("texte", "text", "dev", "developpement", "code")),
    SECURITY("Sécurité", "Mots de passe, PIN, hachages", ToolIcon.SHIELD, listOf("securite", "security", "crypto")),
    SENSORS("Capteurs", "Mesures des capteurs de l'appareil", ToolIcon.SENSORS, listOf("capteur", "capteurs", "sensor", "mesure")),
    DEVICE_TESTS("Tests appareil", "Écran, tactile, vibration, son", ToolIcon.PHONE, listOf("test", "diagnostic", "appareil")),
    AUDIO("Audio", "Enregistrement, synthèse vocale, tonalités", ToolIcon.AUDIO, listOf("audio", "son", "sound")),
    DAILY("Quotidien", "Chronomètre, dates, hasard, checklist", ToolIcon.TODAY, listOf("quotidien", "pratique", "daily")),
}

/** Statut d'implémentation réel d'un outil. Ne jamais afficher un outil comme fonctionnel s'il ne l'est pas. */
enum class ToolStatus(val label: String, val displayName: String) {
    FUNCTIONAL("FONCTIONNEL", "Fonctionnel"),
    PARTIAL("PARTIEL", "Partiel"),
    NOT_IMPLEMENTED("NON IMPLÉMENTÉ", "Non implémenté"),
}

/** Ressources sensibles suivies par le centre de confidentialité. */
enum class SensitiveResource(val label: String) {
    CAMERA("Caméra"),
    MICROPHONE("Microphone"),
    LOCATION("Localisation"),
    FILES("Fichiers"),
    NETWORK("Réseau / Internet"),
}

/** Permissions Android qu'un outil peut nécessiter. */
enum class AppPermission(val label: String, val manifestName: String) {
    CAMERA("Caméra", "android.permission.CAMERA"),
    RECORD_AUDIO("Microphone", "android.permission.RECORD_AUDIO"),
    FINE_LOCATION("Localisation précise", "android.permission.ACCESS_FINE_LOCATION"),
    NEARBY_WIFI_DEVICES("Appareils Wi-Fi à proximité", "android.permission.NEARBY_WIFI_DEVICES"),
    INTERNET("Accès Internet", "android.permission.INTERNET"),
    ACCESS_NETWORK_STATE("État du réseau", "android.permission.ACCESS_NETWORK_STATE"),
    ACCESS_WIFI_STATE("État du Wi-Fi", "android.permission.ACCESS_WIFI_STATE"),
    VIBRATE("Vibration", "android.permission.VIBRATE"),
}

enum class Processing(val label: String) {
    LOCAL("LOCAL — tout le traitement a lieu sur l'appareil"),
    NETWORK("RÉSEAU — l'outil communique avec d'autres machines"),
}

/**
 * Fiche de confidentialité d'un outil implémenté.
 * Elle doit décrire exactement le comportement réel du code ; toute modification
 * de l'outil impose de la mettre à jour.
 */
data class PrivacySheet(
    val processing: Processing,
    val resources: Set<SensitiveResource>,
    val permissions: List<AppPermission>,
    /** Quand et pourquoi une ressource sensible est utilisée. */
    val resourceUsage: String,
    val dataHandled: String,
    val storage: String,
    val destination: String,
    val externalDependencies: String,
    val notes: List<String> = emptyList(),
) {
    val internetRequired: Boolean get() = SensitiveResource.NETWORK in resources
}

/** Icônes symboliques ; l'application Android les associe à des icônes Material. */
enum class ToolIcon {
    CALCULATE, FUNCTIONS, PERCENT, RECEIPT, OFFER, BALANCE, GROUP, CHART, COMPARE,
    RULER, AREA, VOLUME, MASS, TEMPERATURE, SPEED, PRESSURE, ENERGY, POWER, TIME, ANGLE, STORAGE, NUMBERS, SWAP,
    WIFI, SIGNAL, LAN, ROUTER, DNS, NETWORK_CHECK, HUB, HTTP, LOCK, DEVICES,
    QR_CODE, QR_SCAN, BARCODE, HISTORY, CONTACT, LINK,
    DOCUMENT_SCAN, PDF, MERGE, SPLIT, CUT, REORDER, ROTATE, COMPRESS, TEXT_SNIPPET,
    IMAGE, RESIZE, CROP, COLORIZE, PALETTE, INFO, HIDE_IMAGE, ZOOM,
    CODE, TEXT_FIELDS, CASE, CLEAN, FILTER, SORT, REVERSE, FIND_REPLACE, DATA_OBJECT, REGEX, UNICODE, CLOCK, FINGERPRINT, KEY,
    SHIELD, PASSWORD, PIN, DICE, HASH, VAULT, FILE,
    SENSORS, LEVEL, COMPASS, VIBRATION, LIGHT, BAROMETER, MIC, GPS, PHONE, BATTERY, SCREEN, TOUCH, SPEAKER,
    AUDIO, RECORD, SPEECH, TTS, TONE, PLAY,
    TODAY, STOPWATCH, TIMER, HOURGLASS, EVENT, CAKE, SHUFFLE, COIN, CHECKLIST,
}

/**
 * Définition centrale d'un outil : alimente l'accueil, la recherche, les catégories,
 * les favoris, le centre de confidentialité et la navigation (via son [id]).
 */
data class ToolDefinition(
    val id: String,
    val name: String,
    val description: String,
    val category: ToolCategory,
    val icon: ToolIcon,
    val keywords: List<String>,
    val status: ToolStatus,
    /** Fiche réelle : obligatoire pour un outil FONCTIONNEL ou PARTIEL, absente sinon. */
    val privacy: PrivacySheet?,
    /** Pour un outil non implémenté : ressources sensibles qu'il nécessitera probablement. */
    val plannedResources: Set<SensitiveResource> = emptySet(),
    /** Limites connues, obligatoires pour un outil PARTIEL. */
    val limitations: List<String> = emptyList(),
    /** Numéros du cahier des charges couverts par cet outil (traçabilité). */
    val specItems: List<Int>,
) {
    val isAvailable: Boolean get() = status != ToolStatus.NOT_IMPLEMENTED
}
