package com.alsalamy.droidtools.tools.calc

import com.alsalamy.droidtools.core.Outcome
import com.alsalamy.droidtools.core.fail
import com.alsalamy.droidtools.core.outcomeOf
import kotlin.math.abs
import kotlin.math.acos
import kotlin.math.asin
import kotlin.math.atan
import kotlin.math.cbrt
import kotlin.math.cos
import kotlin.math.cosh
import kotlin.math.exp
import kotlin.math.floor
import kotlin.math.ln
import kotlin.math.log10
import kotlin.math.log2
import kotlin.math.pow
import kotlin.math.sin
import kotlin.math.sinh
import kotlin.math.sqrt
import kotlin.math.tan
import kotlin.math.tanh

enum class AngleMode { DEGREES, RADIANS }

/**
 * Évaluateur d'expressions mathématiques (descente récursive), sans `eval` ni moteur de script.
 *
 * Grammaire :
 *   expression := terme (('+' | '-') terme)*
 *   terme      := unaire (('×' | '÷' | '*' | '/') unaire | multiplication implicite)*
 *   unaire     := ('-' | '+' | '√') unaire | puissance
 *   puissance  := postfixe ('^' unaire)?          (associativité à droite)
 *   postfixe   := primaire ('!' | '%' | '²' | '³')*
 *   primaire   := nombre | constante | fonction '(' expression ')' | '(' expression ')'
 *
 * Pourcentages : « 200 + 10 % » vaut 220 (10 % de 200), « 200 × 10 % » vaut 20.
 */
object ExpressionEvaluator {

    const val MAX_LENGTH = 1000
    private const val MAX_DEPTH = 100

    val functions = listOf("sin", "cos", "tan", "asin", "acos", "atan", "sinh", "cosh", "tanh", "ln", "log", "log2", "sqrt", "cbrt", "abs", "exp")

    fun evaluate(expression: String, angleMode: AngleMode = AngleMode.DEGREES): Outcome<Double> = outcomeOf {
        if (expression.isBlank()) fail("Saisissez une expression.")
        if (expression.length > MAX_LENGTH) fail("Expression trop longue (maximum $MAX_LENGTH caractères).")
        val tokens = tokenize(expression)
        val parser = Parser(tokens, angleMode)
        val value = parser.parseExpression().value
        if (!parser.atEnd()) fail("Expression invalide près de « ${parser.peekText()} ».")
        when {
            value.isNaN() -> fail("Résultat indéfini.")
            value.isInfinite() -> fail("Résultat trop grand.")
        }
        if (value == 0.0) 0.0 else value // évite « -0 »
    }

    // ------------------------------------------------------------------ Lexique

    private sealed interface Token {
        data class Num(val value: Double, val text: String) : Token
        data class Ident(val name: String) : Token
        data class Op(val symbol: Char) : Token
        data object LParen : Token
        data object RParen : Token
    }

    private fun tokenize(input: String): List<Token> {
        val tokens = ArrayList<Token>()
        var i = 0
        while (i < input.length) {
            val c = input[i]
            when {
                c.isWhitespace() -> i++
                c.isDigit() || ((c == '.' || c == ',') && i + 1 < input.length && input[i + 1].isDigit()) -> {
                    val start = i
                    var seenSeparator = false
                    while (i < input.length && (input[i].isDigit() || input[i] == '.' || input[i] == ',')) {
                        if (input[i] == '.' || input[i] == ',') {
                            if (seenSeparator) fail("Nombre invalide : « ${input.substring(start, i + 1)} ».")
                            seenSeparator = true
                        }
                        i++
                    }
                    // Notation scientifique, uniquement avec « E » majuscule (« e » est la constante d'Euler).
                    if (i < input.length && input[i] == 'E') {
                        var j = i + 1
                        if (j < input.length && (input[j] == '+' || input[j] == '-')) j++
                        if (j < input.length && input[j].isDigit()) {
                            while (j < input.length && input[j].isDigit()) j++
                            i = j
                        }
                    }
                    val text = input.substring(start, i)
                    val value = text.replace(',', '.').toDoubleOrNull() ?: fail("Nombre invalide : « $text ».")
                    tokens += Token.Num(value, text)
                }
                c.isLetter() && c != 'π' -> {
                    val start = i
                    while (i < input.length && input[i].isLetter() && input[i] != 'π') i++
                    var name = input.substring(start, i).lowercase()
                    // « log2 » est le seul identifiant contenant un chiffre.
                    if (name == "log" && i < input.length && input[i] == '2') { name = "log2"; i++ }
                    tokens += if (name == "x") Token.Op('*') else Token.Ident(name)
                }
                c == 'π' -> { tokens += Token.Ident("pi"); i++ }
                c == '(' -> { tokens += Token.LParen; i++ }
                c == ')' -> { tokens += Token.RParen; i++ }
                c == '+' -> { tokens += Token.Op('+'); i++ }
                c == '-' || c == '−' || c == '–' -> { tokens += Token.Op('-'); i++ }
                c == '*' || c == '×' || c == '·' -> { tokens += Token.Op('*'); i++ }
                c == '/' || c == '÷' || c == ':' -> { tokens += Token.Op('/'); i++ }
                c == '^' -> { tokens += Token.Op('^'); i++ }
                c == '!' || c == '%' || c == '√' || c == '²' || c == '³' -> { tokens += Token.Op(c); i++ }
                else -> fail("Caractère non reconnu : « $c ».")
            }
        }
        return tokens
    }

    // ------------------------------------------------------------------ Analyse

    /** Valeur intermédiaire : [percent] indique un terme se terminant par « % ». */
    private data class Value(val value: Double, val percent: Boolean = false)

    private class Parser(private val tokens: List<Token>, private val angleMode: AngleMode) {
        private var pos = 0
        private var depth = 0

        fun atEnd() = pos >= tokens.size
        private fun peek(): Token? = tokens.getOrNull(pos)
        fun peekText(): String = when (val t = peek()) {
            is Token.Num -> t.text
            is Token.Ident -> t.name
            is Token.Op -> t.symbol.toString()
            Token.LParen -> "("
            Token.RParen -> ")"
            null -> "fin"
        }

        private fun isOp(symbol: Char) = (peek() as? Token.Op)?.symbol == symbol

        private inline fun <T> nested(block: () -> T): T {
            depth++
            if (depth > MAX_DEPTH) fail("Expression trop imbriquée.")
            try { return block() } finally { depth-- }
        }

        fun parseExpression(): Value = nested {
            var left = parseTerm()
            while (isOp('+') || isOp('-')) {
                val op = (peek() as Token.Op).symbol
                pos++
                val right = parseTerm()
                // « a + b % » : b % s'applique à a.
                val rhs = if (right.percent) left.value * right.value else right.value
                left = Value(if (op == '+') left.value + rhs else left.value - rhs)
            }
            left
        }

        private fun parseTerm(): Value {
            var left = parseUnary()
            while (true) {
                val next = peek()
                when {
                    isOp('*') -> { pos++; left = Value(left.value * parseUnary().value, percent = false) }
                    isOp('/') -> {
                        pos++
                        val divisor = parseUnary().value
                        if (divisor == 0.0) fail("Division par zéro impossible.")
                        left = Value(left.value / divisor)
                    }
                    // Multiplication implicite : 2π, 3(4+1), (2)(3), 2sin(30)
                    next == Token.LParen || next is Token.Ident || (isOp('√')) ||
                        (next is Token.Num && tokens.getOrNull(pos - 1) == Token.RParen) -> {
                        left = Value(left.value * parseUnary().value)
                    }
                    next is Token.Num -> fail("Opérateur manquant avant « ${next.text} ».")
                    else -> return left
                }
            }
        }

        private fun parseUnary(): Value = nested {
            when {
                isOp('-') -> { pos++; val v = parseUnary(); Value(-v.value, v.percent) }
                isOp('+') -> { pos++; parseUnary() }
                isOp('√') -> {
                    pos++
                    val v = parseUnary().value
                    if (v < 0) fail("Racine carrée d'un nombre négatif impossible.")
                    Value(sqrt(v))
                }
                else -> parsePower()
            }
        }

        private fun parsePower(): Value {
            val base = parsePostfix()
            if (isOp('^')) {
                pos++
                val exponent = parseUnary().value
                val result = base.value.pow(exponent)
                if (result.isNaN()) fail("Puissance non définie pour ces valeurs.")
                if (result.isInfinite()) fail(if (base.value == 0.0) "Division par zéro impossible." else "Résultat trop grand.")
                return Value(result)
            }
            return base
        }

        private fun parsePostfix(): Value {
            var v = parsePrimary()
            while (true) {
                v = when {
                    isOp('!') -> { pos++; Value(factorial(v.value)) }
                    isOp('%') -> { pos++; Value(v.value / 100.0, percent = true) }
                    isOp('²') -> { pos++; Value(v.value * v.value) }
                    isOp('³') -> { pos++; Value(v.value * v.value * v.value) }
                    else -> return v
                }
            }
        }

        private fun parsePrimary(): Value {
            return when (val t = peek()) {
                is Token.Num -> { pos++; Value(t.value) }
                Token.LParen -> {
                    pos++
                    val inner = parseExpression()
                    if (peek() != Token.RParen) fail("Parenthèse fermante manquante.")
                    pos++
                    Value(inner.value)
                }
                is Token.Ident -> {
                    pos++
                    when (t.name) {
                        "pi" -> Value(Math.PI)
                        "e" -> Value(Math.E)
                        in functions -> {
                            if (peek() != Token.LParen) fail("La fonction ${t.name} doit être suivie de parenthèses, par exemple ${t.name}(30).")
                            pos++
                            val arg = parseExpression().value
                            if (peek() != Token.RParen) fail("Parenthèse fermante manquante après ${t.name}(…).")
                            pos++
                            Value(applyFunction(t.name, arg))
                        }
                        else -> fail("Fonction ou constante inconnue : « ${t.name} ».")
                    }
                }
                Token.RParen -> fail("Parenthèse fermante inattendue.")
                is Token.Op -> fail("Opérateur « ${t.symbol} » mal placé.")
                null -> fail("Expression incomplète.")
            }
        }

        private fun toRadians(x: Double) = if (angleMode == AngleMode.DEGREES) Math.toRadians(x) else x
        private fun fromRadians(x: Double) = if (angleMode == AngleMode.DEGREES) Math.toDegrees(x) else x
        private fun snap(x: Double) = if (abs(x) < 1e-12) 0.0 else x

        private fun applyFunction(name: String, x: Double): Double = when (name) {
            "sin" -> snap(sin(toRadians(x)))
            "cos" -> snap(cos(toRadians(x)))
            "tan" -> {
                val r = toRadians(x)
                if (abs(cos(r)) < 1e-12) fail("Tangente non définie pour cet angle.")
                snap(tan(r))
            }
            "asin" -> { if (x < -1 || x > 1) fail("asin est défini entre -1 et 1."); fromRadians(asin(x)) }
            "acos" -> { if (x < -1 || x > 1) fail("acos est défini entre -1 et 1."); fromRadians(acos(x)) }
            "atan" -> fromRadians(atan(x))
            "sinh" -> sinh(x)
            "cosh" -> cosh(x)
            "tanh" -> tanh(x)
            "ln" -> { if (x <= 0) fail("Logarithme défini uniquement pour un nombre strictement positif."); ln(x) }
            "log" -> { if (x <= 0) fail("Logarithme défini uniquement pour un nombre strictement positif."); log10(x) }
            "log2" -> { if (x <= 0) fail("Logarithme défini uniquement pour un nombre strictement positif."); log2(x) }
            "sqrt" -> { if (x < 0) fail("Racine carrée d'un nombre négatif impossible."); sqrt(x) }
            "cbrt" -> cbrt(x)
            "abs" -> abs(x)
            "exp" -> exp(x).also { if (it.isInfinite()) fail("Résultat trop grand.") }
            else -> fail("Fonction inconnue : $name.")
        }

        private fun factorial(x: Double): Double {
            if (x < 0 || x != floor(x)) fail("La factorielle est définie pour les entiers positifs ou nuls.")
            if (x > 170) fail("Factorielle trop grande (maximum 170!).")
            var result = 1.0
            var i = 2
            while (i <= x.toInt()) { result *= i; i++ }
            return result
        }
    }
}
