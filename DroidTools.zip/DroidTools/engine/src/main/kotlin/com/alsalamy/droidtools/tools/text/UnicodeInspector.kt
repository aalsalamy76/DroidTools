package com.alsalamy.droidtools.tools.text

import java.util.Locale

data class CodePointInfo(
    val codePoint: Int,
    val display: String,
    val notation: String,
    val name: String,
    val category: String,
    val block: String?,
    val utf8: String,
    val utf16: String,
    /** Caractère invisible ou de contrôle pouvant tromper un lecteur (espace insécable, zéro-chasse, bidi…). */
    val warning: String?,
)

data class UnicodeReport(val codePoints: List<CodePointInfo>, val total: Int, val truncated: Boolean, val warnings: Int)

object UnicodeInspector {
    const val MAX_CODE_POINTS = 2000

    private val invisible = mapOf(
        0x00A0 to "Espace insécable",
        0x00AD to "Trait d'union conditionnel (invisible)",
        0x034F to "Combining grapheme joiner (invisible)",
        0x061C to "Marque de lettre arabe (contrôle bidirectionnel)",
        0x115F to "Remplissage Hangul (invisible)",
        0x1160 to "Remplissage Hangul (invisible)",
        0x180E to "Séparateur de voyelle mongol (invisible)",
        0x200B to "Espace sans chasse (invisible)",
        0x200C to "Antiliant sans chasse (invisible)",
        0x200D to "Liant sans chasse (invisible)",
        0x200E to "Marque gauche-à-droite (contrôle bidirectionnel)",
        0x200F to "Marque droite-à-gauche (contrôle bidirectionnel)",
        0x202A to "Contrôle bidirectionnel (LRE)",
        0x202B to "Contrôle bidirectionnel (RLE)",
        0x202C to "Contrôle bidirectionnel (PDF)",
        0x202D to "Contrôle bidirectionnel (LRO)",
        0x202E to "Contrôle bidirectionnel (RLO) : peut inverser l'affichage du texte",
        0x202F to "Espace fine insécable",
        0x2060 to "Gluon de mots (invisible)",
        0x2066 to "Isolat bidirectionnel (LRI)",
        0x2067 to "Isolat bidirectionnel (RLI)",
        0x2068 to "Isolat bidirectionnel (FSI)",
        0x2069 to "Fin d'isolat bidirectionnel (PDI)",
        0x3164 to "Remplissage Hangul (invisible)",
        0xFEFF to "Indicateur d'ordre des octets / espace sans chasse (invisible)",
        0xFFFC to "Caractère de remplacement d'objet",
        0xFFFD to "Caractère de remplacement (données mal décodées)",
    )

    fun inspect(text: String): UnicodeReport {
        val result = ArrayList<CodePointInfo>()
        var index = 0
        var total = 0
        var warnings = 0
        while (index < text.length) {
            val cp = text.codePointAt(index)
            index += Character.charCount(cp)
            total++
            val info = describe(cp)
            if (info.warning != null) warnings++
            if (result.size < MAX_CODE_POINTS) result += info
        }
        return UnicodeReport(result, total, total > MAX_CODE_POINTS, warnings)
    }

    fun describe(cp: Int): CodePointInfo {
        val str = String(Character.toChars(cp))
        val type = Character.getType(cp)
        val warning = invisible[cp] ?: when {
            type == Character.CONTROL.toInt() && cp != 0x0A && cp != 0x09 && cp != 0x0D -> "Caractère de contrôle"
            type == Character.FORMAT.toInt() -> "Caractère de mise en forme (invisible)"
            type == Character.PRIVATE_USE.toInt() -> "Zone à usage privé (affichage variable)"
            cp in 0xE0000..0xE007F -> "Étiquette Unicode (invisible) : peut dissimuler du texte"
            else -> null
        }
        val display = when {
            cp == 0x0A -> "↵"
            cp == 0x09 -> "⇥"
            cp == 0x0D -> "␍"
            cp == 0x20 -> "␠"
            warning != null || type == Character.CONTROL.toInt() -> "◌"
            type == Character.NON_SPACING_MARK.toInt() || type == Character.ENCLOSING_MARK.toInt() -> "◌$str"
            else -> str
        }
        return CodePointInfo(
            codePoint = cp,
            display = display,
            notation = "U+" + Integer.toHexString(cp).uppercase(Locale.ROOT).padStart(4, '0'),
            name = Character.getName(cp) ?: "(sans nom)",
            category = categoryLabel(type),
            block = Character.UnicodeBlock.of(cp)?.toString()?.replace('_', ' '),
            utf8 = str.toByteArray(Charsets.UTF_8).joinToString(" ") { "%02X".format(Locale.ROOT, it.toInt() and 0xFF) },
            utf16 = str.map { "%04X".format(Locale.ROOT, it.code) }.joinToString(" "),
            warning = warning,
        )
    }

    private fun categoryLabel(type: Int): String = when (type.toByte()) {
        Character.UPPERCASE_LETTER -> "Lettre majuscule"
        Character.LOWERCASE_LETTER -> "Lettre minuscule"
        Character.TITLECASE_LETTER -> "Lettre de titre"
        Character.MODIFIER_LETTER -> "Lettre modificative"
        Character.OTHER_LETTER -> "Lettre"
        Character.NON_SPACING_MARK -> "Diacritique combinant"
        Character.ENCLOSING_MARK -> "Signe englobant"
        Character.COMBINING_SPACING_MARK -> "Signe combinant"
        Character.DECIMAL_DIGIT_NUMBER -> "Chiffre"
        Character.LETTER_NUMBER -> "Nombre lettre"
        Character.OTHER_NUMBER -> "Nombre"
        Character.SPACE_SEPARATOR -> "Espace"
        Character.LINE_SEPARATOR -> "Séparateur de ligne"
        Character.PARAGRAPH_SEPARATOR -> "Séparateur de paragraphe"
        Character.CONTROL -> "Contrôle"
        Character.FORMAT -> "Format"
        Character.PRIVATE_USE -> "Usage privé"
        Character.SURROGATE -> "Demi-code (surrogate)"
        Character.DASH_PUNCTUATION -> "Tiret"
        Character.START_PUNCTUATION -> "Ponctuation ouvrante"
        Character.END_PUNCTUATION -> "Ponctuation fermante"
        Character.CONNECTOR_PUNCTUATION -> "Ponctuation de liaison"
        Character.OTHER_PUNCTUATION -> "Ponctuation"
        Character.INITIAL_QUOTE_PUNCTUATION -> "Guillemet ouvrant"
        Character.FINAL_QUOTE_PUNCTUATION -> "Guillemet fermant"
        Character.MATH_SYMBOL -> "Symbole mathématique"
        Character.CURRENCY_SYMBOL -> "Symbole monétaire"
        Character.MODIFIER_SYMBOL -> "Symbole modificatif"
        Character.OTHER_SYMBOL -> "Symbole"
        else -> "Non attribué"
    }
}
