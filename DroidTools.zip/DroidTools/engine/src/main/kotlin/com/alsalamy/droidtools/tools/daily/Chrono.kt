package com.alsalamy.droidtools.tools.daily

import com.alsalamy.droidtools.core.Outcome
import com.alsalamy.droidtools.core.fail
import com.alsalamy.droidtools.core.outcomeOf

/** Mise en forme des durées : « MM:SS,cc » ou « H:MM:SS,cc ». */
object Durations {
    fun format(ms: Long, hundredths: Boolean = true): String {
        val safe = ms.coerceAtLeast(0)
        val hours = safe / 3_600_000
        val minutes = (safe / 60_000) % 60
        val seconds = (safe / 1000) % 60
        val cents = (safe / 10) % 100
        val base = if (hours > 0) {
            "$hours:${minutes.pad()}:${seconds.pad()}"
        } else {
            "${minutes.pad()}:${seconds.pad()}"
        }
        return if (hundredths) "$base,${cents.pad()}" else base
    }

    /** Version lue par TalkBack : « 1 heure 2 minutes 3 secondes ». */
    fun spoken(ms: Long): String {
        val safe = ms.coerceAtLeast(0)
        val h = safe / 3_600_000
        val m = (safe / 60_000) % 60
        val s = (safe / 1000) % 60
        return buildList {
            if (h > 0) add("$h heure" + if (h > 1) "s" else "")
            if (m > 0) add("$m minute" + if (m > 1) "s" else "")
            add("$s seconde" + if (s > 1) "s" else "")
        }.joinToString(" ")
    }

    private fun Long.pad() = toString().padStart(2, '0')
}

/**
 * Chronomètre fondé sur une horloge monotone fournie par l'appelant
 * (SystemClock.elapsedRealtime() sous Android) : insensible aux changements d'heure.
 */
data class Stopwatch(
    val running: Boolean = false,
    val accumulatedMs: Long = 0,
    val startedAtMs: Long = 0,
    /** Temps total au moment de chaque tour, du plus ancien au plus récent. */
    val laps: List<Long> = emptyList(),
) {
    data class Lap(val number: Int, val lapMs: Long, val totalMs: Long)

    fun elapsed(nowMs: Long): Long = accumulatedMs + if (running) (nowMs - startedAtMs).coerceAtLeast(0) else 0

    fun start(nowMs: Long): Stopwatch = if (running) this else copy(running = true, startedAtMs = nowMs)

    fun pause(nowMs: Long): Stopwatch = if (!running) this else copy(running = false, accumulatedMs = elapsed(nowMs))

    fun lap(nowMs: Long): Stopwatch = if (!running || laps.size >= MAX_LAPS) this else copy(laps = laps + elapsed(nowMs))

    fun reset(): Stopwatch = Stopwatch()

    /** Tours du plus récent au plus ancien. */
    fun lapDetails(): List<Lap> = laps.mapIndexed { i, total ->
        Lap(i + 1, total - (if (i == 0) 0 else laps[i - 1]), total)
    }.asReversed()

    companion object {
        const val MAX_LAPS = 999
    }
}

/** Minuteur (compte à rebours d'une durée), piloté par une horloge monotone. */
data class CountdownTimer(
    val durationMs: Long,
    val remainingAtPauseMs: Long = durationMs,
    val running: Boolean = false,
    val endAtMs: Long = 0,
) {
    fun remaining(nowMs: Long): Long = if (running) (endAtMs - nowMs).coerceAtLeast(0) else remainingAtPauseMs

    fun start(nowMs: Long): CountdownTimer =
        if (running || remainingAtPauseMs <= 0) this else copy(running = true, endAtMs = nowMs + remainingAtPauseMs)

    fun pause(nowMs: Long): CountdownTimer = if (!running) this else copy(running = false, remainingAtPauseMs = remaining(nowMs))

    fun reset(): CountdownTimer = CountdownTimer(durationMs)

    fun isFinished(nowMs: Long): Boolean = remaining(nowMs) == 0L

    /** Part restante, de 1 (début) à 0 (terminé). */
    fun fractionRemaining(nowMs: Long): Float =
        if (durationMs <= 0) 0f else (remaining(nowMs).toDouble() / durationMs).toFloat().coerceIn(0f, 1f)

    companion object {
        const val MAX_DURATION_MS = 99L * 3_600_000 + 59 * 60_000 + 59_000

        /** Lit une durée en heures / minutes / secondes saisies séparément (champs vides = 0). */
        fun parseDuration(hours: String, minutes: String, seconds: String): Outcome<Long> = outcomeOf {
            fun part(text: String, label: String, max: Int): Long {
                val t = text.trim()
                if (t.isEmpty()) return 0
                val v = t.toIntOrNull() ?: fail("$label : nombre entier attendu.")
                if (v < 0 || v > max) fail("$label : de 0 à $max.")
                return v.toLong()
            }
            val total = part(hours, "Heures", 99) * 3_600_000 + part(minutes, "Minutes", 59) * 60_000 + part(seconds, "Secondes", 59) * 1000
            if (total == 0L) fail("Indiquez une durée d'au moins 1 seconde.")
            total
        }
    }
}
