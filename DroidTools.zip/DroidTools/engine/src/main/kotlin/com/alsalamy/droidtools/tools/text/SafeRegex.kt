package com.alsalamy.droidtools.tools.text

import com.alsalamy.droidtools.core.Outcome
import com.alsalamy.droidtools.core.UserInputException
import com.alsalamy.droidtools.core.fail
import com.alsalamy.droidtools.core.outcomeOf
import java.util.concurrent.ExecutionException
import java.util.concurrent.FutureTask
import java.util.concurrent.TimeUnit
import java.util.concurrent.TimeoutException
import java.util.concurrent.atomic.AtomicInteger
import java.util.regex.Matcher
import java.util.regex.Pattern
import java.util.regex.PatternSyntaxException

/** Levée quand une évaluation d'expression régulière dépasse son délai (retour arrière catastrophique). */
class RegexTimeoutException : RuntimeException("Délai dépassé")

/**
 * Séquence de caractères qui interrompt le moteur regex une fois le délai écoulé.
 * Le moteur java.util.regex lit le texte via charAt() : c'est le seul point d'interruption fiable.
 */
private class DeadlineCharSequence(
    private val inner: CharSequence,
    private val deadlineNanos: Long,
) : CharSequence {
    private var counter = 0
    override val length: Int get() = inner.length
    override fun get(index: Int): Char {
        if (++counter and 0x3FF == 0 && System.nanoTime() > deadlineNanos) throw RegexTimeoutException()
        return inner[index]
    }
    override fun subSequence(startIndex: Int, endIndex: Int): CharSequence =
        DeadlineCharSequence(inner.subSequence(startIndex, endIndex), deadlineNanos)
    override fun toString(): String = inner.toString()
}

data class RegexOptions(
    val ignoreCase: Boolean = false,
    val multiline: Boolean = false,
    val dotAll: Boolean = false,
    val comments: Boolean = false,
)

data class GroupMatch(val index: Int, val name: String?, val value: String?, val start: Int, val end: Int)

data class RegexMatch(val value: String, val start: Int, val end: Int, val groups: List<GroupMatch>)

data class RegexTestResult(val matches: List<RegexMatch>, val truncated: Boolean, val groupCount: Int)

data class ReplaceResult(val output: String, val replacements: Int)

object SafeRegex {
    const val TIMEOUT_MS = 2000L
    const val MAX_MATCHES = 1000
    const val MAX_PATTERN_LENGTH = 5000

    fun compile(pattern: String, options: RegexOptions): Pattern {
        if (pattern.isEmpty()) fail("Saisissez une expression régulière.")
        if (pattern.length > MAX_PATTERN_LENGTH) fail("Expression trop longue (maximum $MAX_PATTERN_LENGTH caractères).")
        var flags = 0
        if (options.ignoreCase) flags = flags or Pattern.CASE_INSENSITIVE or Pattern.UNICODE_CASE
        if (options.multiline) flags = flags or Pattern.MULTILINE
        if (options.dotAll) flags = flags or Pattern.DOTALL
        if (options.comments) flags = flags or Pattern.COMMENTS
        return try {
            Pattern.compile(pattern, flags)
        } catch (e: PatternSyntaxException) {
            val where = if (e.index >= 0) " (position ${e.index + 1})" else ""
            fail("Expression invalide$where : ${e.description}.")
        }
    }

    const val MAX_TEXT_LENGTH = 500_000
    /** Nombre maximal d'évaluations abandonnées pouvant encore tourner en arrière-plan. */
    const val MAX_ABANDONED = 2

    private const val TIMEOUT_MESSAGE =
        "Évaluation interrompue après 2 s : l'expression provoque trop de retours arrière. Simplifiez-la."

    private val abandoned = AtomicInteger(0)

    /** Nombre d'évaluations abandonnées encore actives (exposé pour les tests et l'interface). */
    val abandonedCount: Int get() = abandoned.get()

    /**
     * Exécute [block] sur un thread démon dédié et n'attend jamais plus de [TIMEOUT_MS].
     *
     * Deux protections complémentaires :
     * - sur la JVM, [DeadlineCharSequence] interrompt le moteur regex lui-même ;
     * - sur Android, java.util.regex délègue au moteur natif ICU, qui copie le texte : la lecture
     *   par charAt() n'a pas lieu et le moteur ne peut pas être interrompu. Le délai est alors garanti
     *   par l'attente bornée de l'appelant ; le calcul abandonné continue en arrière-plan jusqu'à sa fin.
     *   Au-delà de [MAX_ABANDONED] calculs abandonnés encore actifs, toute nouvelle évaluation est refusée.
     */
    private fun <T> withDeadline(text: CharSequence, block: (CharSequence) -> T): T {
        if (text.length > MAX_TEXT_LENGTH) fail("Texte trop long pour le testeur (maximum ${MAX_TEXT_LENGTH / 1000} 000 caractères).")
        if (abandoned.get() >= MAX_ABANDONED) {
            fail("Des évaluations précédentes tournent encore en arrière-plan. Patientez, ou fermez puis rouvrez DroidTools.")
        }
        val lock = Any()
        var finished = false
        var gaveUp = false
        val task = FutureTask {
            try {
                block(DeadlineCharSequence(text, System.nanoTime() + TIMEOUT_MS * 1_000_000))
            } finally {
                synchronized(lock) {
                    finished = true
                    if (gaveUp) abandoned.decrementAndGet()
                }
            }
        }
        Thread(task, "droidtools-regex").apply { isDaemon = true }.start()
        return try {
            task.get(TIMEOUT_MS, TimeUnit.MILLISECONDS)
        } catch (e: TimeoutException) {
            synchronized(lock) {
                if (!finished) {
                    gaveUp = true
                    abandoned.incrementAndGet()
                }
            }
            task.cancel(true)
            fail(TIMEOUT_MESSAGE)
        } catch (e: InterruptedException) {
            Thread.currentThread().interrupt()
            fail("Évaluation annulée.")
        } catch (e: ExecutionException) {
            when (val cause = e.cause) {
                is UserInputException -> throw cause
                is RegexTimeoutException -> fail(TIMEOUT_MESSAGE)
                is StackOverflowError -> fail("Expression trop complexe pour ce texte.")
                is OutOfMemoryError -> fail("Texte trop volumineux pour cette expression.")
                else -> fail("Évaluation impossible avec cette expression.")
            }
        }
    }

    fun test(pattern: String, text: String, options: RegexOptions = RegexOptions()): Outcome<RegexTestResult> = outcomeOf {
        val compiled = compile(pattern, options)
        val names = groupNames(pattern)
        withDeadline(text) { guarded ->
            val matcher = compiled.matcher(guarded)
            val matches = ArrayList<RegexMatch>()
            var truncated = false
            while (matcher.find()) {
                if (matches.size >= MAX_MATCHES) { truncated = true; break }
                matches += RegexMatch(matcher.group(), matcher.start(), matcher.end(), groupsOf(matcher, names))
                // Évite une boucle infinie sur une correspondance vide.
                if (matcher.end() == matcher.start() && matcher.end() >= guarded.length) break
            }
            RegexTestResult(matches, truncated, matcher.groupCount())
        }
    }

    /**
     * Associe l'index de chaque groupe capturant à son nom, en parcourant le motif
     * (les classes de caractères, échappements et groupes non capturants sont ignorés).
     */
    internal fun groupNames(pattern: String): Map<Int, String> {
        val result = HashMap<Int, String>()
        var index = 0
        var i = 0
        var inClass = false
        while (i < pattern.length) {
            val c = pattern[i]
            when {
                c == '\\' -> {
                    if (i + 1 < pattern.length && pattern[i + 1] == 'Q') {
                        val end = pattern.indexOf("\\E", i + 2)
                        i = if (end < 0) pattern.length else end + 2
                        continue
                    }
                    i += 2
                    continue
                }
                inClass -> if (c == ']') inClass = false
                c == '[' -> inClass = true
                c == '(' -> {
                    val next = pattern.getOrNull(i + 1)
                    if (next != '?') {
                        index++
                    } else if (pattern.getOrNull(i + 2) == '<' && pattern.getOrNull(i + 3) != '=' && pattern.getOrNull(i + 3) != '!') {
                        index++
                        val close = pattern.indexOf('>', i + 3)
                        if (close > 0) result[index] = pattern.substring(i + 3, close)
                    }
                }
            }
            i++
        }
        return result
    }

    private fun groupsOf(matcher: Matcher, names: Map<Int, String>): List<GroupMatch> =
        (1..matcher.groupCount()).map { i ->
            GroupMatch(i, names[i], matcher.group(i), matcher.start(i), matcher.end(i))
        }

    /** Remplace avec [replacement] interprété littéralement, ou avec références $1 / ${nom} si [useGroupRefs]. */
    fun replace(
        pattern: Pattern,
        text: String,
        replacement: String,
        useGroupRefs: Boolean,
    ): ReplaceResult = withDeadline(text) { guarded ->
        val matcher = pattern.matcher(guarded)
        val sb = StringBuffer()
        var count = 0
        val rep = if (useGroupRefs) replacement else Matcher.quoteReplacement(replacement)
        try {
            while (matcher.find()) {
                matcher.appendReplacement(sb, rep)
                count++
            }
        } catch (e: IllegalArgumentException) {
            fail("Remplacement invalide : référence de groupe inexistante.")
        } catch (e: IndexOutOfBoundsException) {
            fail("Remplacement invalide : référence de groupe inexistante.")
        }
        matcher.appendTail(sb)
        ReplaceResult(sb.toString(), count)
    }
}
