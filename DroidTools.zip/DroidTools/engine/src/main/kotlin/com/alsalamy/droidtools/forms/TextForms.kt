package com.alsalamy.droidtools.forms

import com.alsalamy.droidtools.core.fail
import com.alsalamy.droidtools.tools.codec.Base64Codec
import com.alsalamy.droidtools.tools.codec.UrlCodec
import com.alsalamy.droidtools.tools.codec.UrlEncodingMode
import com.alsalamy.droidtools.tools.json.Json
import com.alsalamy.droidtools.tools.json.JsonIndent
import com.alsalamy.droidtools.tools.json.JsonValue
import com.alsalamy.droidtools.tools.text.EscapeFormat
import com.alsalamy.droidtools.tools.text.FindReplace
import com.alsalamy.droidtools.tools.text.FindReplaceOptions
import com.alsalamy.droidtools.tools.text.RegexOptions
import com.alsalamy.droidtools.tools.text.SafeRegex
import com.alsalamy.droidtools.tools.text.SortOrder
import com.alsalamy.droidtools.tools.text.StringEscaper
import com.alsalamy.droidtools.tools.text.TextOperation
import com.alsalamy.droidtools.tools.text.TextStatistics
import com.alsalamy.droidtools.tools.text.TextTransforms
import com.alsalamy.droidtools.tools.text.TransformOptions
import com.alsalamy.droidtools.tools.text.UnicodeInspector
import com.alsalamy.droidtools.tools.xml.XmlFormatter

internal object TextForms {

    private fun textInput(label: String = "Texte", kind: InputKind = InputKind.MULTILINE) =
        TextInput("text", label, kind, placeholder = "Saisissez ou collez votre texte")

    private fun output(text: String, monospace: Boolean = false, label: String = "Résultat"): ResultItem =
        ResultText(label, text, monospace = monospace)

    val counter: ToolForm = ToolForm(fields = listOf(textInput())) { v, _ ->
        val text = v["text"]
        if (text.isEmpty()) awaiting()
        val s = TextStatistics.analyze(text)
        val reading = when {
            s.readingSeconds == 0 -> "—"
            s.readingSeconds < 60 -> "${s.readingSeconds} s"
            else -> "${s.readingSeconds / 60} min ${(s.readingSeconds % 60).toString().padStart(2, '0')} s"
        }
        FormResult(
            ResultRow("Mots", count(s.words), emphasis = true),
            ResultRow("Caractères", count(s.characters)),
            ResultRow("Caractères sans espaces", count(s.charactersNoSpaces)),
            ResultRow("Lignes", count(s.lines)),
            ResultRow("Lignes non vides", count(s.nonEmptyLines)),
            ResultRow("Paragraphes", count(s.paragraphs)),
            ResultRow("Phrases (estimation)", count(s.sentences)),
            ResultRow("Taille en UTF-8", byteSize(s.utf8Bytes.toLong())),
            ResultRow("Temps de lecture (230 mots/min)", reading, copyable = false),
            ResultNotice("Les caractères sont comptés tels qu'on les voit : une lettre accentuée ou un emoji simple compte pour 1."),
        )
    }

    private fun transform(op: (FormValues) -> TextOperation, options: (FormValues) -> TransformOptions, extraFields: List<Field> = emptyList()) =
        ToolForm(fields = listOf(textInput()) + extraFields) { v, _ ->
            val text = v["text"]
            if (text.isEmpty()) awaiting()
            val r = TextTransforms.apply(text, op(v), options(v))
            val items = mutableListOf(output(r.text))
            r.summary?.let { items += ResultNotice(it) }
            FormResult(items)
        }

    val uppercase = transform({ TextOperation.UPPERCASE }, { TransformOptions() })
    val lowercase = transform({ TextOperation.LOWERCASE }, { TransformOptions() })

    val capitalize = transform(
        { if (it["style"] == "sentences") TextOperation.CAPITALIZE_SENTENCES else TextOperation.CAPITALIZE_WORDS },
        { TransformOptions() },
        listOf(ChoiceInput("style", "Style", listOf(Choice("words", "Chaque Mot"), Choice("sentences", "Début de phrase")))),
    )

    val cleanSpaces = transform(
        { TextOperation.CLEAN_SPACES },
        { TransformOptions(removeEmptyLines = it.flag("removeEmpty")) },
        listOf(ToggleInput("removeEmpty", "Supprimer toutes les lignes vides",
            supportingText = "Sinon, les lignes vides consécutives sont réduites à une seule")),
    )

    val dedupe = transform(
        { TextOperation.DEDUPE_LINES },
        { TransformOptions(ignoreCase = it.flag("ignoreCase")) },
        listOf(ToggleInput("ignoreCase", "Ignorer la casse")),
    )

    val sortLines = transform(
        { TextOperation.SORT_LINES },
        { TransformOptions(sortOrder = SortOrder.valueOf(it["order"]), ignoreCase = it.flag("ignoreCase")) },
        listOf(
            ChoiceInput("order", "Ordre", SortOrder.entries.map { Choice(it.name, it.label) }),
            ToggleInput("ignoreCase", "Ignorer la casse et les accents secondaires", default = true),
        ),
    )

    val reverse = transform(
        { if (it["what"] == "lines") TextOperation.REVERSE_LINES else TextOperation.REVERSE_TEXT },
        { TransformOptions() },
        listOf(ChoiceInput("what", "Inverser", listOf(Choice("chars", "Les caractères"), Choice("lines", "L'ordre des lignes")))),
    )

    val findReplace: ToolForm = ToolForm(
        fields = listOf(
            textInput(),
            TextInput("find", "Rechercher", InputKind.CODE, placeholder = "texte ou expression"),
            TextInput("replacement", "Remplacer par", InputKind.CODE, placeholder = "(vide pour supprimer)"),
            ToggleInput("regex", "Expression régulière", supportingText = "Références de groupes : \$1, \${nom}"),
            ToggleInput("ignoreCase", "Ignorer la casse"),
            ToggleInput("wholeWord", "Mots entiers uniquement"),
        ),
    ) { v, _ ->
        val text = v["text"]
        if (text.isEmpty() || v["find"].isEmpty()) awaiting()
        val r = FindReplace.run(text, v["find"], v["replacement"],
            FindReplaceOptions(useRegex = v.flag("regex"), ignoreCase = v.flag("ignoreCase"), wholeWord = v.flag("wholeWord"))).orFail()
        FormResult(
            ResultNotice(if (r.replacements == 0) "Aucune occurrence trouvée." else "${plural(r.replacements, "remplacement")} effectué(s).",
                if (r.replacements == 0) NoticeLevel.INFO else NoticeLevel.SUCCESS),
            output(r.output),
        )
    }

    val base64Encode: ToolForm = ToolForm(
        fields = listOf(
            textInput(),
            ToggleInput("urlSafe", "Alphabet « URL » (- et _ au lieu de + et /)"),
            ToggleInput("padding", "Remplissage « = »", default = true),
        ),
    ) { v, _ ->
        val text = v["text"]
        if (text.isEmpty()) awaiting()
        if (text.length > Base64Codec.MAX_INPUT_CHARS) fail("Texte trop long.")
        FormResult(output(Base64Codec.encode(text, urlSafe = v.flag("urlSafe"), padding = v.flag("padding")), monospace = true))
    }

    val base64Decode: ToolForm = ToolForm(fields = listOf(textInput("Texte Base64", InputKind.CODE_BLOCK))) { v, _ ->
        val decoded = Base64Codec.decode(v.requiredText("text")).orFail()
        val items = mutableListOf<ResultItem>()
        if (decoded.text != null) {
            items += output(decoded.text)
        } else {
            items += ResultNotice("Le contenu décodé n'est pas du texte UTF-8 : affichage en hexadécimal.", NoticeLevel.WARNING)
            items += output(decoded.hex, monospace = true, label = "Octets (hexadécimal)")
        }
        items += ResultRow("Taille décodée", byteSize(decoded.bytes.size.toLong()), copyable = false)
        FormResult(items)
    }

    private val urlMode = ChoiceInput("mode", "Format", UrlEncodingMode.entries.map { Choice(it.name, it.label) })

    val urlEncode: ToolForm = ToolForm(fields = listOf(textInput(), urlMode)) { v, _ ->
        val text = v["text"]
        if (text.isEmpty()) awaiting()
        FormResult(output(UrlCodec.encode(text, UrlEncodingMode.valueOf(v["mode"])), monospace = true))
    }

    val urlDecode: ToolForm = ToolForm(fields = listOf(textInput("Texte encodé", InputKind.CODE_BLOCK), urlMode)) { v, _ ->
        FormResult(output(UrlCodec.decode(v.requiredText("text"), UrlEncodingMode.valueOf(v["mode"])).orFail()))
    }

    private fun jsonInput() = TextInput("text", "JSON", InputKind.CODE_BLOCK, placeholder = "{\"exemple\": [1, 2, 3]}")

    private fun duplicateNotice(text: String): ResultItem? {
        val keys = Json.parse(text).getOrNull()?.duplicateKeys.orEmpty()
        if (keys.isEmpty()) return null
        val shown = keys.take(5).joinToString(", ") { "« $it »" } + if (keys.size > 5) "…" else ""
        return ResultNotice("Clés en double : $shown. La RFC 8259 déconseille les clés en double (comportement imprévisible selon les lecteurs).",
            NoticeLevel.WARNING)
    }

    val jsonFormat: ToolForm = ToolForm(
        fields = listOf(
            jsonInput(),
            ChoiceInput("indent", "Indentation", JsonIndent.entries.map { Choice(it.name, it.label) }),
            ToggleInput("sortKeys", "Trier les clés"),
        ),
    ) { v, _ ->
        val text = v.requiredText("text")
        val formatted = Json.format(text, JsonIndent.valueOf(v["indent"]), v.flag("sortKeys")).orFail()
        FormResult(listOfNotNull(duplicateNotice(text), output(formatted, monospace = true)))
    }

    val jsonValidate: ToolForm = ToolForm(fields = listOf(jsonInput())) { v, _ ->
        val text = v.requiredText("text")
        val parsed = Json.parse(text)
        val error = Json.errorOf(parsed)
        if (error != null) {
            val items = mutableListOf<ResultItem>(
                ResultNotice("JSON invalide : ${error.message}", NoticeLevel.ERROR),
                ResultRow("Position", "ligne ${error.line}, colonne ${error.column}", copyable = false),
            )
            if (error.excerpt.isNotBlank()) items += ResultText("Extrait", error.excerpt, monospace = true)
            return@ToolForm FormResult(items)
        }
        val analysis = parsed.getOrThrow()
        val rootType = when (analysis.value) {
            is JsonValue.Obj -> "Objet"
            is JsonValue.Arr -> "Tableau"
            is JsonValue.Str -> "Chaîne"
            is JsonValue.Num -> "Nombre"
            is JsonValue.Bool -> "Booléen"
            JsonValue.Null -> "null"
        }
        FormResult(
            listOfNotNull(
                ResultNotice("JSON valide (RFC 8259).", NoticeLevel.SUCCESS),
                duplicateNotice(text),
                ResultRow("Type de la racine", rootType, copyable = false),
                ResultRow("Objets", count(analysis.objectCount), copyable = false),
                ResultRow("Tableaux", count(analysis.arrayCount), copyable = false),
                ResultRow("Profondeur maximale", count(analysis.maxDepth), copyable = false),
            ),
        )
    }

    val jsonMinify: ToolForm = ToolForm(fields = listOf(jsonInput())) { v, _ ->
        val text = v.requiredText("text")
        val minified = Json.minify(text).orFail()
        val before = text.toByteArray(Charsets.UTF_8).size.toLong()
        val after = minified.toByteArray(Charsets.UTF_8).size.toLong()
        FormResult(
            listOfNotNull(
                duplicateNotice(text),
                output(minified, monospace = true),
                ResultRow("Taille", "${byteSize(before)} → ${byteSize(after)}", copyable = false),
            ),
        )
    }

    val xml: ToolForm = ToolForm(
        fields = listOf(
            TextInput("text", "XML", InputKind.CODE_BLOCK, placeholder = "<racine><element attribut=\"1\"/></racine>"),
            ChoiceInput("mode", "Opération", listOf(Choice("format", "Formater"), Choice("minify", "Compacter"))),
            ChoiceInput("indent", "Indentation", listOf(Choice("2", "2 espaces"), Choice("4", "4 espaces"), Choice("tab", "Tabulation")),
                visibleWhen = visibleIf("mode", "format")),
        ),
        intro = "Vérifie la structure (pas de schéma XSD/DTD). Les entités ne sont jamais développées (protection XXE).",
    ) { v, _ ->
        val text = v.requiredText("text")
        val result = if (v["mode"] == "minify") {
            XmlFormatter.minify(text)
        } else {
            val indent = when (v["indent"]) { "4" -> "    "; "tab" -> "\t"; else -> "  " }
            XmlFormatter.format(text, indent)
        }
        FormResult(output(result.orFail(), monospace = true))
    }

    val regexTester: ToolForm = ToolForm(
        fields = listOf(
            TextInput("pattern", "Expression régulière", InputKind.CODE, placeholder = "(?<annee>\\d{4})-(\\d{2})"),
            TextInput("text", "Texte à tester", InputKind.MULTILINE, placeholder = "2024-03 et 1999-12"),
            ToggleInput("ignoreCase", "Ignorer la casse"),
            ToggleInput("multiline", "Multiligne (^ et \$ à chaque ligne)"),
            ToggleInput("dotAll", "Le point inclut les retours à la ligne"),
        ),
        intro = "Syntaxe java.util.regex. Une expression trop coûteuse est abandonnée après 2 secondes.",
    ) { v, _ ->
        val pattern = v["pattern"]
        if (pattern.isEmpty()) awaiting()
        val r = SafeRegex.test(pattern, v["text"],
            RegexOptions(ignoreCase = v.flag("ignoreCase"), multiline = v.flag("multiline"), dotAll = v.flag("dotAll"))).orFail()
        if (r.matches.isEmpty()) return@ToolForm FormResult(ResultNotice("Aucune correspondance."))
        val items = mutableListOf<ResultItem>(
            ResultHeader(plural(r.matches.size, "correspondance") + (if (r.truncated) " (liste limitée)" else "") +
                " — ${plural(r.groupCount, "groupe")} par correspondance"),
        )
        val shown = r.matches.take(MAX_SHOWN_MATCHES)
        shown.forEachIndexed { i, m ->
            items += ResultRow("n° ${i + 1} · position ${m.start + 1}–${m.end}", m.value.ifEmpty { "(chaîne vide)" }, monospace = true)
            m.groups.forEach { g ->
                val name = g.name?.let { " « $it »" } ?: ""
                items += ResultRow("    Groupe ${g.index}$name", g.value ?: "(non capturé)", monospace = true, copyable = g.value != null)
            }
        }
        if (r.matches.size > shown.size) items += ResultNotice("Seules les $MAX_SHOWN_MATCHES premières correspondances sont affichées.")
        FormResult(items)
    }

    private const val MAX_SHOWN_MATCHES = 200

    val escape: ToolForm = ToolForm(
        fields = listOf(
            textInput(kind = InputKind.CODE_BLOCK),
            ChoiceInput("format", "Format", EscapeFormat.entries.map { Choice(it.name, it.label) }),
            ChoiceInput("direction", "Sens", listOf(Choice("escape", "Échapper"), Choice("unescape", "Déséchapper"))),
        ),
    ) { v, _ ->
        val text = v["text"]
        if (text.isEmpty()) awaiting()
        val format = EscapeFormat.valueOf(v["format"])
        val out = if (v["direction"] == "unescape") StringEscaper.unescape(text, format).orFail() else StringEscaper.escape(text, format)
        FormResult(output(out, monospace = true))
    }

    val unicode: ToolForm = ToolForm(
        fields = listOf(textInput()),
        intro = "Révèle les caractères invisibles ou trompeurs (espaces spéciaux, contrôles bidirectionnels…).",
    ) { v, _ ->
        val text = v["text"]
        if (text.isEmpty()) awaiting()
        val r = UnicodeInspector.inspect(text)
        val items = mutableListOf<ResultItem>()
        items += if (r.warnings > 0) {
            ResultNotice("${plural(r.warnings, "caractère invisible ou trompeur", "caractères invisibles ou trompeurs")} détecté(s).", NoticeLevel.WARNING)
        } else {
            ResultNotice("Aucun caractère invisible ou trompeur détecté.", NoticeLevel.SUCCESS)
        }
        items += ResultHeader(plural(r.total, "point de code", "points de code"))
        r.codePoints.forEach { cp ->
            val details = buildString {
                append(cp.name)
                append("\n").append(cp.category)
                cp.block?.let { append(" · ").append(it) }
                append("\nUTF-8 : ").append(cp.utf8).append(" · UTF-16 : ").append(cp.utf16)
                cp.warning?.let { append("\n⚠ ").append(it) }
            }
            items += ResultRow("${cp.display}   ${cp.notation}", details, monospace = false)
        }
        if (r.truncated) items += ResultNotice("Seuls les ${UnicodeInspector.MAX_CODE_POINTS} premiers points de code sont détaillés.")
        FormResult(items)
    }
}
