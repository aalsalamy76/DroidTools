package com.alsalamy.droidtools.tools.color

import com.alsalamy.droidtools.core.Outcome
import com.alsalamy.droidtools.core.fail
import com.alsalamy.droidtools.core.outcomeOf
import java.util.Locale
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.roundToInt

data class Rgba(val r: Int, val g: Int, val b: Int, val alpha: Int = 255) {
    init { require(r in 0..255 && g in 0..255 && b in 0..255 && alpha in 0..255) }
    /** ARGB 32 bits, directement utilisable par Android (Color(argb)). */
    val argb: Long get() = (alpha.toLong() shl 24) or (r.toLong() shl 16) or (g.toLong() shl 8) or b.toLong()
}

data class ColorReport(
    val color: Rgba,
    val hex: String,
    val hexWithAlpha: String?,
    val rgb: String,
    val hsl: String,
    val hsv: String,
    val cmyk: String,
    val contrastWithWhite: Double,
    val contrastWithBlack: Double,
)

object ColorConverter {

    fun parse(input: String): Outcome<ColorReport> = outcomeOf { report(parseColor(input)) }

    fun parseColor(input: String): Rgba {
        val s = input.trim()
        if (s.isEmpty()) fail("Saisissez une couleur (ex. #1E88E5 ou 30, 136, 229).")
        val hexBody = s.removePrefix("#")
        val looksHex = Regex("[0-9a-fA-F]{6}([0-9a-fA-F]{2})?").matches(s) || (Regex("[0-9a-fA-F]{3,4}").matches(s) && s.any { it.isLetter() })
        if (s.startsWith("#") || looksHex) {
            if (!hexBody.all { it in '0'..'9' || it.lowercaseChar() in 'a'..'f' }) fail("Code HEX invalide : seuls 0-9 et A-F sont autorisés.")
            return when (hexBody.length) {
                3, 4 -> {
                    val c = hexBody.map { "$it$it".toInt(16) }
                    Rgba(c[0], c[1], c[2], if (c.size == 4) c[3] else 255)
                }
                6, 8 -> {
                    val c = hexBody.chunked(2).map { it.toInt(16) }
                    Rgba(c[0], c[1], c[2], if (c.size == 4) c[3] else 255)
                }
                else -> fail("Code HEX invalide : 3, 4, 6 ou 8 chiffres hexadécimaux attendus.")
            }
        }
        // La virgule sépare toujours les composantes (« rgb(30,136,229) ») ; le point est le seul séparateur décimal.
        val numbers = Regex("-?\\d+(?:\\.\\d+)?").findAll(s.removePrefix("rgba").removePrefix("rgb")).map { it.value }.toList()
        if (numbers.size !in 3..4) fail("Format RGB attendu : trois valeurs de 0 à 255 (ex. 30, 136, 229), opacité facultative avec un point (ex. 0.5).")
        val rgb = numbers.take(3).map {
            val v = it.toDoubleOrNull() ?: fail("Valeur « $it » invalide.")
            if (v < 0 || v > 255 || v != kotlin.math.floor(v)) fail("Chaque composante RGB doit être un entier de 0 à 255 (« $it »).")
            v.toInt()
        }
        val alpha = numbers.getOrNull(3)?.let {
            val a = it.toDouble()
            when {
                a in 0.0..1.0 -> (a * 255).roundToInt()
                a <= 255 && a == kotlin.math.floor(a) -> a.toInt()
                else -> fail("Opacité invalide : de 0 à 1 (ou 0 à 255).")
            }
        } ?: 255
        return Rgba(rgb[0], rgb[1], rgb[2], alpha)
    }

    fun report(c: Rgba): ColorReport {
        val hex = "#%02X%02X%02X".format(Locale.ROOT, c.r, c.g, c.b)
        val (h, sl, l) = toHsl(c)
        val (hv, sv, v) = toHsv(c)
        val cmyk = toCmyk(c)
        val lum = relativeLuminance(c)
        return ColorReport(
            color = c,
            hex = hex,
            hexWithAlpha = if (c.alpha != 255) hex + "%02X".format(Locale.ROOT, c.alpha) else null,
            rgb = if (c.alpha == 255) "rgb(${c.r}, ${c.g}, ${c.b})" else "rgba(${c.r}, ${c.g}, ${c.b}, ${fmt(c.alpha / 255.0)})",
            hsl = "hsl(${h.roundToInt()}, ${(sl * 100).roundToInt()} %, ${(l * 100).roundToInt()} %)",
            hsv = "hsv(${hv.roundToInt()}, ${(sv * 100).roundToInt()} %, ${(v * 100).roundToInt()} %)",
            cmyk = cmyk.joinToString(", ", prefix = "cmjn(", postfix = ")") { "${(it * 100).roundToInt()} %" },
            contrastWithWhite = contrast(lum, 1.0),
            contrastWithBlack = contrast(lum, 0.0),
        )
    }

    private fun fmt(d: Double) = String.format(Locale.ROOT, "%.2f", d).trimEnd('0').trimEnd('.')

    fun toHsl(c: Rgba): Triple<Double, Double, Double> {
        val r = c.r / 255.0; val g = c.g / 255.0; val b = c.b / 255.0
        val mx = max(r, max(g, b)); val mn = min(r, min(g, b))
        val l = (mx + mn) / 2
        val d = mx - mn
        if (d == 0.0) return Triple(0.0, 0.0, l)
        val s = d / (1 - abs(2 * l - 1))
        return Triple(hue(r, g, b, mx, d), s, l)
    }

    fun toHsv(c: Rgba): Triple<Double, Double, Double> {
        val r = c.r / 255.0; val g = c.g / 255.0; val b = c.b / 255.0
        val mx = max(r, max(g, b)); val mn = min(r, min(g, b))
        val d = mx - mn
        val s = if (mx == 0.0) 0.0 else d / mx
        return Triple(if (d == 0.0) 0.0 else hue(r, g, b, mx, d), s, mx)
    }

    private fun hue(r: Double, g: Double, b: Double, mx: Double, d: Double): Double {
        val h = when (mx) {
            r -> ((g - b) / d) % 6
            g -> (b - r) / d + 2
            else -> (r - g) / d + 4
        } * 60
        return if (h < 0) h + 360 else h
    }

    /** CMJN « naïf » (sans profil ICC) : indicatif pour l'impression. */
    fun toCmyk(c: Rgba): List<Double> {
        val r = c.r / 255.0; val g = c.g / 255.0; val b = c.b / 255.0
        val k = 1 - max(r, max(g, b))
        if (k >= 1.0) return listOf(0.0, 0.0, 0.0, 1.0)
        return listOf((1 - r - k) / (1 - k), (1 - g - k) / (1 - k), (1 - b - k) / (1 - k), k)
    }

    /** Luminance relative WCAG 2.x. */
    fun relativeLuminance(c: Rgba): Double {
        fun channel(v: Int): Double {
            val s = v / 255.0
            return if (s <= 0.04045) s / 12.92 else ((s + 0.055) / 1.055).pow(2.4)
        }
        return 0.2126 * channel(c.r) + 0.7152 * channel(c.g) + 0.0722 * channel(c.b)
    }

    fun contrast(l1: Double, l2: Double): Double = (max(l1, l2) + 0.05) / (min(l1, l2) + 0.05)
}
