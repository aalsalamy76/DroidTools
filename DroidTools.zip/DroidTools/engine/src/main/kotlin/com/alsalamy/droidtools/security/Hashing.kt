package com.alsalamy.droidtools.security

import com.alsalamy.droidtools.core.Outcome
import com.alsalamy.droidtools.core.fail
import com.alsalamy.droidtools.core.outcomeOf
import com.alsalamy.droidtools.tools.codec.Hex
import java.io.InputStream
import java.security.MessageDigest
import java.util.Base64

enum class HashAlgorithm(val label: String, val jcaName: String, val hexLength: Int, val secure: Boolean) {
    SHA256("SHA-256", "SHA-256", 64, true),
    SHA512("SHA-512", "SHA-512", 128, true),
    SHA1("SHA-1 (obsolète)", "SHA-1", 40, false),
    MD5("MD5 (non sécuritaire)", "MD5", 32, false),
}

data class HashResult(val hex: String, val base64: String)

enum class HashComparison { EQUAL, DIFFERENT, INVALID }

object Hashing {
    const val BUFFER_SIZE = 64 * 1024

    fun text(text: String, algorithm: HashAlgorithm): HashResult =
        bytes(text.toByteArray(Charsets.UTF_8), algorithm)

    fun bytes(data: ByteArray, algorithm: HashAlgorithm): HashResult {
        val digest = MessageDigest.getInstance(algorithm.jcaName).digest(data)
        return HashResult(Hex.encode(digest), Base64.getEncoder().encodeToString(digest))
    }

    /**
     * Calcule l'empreinte d'un flux par blocs (ne charge jamais tout le fichier en mémoire).
     * [onProgress] reçoit le nombre d'octets lus ; [isCancelled] permet l'annulation.
     */
    fun stream(
        input: InputStream,
        algorithms: List<HashAlgorithm>,
        onProgress: (Long) -> Unit = {},
        isCancelled: () -> Boolean = { false },
    ): Map<HashAlgorithm, HashResult> {
        val digests = algorithms.associateWith { MessageDigest.getInstance(it.jcaName) }
        val buffer = ByteArray(BUFFER_SIZE)
        var total = 0L
        while (true) {
            if (isCancelled()) throw java.util.concurrent.CancellationException("Calcul annulé")
            val read = input.read(buffer)
            if (read < 0) break
            for (d in digests.values) d.update(buffer, 0, read)
            total += read
            onProgress(total)
        }
        return digests.mapValues { (_, d) ->
            val out = d.digest()
            HashResult(Hex.encode(out), Base64.getEncoder().encodeToString(out))
        }
    }

    /** Normalise une empreinte collée : espaces, deux-points et casse ignorés. */
    fun normalize(hash: String): String =
        hash.trim().lowercase().filterNot { it.isWhitespace() || it == ':' || it == '-' }

    fun guessAlgorithm(hash: String): HashAlgorithm? {
        val n = normalize(hash)
        if (!n.all { it in '0'..'9' || it in 'a'..'f' }) return null
        return HashAlgorithm.entries.firstOrNull { it.hexLength == n.length }
    }

    /** Comparaison à temps constant (évite de révéler la position de la première différence). */
    fun compare(a: String, b: String): Outcome<HashComparison> = outcomeOf {
        val na = normalize(a)
        val nb = normalize(b)
        if (na.isEmpty() || nb.isEmpty()) fail("Saisissez les deux empreintes à comparer.")
        val hexA = na.all { it in '0'..'9' || it in 'a'..'f' }
        val hexB = nb.all { it in '0'..'9' || it in 'a'..'f' }
        if (!hexA || !hexB) return@outcomeOf HashComparison.INVALID
        if (MessageDigest.isEqual(na.toByteArray(), nb.toByteArray())) HashComparison.EQUAL else HashComparison.DIFFERENT
    }
}
