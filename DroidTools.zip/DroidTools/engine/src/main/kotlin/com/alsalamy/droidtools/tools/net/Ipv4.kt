package com.alsalamy.droidtools.tools.net

import com.alsalamy.droidtools.core.Outcome
import com.alsalamy.droidtools.core.fail
import com.alsalamy.droidtools.core.outcomeOf

/** Adresse IPv4 manipulée comme entier non signé sur 32 bits (stocké dans un Long). */
@JvmInline
value class Ipv4(val value: Long) {
    init { require(value in 0..0xFFFFFFFFL) }

    override fun toString(): String =
        "${(value ushr 24) and 255}.${(value ushr 16) and 255}.${(value ushr 8) and 255}.${value and 255}"

    fun toBinary(dotted: Boolean = true): String {
        val bits = java.lang.Long.toBinaryString(value).padStart(32, '0')
        return if (dotted) bits.chunked(8).joinToString(".") else bits
    }

    fun toHex(): String = "0x" + java.lang.Long.toHexString(value).uppercase().padStart(8, '0')

    companion object {
        fun parse(input: String, field: String = "Adresse IP"): Ipv4 {
            val s = input.trim()
            if (s.isEmpty()) fail("$field : champ vide.")
            val parts = s.split('.')
            if (parts.size != 4) fail("$field : une adresse IPv4 comporte 4 nombres séparés par des points (ex. 192.168.1.10).")
            var v = 0L
            parts.forEachIndexed { i, p ->
                if (p.isEmpty() || p.length > 3 || !p.all { it in '0'..'9' }) fail("$field : « $p » n'est pas un octet valide (0 à 255).")
                if (p.length > 1 && p[0] == '0') fail("$field : « $p » est ambigu (zéro initial, parfois lu en octal). Écrivez ${p.trimStart('0').ifEmpty { "0" }}.")
                val n = p.toInt()
                if (n > 255) fail("$field : l'octet n° ${i + 1} (« $p ») dépasse 255.")
                v = (v shl 8) or n.toLong()
            }
            return Ipv4(v)
        }

        fun fromBinary(input: String): Ipv4 {
            val s = input.trim().replace(" ", "")
            val bits = if (s.contains('.')) {
                val parts = s.split('.')
                if (parts.size != 4) fail("Saisissez 4 groupes de 8 bits séparés par des points, ou 32 bits à la suite.")
                parts.forEachIndexed { i, p ->
                    if (p.isEmpty() || p.length > 8) fail("Le groupe n° ${i + 1} doit contenir de 1 à 8 bits.")
                }
                parts.joinToString("") { it.padStart(8, '0') }
            } else s
            if (bits.length != 32) fail("Une adresse IPv4 compte 32 bits (ici : ${bits.length}).")
            val bad = bits.indexOfFirst { it != '0' && it != '1' }
            if (bad >= 0) fail("Seuls les chiffres 0 et 1 sont autorisés (caractère « ${bits[bad]} »).")
            return Ipv4(bits.toLong(2))
        }
    }
}

data class SubnetInfo(
    val address: Ipv4,
    val prefix: Int,
    val mask: Ipv4,
    val wildcard: Ipv4,
    val network: Ipv4,
    val broadcast: Ipv4,
    val firstHost: Ipv4,
    val lastHost: Ipv4,
    val totalAddresses: Long,
    val usableHosts: Long,
    val addressClass: String,
    val addressType: String,
)

object Ipv4Calculator {

    fun maskFromPrefix(prefix: Int): Long = if (prefix == 0) 0L else (0xFFFFFFFFL shl (32 - prefix)) and 0xFFFFFFFFL

    /** Lit « 24 », « /24 » ou « 255.255.255.0 ». */
    fun parsePrefix(input: String): Int {
        val s = input.trim().removePrefix("/")
        if (s.isEmpty()) fail("Masque : champ vide.")
        if (!s.contains('.')) {
            val p = s.toIntOrNull() ?: fail("Masque : « $input » n'est ni un préfixe (0 à 32) ni un masque décimal pointé.")
            if (p !in 0..32) fail("Le préfixe doit être compris entre 0 et 32.")
            return p
        }
        val mask = Ipv4.parse(s, "Masque").value
        val prefix = java.lang.Long.bitCount(mask)
        if (maskFromPrefix(prefix) != mask) fail("Masque non contigu : les bits à 1 doivent être consécutifs (ex. 255.255.255.0).")
        return prefix
    }

    /** Lit « 192.168.1.10/24 » ou une adresse seule (dans ce cas [defaultPrefix]). */
    fun parseCidr(input: String, defaultPrefix: Int? = null): Pair<Ipv4, Int> {
        val s = input.trim()
        val slash = s.indexOf('/')
        return if (slash >= 0) {
            Ipv4.parse(s.substring(0, slash)) to parsePrefix(s.substring(slash + 1))
        } else {
            Ipv4.parse(s) to (defaultPrefix ?: fail("Ajoutez le préfixe, par exemple 192.168.1.0/24."))
        }
    }

    fun calculate(address: Ipv4, prefix: Int): SubnetInfo {
        require(prefix in 0..32)
        val mask = maskFromPrefix(prefix)
        val network = address.value and mask
        val broadcast = network or (mask.inv() and 0xFFFFFFFFL)
        val total = 1L shl (32 - prefix)
        val (first, last, usable) = when (prefix) {
            32 -> Triple(network, network, 1L)
            31 -> Triple(network, broadcast, 2L) // RFC 3021 : liaison point à point
            else -> Triple(network + 1, broadcast - 1, total - 2)
        }
        return SubnetInfo(
            address = address,
            prefix = prefix,
            mask = Ipv4(mask),
            wildcard = Ipv4(mask.inv() and 0xFFFFFFFFL),
            network = Ipv4(network),
            broadcast = Ipv4(broadcast),
            firstHost = Ipv4(first),
            lastHost = Ipv4(last),
            totalAddresses = total,
            usableHosts = usable,
            addressClass = addressClass(address),
            addressType = addressType(address),
        )
    }

    fun calculate(input: String, maskInput: String?): Outcome<SubnetInfo> = outcomeOf {
        val (ip, prefix) = if (!maskInput.isNullOrBlank() && !input.contains('/')) {
            Ipv4.parse(input) to parsePrefix(maskInput)
        } else parseCidr(input)
        calculate(ip, prefix)
    }

    fun addressClass(ip: Ipv4): String {
        val first = (ip.value ushr 24).toInt()
        return when {
            first < 128 -> "A"
            first < 192 -> "B"
            first < 224 -> "C"
            first < 240 -> "D (multicast)"
            else -> "E (réservée)"
        }
    }

    private data class Special(val network: Long, val prefix: Int, val label: String)

    private val specials = listOf(
        Special(0x00000000, 8, "Réseau « ce réseau » (RFC 791)"),
        Special(0x0A000000, 8, "Privée (RFC 1918)"),
        Special(0x64400000, 10, "Partagée CGNAT (RFC 6598)"),
        Special(0x7F000000, 8, "Boucle locale (loopback)"),
        Special(0xA9FE0000, 16, "Lien local (APIPA)"),
        Special(0xAC100000, 12, "Privée (RFC 1918)"),
        Special(0xC0000000, 24, "Réservée IETF (RFC 6890)"),
        Special(0xC0000200, 24, "Documentation TEST-NET-1 (RFC 5737)"),
        Special(0xC0A80000, 16, "Privée (RFC 1918)"),
        Special(0xC6120000, 15, "Tests de performance (RFC 2544)"),
        Special(0xC6336400, 24, "Documentation TEST-NET-2 (RFC 5737)"),
        Special(0xCB007100, 24, "Documentation TEST-NET-3 (RFC 5737)"),
        Special(0xE0000000, 4, "Multicast"),
        Special(0xFFFFFFFF, 32, "Diffusion limitée (broadcast)"),
        Special(0xF0000000, 4, "Réservée (usage futur)"),
    )

    fun addressType(ip: Ipv4): String =
        specials.firstOrNull { (ip.value and maskFromPrefix(it.prefix)) == it.network }?.label ?: "Publique"

    /** Plus petite liste de blocs CIDR couvrant exactement [start, end]. */
    fun rangeToCidrs(start: Ipv4, end: Ipv4): Outcome<List<Pair<Ipv4, Int>>> = outcomeOf {
        if (start.value > end.value) fail("L'adresse de début doit précéder l'adresse de fin.")
        val result = ArrayList<Pair<Ipv4, Int>>()
        var current = start.value
        while (current <= end.value) {
            // Taille maximale alignée sur current…
            var size = if (current == 0L) 32 else java.lang.Long.numberOfTrailingZeros(current).coerceAtMost(32)
            // … sans dépasser la fin.
            while (size > 0 && current + (1L shl size) - 1 > end.value) size--
            result += Ipv4(current) to (32 - size)
            current += 1L shl size
            if (result.size > 64) fail("Plage trop fragmentée.")
        }
        result
    }

    data class SubnetSplit(val prefix: Int, val subnets: List<SubnetInfo>, val totalSubnets: Long, val truncated: Boolean)

    /** Découpe un réseau en sous-réseaux de préfixe [newPrefix]. */
    fun split(network: Ipv4, prefix: Int, newPrefix: Int, maxListed: Int = 256): Outcome<SubnetSplit> = outcomeOf {
        if (newPrefix !in prefix..32) fail("Le nouveau préfixe doit être compris entre /$prefix et /32.")
        val base = network.value and maskFromPrefix(prefix)
        val count = 1L shl (newPrefix - prefix)
        val step = 1L shl (32 - newPrefix)
        val listed = minOf(count, maxListed.toLong()).toInt()
        val subnets = List(listed) { i -> calculate(Ipv4(base + i * step), newPrefix) }
        SubnetSplit(newPrefix, subnets, count, count > listed)
    }

    /** Préfixe nécessaire pour obtenir au moins [count] sous-réseaux. */
    fun prefixForSubnetCount(prefix: Int, count: Int): Outcome<Int> = outcomeOf {
        if (count < 1) fail("Il faut au moins un sous-réseau.")
        var bits = 0
        while ((1L shl bits) < count) bits++
        if (prefix + bits > 32) fail("Impossible : un /$prefix ne peut pas contenir $count sous-réseaux.")
        prefix + bits
    }

    /** Préfixe le plus grand permettant [hosts] hôtes utilisables. */
    fun prefixForHosts(hosts: Long): Outcome<Int> = outcomeOf {
        if (hosts < 1) fail("Il faut au moins un hôte.")
        if (hosts > 4294967294L) fail("Trop d'hôtes pour IPv4.")
        // Convention classique (réseau + broadcast réservés) ; /31 point à point non proposé ici.
        when (hosts) {
            1L -> 32
            else -> {
                var hostBits = 2
                while ((1L shl hostBits) - 2 < hosts) hostBits++
                32 - hostBits
            }
        }
    }

    fun contains(networkCidr: String, address: String): Outcome<Boolean> = outcomeOf {
        val (net, prefix) = parseCidr(networkCidr)
        val ip = Ipv4.parse(address)
        val mask = maskFromPrefix(prefix)
        (ip.value and mask) == (net.value and mask)
    }
}
