package com.alsalamy.droidtools.tools.convert

import com.alsalamy.droidtools.core.Num
import com.alsalamy.droidtools.core.Outcome
import com.alsalamy.droidtools.core.fail
import com.alsalamy.droidtools.core.outcomeOf
import java.math.BigDecimal

/**
 * Unité linéaire : valeur_de_base = valeur × [factor].
 * Les facteurs sont des définitions exactes (BIPM, NIST) sauf mention « ≈ » dans le libellé.
 */
data class UnitDef(val id: String, val label: String, val symbol: String, val factor: BigDecimal)

enum class Quantity(val label: String, val toolId: String) {
    LENGTH("Longueur", "convert_length"),
    AREA("Surface", "convert_area"),
    VOLUME("Volume", "convert_volume"),
    MASS("Masse", "convert_mass"),
    TEMPERATURE("Température", "convert_temperature"),
    SPEED("Vitesse", "convert_speed"),
    PRESSURE("Pression", "convert_pressure"),
    ENERGY("Énergie", "convert_energy"),
    POWER("Puissance", "convert_power"),
    TIME("Temps", "convert_time"),
    ANGLE("Angle", "convert_angle"),
    DATA("Stockage numérique", "convert_storage"),
}

object Units {
    private fun u(id: String, label: String, symbol: String, factor: String) = UnitDef(id, label, symbol, BigDecimal(factor))
    private fun ratio(numerator: String, denominator: String): BigDecimal =
        BigDecimal(numerator).divide(BigDecimal(denominator), Num.MC)

    private val PI = BigDecimal("3.141592653589793238462643383279503")

    // Base : mètre
    val length = listOf(
        u("nm", "Nanomètre", "nm", "1E-9"),
        u("um", "Micromètre", "µm", "1E-6"),
        u("mm", "Millimètre", "mm", "0.001"),
        u("cm", "Centimètre", "cm", "0.01"),
        u("dm", "Décimètre", "dm", "0.1"),
        u("m", "Mètre", "m", "1"),
        u("km", "Kilomètre", "km", "1000"),
        u("in", "Pouce", "in", "0.0254"),
        u("ft", "Pied", "ft", "0.3048"),
        u("yd", "Yard", "yd", "0.9144"),
        u("mi", "Mile", "mi", "1609.344"),
        u("nmi", "Mille marin", "NM", "1852"),
        u("au", "Unité astronomique", "au", "149597870700"),
        u("ly", "Année-lumière", "al", "9460730472580800"),
    )

    // Base : mètre carré
    val area = listOf(
        u("mm2", "Millimètre carré", "mm²", "1E-6"),
        u("cm2", "Centimètre carré", "cm²", "0.0001"),
        u("m2", "Mètre carré", "m²", "1"),
        u("a", "Are", "a", "100"),
        u("ha", "Hectare", "ha", "10000"),
        u("km2", "Kilomètre carré", "km²", "1000000"),
        u("in2", "Pouce carré", "in²", "0.00064516"),
        u("ft2", "Pied carré", "ft²", "0.09290304"),
        u("yd2", "Yard carré", "yd²", "0.83612736"),
        u("acre", "Acre", "ac", "4046.8564224"),
        u("mi2", "Mile carré", "mi²", "2589988.110336"),
    )

    // Base : litre
    val volume = listOf(
        u("ml", "Millilitre", "mL", "0.001"),
        u("cl", "Centilitre", "cL", "0.01"),
        u("dl", "Décilitre", "dL", "0.1"),
        u("l", "Litre", "L", "1"),
        u("m3", "Mètre cube", "m³", "1000"),
        u("cm3", "Centimètre cube", "cm³", "0.001"),
        u("tsp_us", "Cuillère à café (US)", "tsp", "0.00492892159375"),
        u("tbsp_us", "Cuillère à soupe (US)", "tbsp", "0.01478676478125"),
        u("floz_us", "Once liquide (US)", "fl oz", "0.0295735295625"),
        u("cup_us", "Tasse (US)", "cup", "0.2365882365"),
        u("pt_us", "Pinte (US)", "pt", "0.473176473"),
        u("gal_us", "Gallon (US)", "gal", "3.785411784"),
        u("floz_uk", "Once liquide (UK)", "fl oz UK", "0.0284130625"),
        u("pt_uk", "Pinte (UK)", "pt UK", "0.56826125"),
        u("gal_uk", "Gallon (UK)", "gal UK", "4.54609"),
        u("in3", "Pouce cube", "in³", "0.016387064"),
        u("ft3", "Pied cube", "ft³", "28.316846592"),
    )

    // Base : kilogramme
    val mass = listOf(
        u("ug", "Microgramme", "µg", "1E-9"),
        u("mg", "Milligramme", "mg", "1E-6"),
        u("ct", "Carat", "ct", "0.0002"),
        u("g", "Gramme", "g", "0.001"),
        u("kg", "Kilogramme", "kg", "1"),
        u("t", "Tonne", "t", "1000"),
        u("oz", "Once", "oz", "0.028349523125"),
        u("lb", "Livre (lb)", "lb", "0.45359237"),
        u("st", "Stone", "st", "6.35029318"),
        u("ton_us", "Tonne courte (US)", "sh tn", "907.18474"),
        u("ton_uk", "Tonne longue (UK)", "long tn", "1016.0469088"),
    )

    // Base : mètre par seconde
    val speed = listOf(
        u("mps", "Mètre par seconde", "m/s", "1"),
        UnitDef("kmh", "Kilomètre par heure", "km/h", ratio("1000", "3600")),
        u("mph", "Mile par heure", "mph", "0.44704"),
        UnitDef("kn", "Nœud", "kn", ratio("1852", "3600")),
        u("fps", "Pied par seconde", "ft/s", "0.3048"),
        u("mach", "Mach (≈ 340,29 m/s, air à 15 °C)", "Ma", "340.29"),
    )

    // Base : pascal
    val pressure = listOf(
        u("pa", "Pascal", "Pa", "1"),
        u("hpa", "Hectopascal", "hPa", "100"),
        u("kpa", "Kilopascal", "kPa", "1000"),
        u("mpa", "Mégapascal", "MPa", "1000000"),
        u("mbar", "Millibar", "mbar", "100"),
        u("bar", "Bar", "bar", "100000"),
        u("atm", "Atmosphère", "atm", "101325"),
        UnitDef("torr", "Torr", "Torr", ratio("101325", "760")),
        u("mmhg", "Millimètre de mercure", "mmHg", "133.322387415"),
        u("inhg", "Pouce de mercure", "inHg", "3386.389"),
        u("psi", "Livre par pouce carré", "psi", "6894.757293168361"),
    )

    // Base : joule
    val energy = listOf(
        u("j", "Joule", "J", "1"),
        u("kj", "Kilojoule", "kJ", "1000"),
        u("mj", "Mégajoule", "MJ", "1000000"),
        u("cal", "Calorie", "cal", "4.184"),
        u("kcal", "Kilocalorie", "kcal", "4184"),
        u("wh", "Wattheure", "Wh", "3600"),
        u("kwh", "Kilowattheure", "kWh", "3600000"),
        u("ev", "Électronvolt", "eV", "1.602176634E-19"),
        u("btu", "BTU (international)", "BTU", "1055.05585262"),
        u("ftlbf", "Pied-livre force", "ft·lbf", "1.3558179483314004"),
    )

    // Base : watt
    val power = listOf(
        u("mw_milli", "Milliwatt", "mW", "0.001"),
        u("w", "Watt", "W", "1"),
        u("kw", "Kilowatt", "kW", "1000"),
        u("mw", "Mégawatt", "MW", "1000000"),
        u("ch", "Cheval-vapeur (métrique)", "ch", "735.49875"),
        u("hp", "Horsepower (mécanique)", "hp", "745.69987158227022"),
        u("btuh", "BTU par heure", "BTU/h", "0.29307107017222"),
        UnitDef("kcalh", "Kilocalorie par heure", "kcal/h", ratio("4184", "3600")),
    )

    // Base : seconde
    val time = listOf(
        u("ns", "Nanoseconde", "ns", "1E-9"),
        u("us", "Microseconde", "µs", "1E-6"),
        u("ms", "Milliseconde", "ms", "0.001"),
        u("s", "Seconde", "s", "1"),
        u("min", "Minute", "min", "60"),
        u("h", "Heure", "h", "3600"),
        u("d", "Jour", "j", "86400"),
        u("wk", "Semaine", "sem.", "604800"),
        u("mo", "Mois (moyen, 30,44 j)", "mois", "2629746"),
        u("yr", "Année (moyenne, 365,2425 j)", "an", "31556952"),
    )

    // Base : degré
    val angle = listOf(
        u("deg", "Degré", "°", "1"),
        UnitDef("rad", "Radian", "rad", BigDecimal(180).divide(PI, Num.MC)),
        u("grad", "Grade", "gon", "0.9"),
        UnitDef("arcmin", "Minute d'arc", "′", ratio("1", "60")),
        UnitDef("arcsec", "Seconde d'arc", "″", ratio("1", "3600")),
        u("turn", "Tour", "tr", "360"),
        u("mil", "Millième OTAN", "mil", "0.05625"),
    )

    // Base : bit
    val data = listOf(
        u("bit", "Bit", "bit", "1"),
        u("byte", "Octet", "o", "8"),
        u("kbit", "Kilobit", "kbit", "1000"),
        u("mbit", "Mégabit", "Mbit", "1000000"),
        u("gbit", "Gigabit", "Gbit", "1000000000"),
        u("kb", "Kilooctet", "ko", "8000"),
        u("mb", "Mégaoctet", "Mo", "8000000"),
        u("gb", "Gigaoctet", "Go", "8000000000"),
        u("tb", "Téraoctet", "To", "8000000000000"),
        u("pb", "Pétaoctet", "Po", "8000000000000000"),
        u("kib", "Kibioctet", "Kio", "8192"),
        u("mib", "Mébioctet", "Mio", "8388608"),
        u("gib", "Gibioctet", "Gio", "8589934592"),
        u("tib", "Tébioctet", "Tio", "8796093022208"),
        u("pib", "Pébioctet", "Pio", "9007199254740992"),
    )

    /** Températures : traitées à part (conversions affines). */
    val temperature = listOf(
        u("c", "Degré Celsius", "°C", "1"),
        u("f", "Degré Fahrenheit", "°F", "1"),
        u("k", "Kelvin", "K", "1"),
        u("r", "Degré Rankine", "°R", "1"),
    )

    fun of(quantity: Quantity): List<UnitDef> = when (quantity) {
        Quantity.LENGTH -> length
        Quantity.AREA -> area
        Quantity.VOLUME -> volume
        Quantity.MASS -> mass
        Quantity.TEMPERATURE -> temperature
        Quantity.SPEED -> speed
        Quantity.PRESSURE -> pressure
        Quantity.ENERGY -> energy
        Quantity.POWER -> power
        Quantity.TIME -> time
        Quantity.ANGLE -> angle
        Quantity.DATA -> data
    }

    /** Unités proposées par défaut (source, cible). */
    fun defaults(quantity: Quantity): Pair<String, String> = when (quantity) {
        Quantity.LENGTH -> "m" to "ft"
        Quantity.AREA -> "m2" to "ft2"
        Quantity.VOLUME -> "l" to "gal_us"
        Quantity.MASS -> "kg" to "lb"
        Quantity.TEMPERATURE -> "c" to "f"
        Quantity.SPEED -> "kmh" to "mph"
        Quantity.PRESSURE -> "bar" to "psi"
        Quantity.ENERGY -> "kcal" to "kj"
        Quantity.POWER -> "kw" to "ch"
        Quantity.TIME -> "h" to "min"
        Quantity.ANGLE -> "deg" to "rad"
        Quantity.DATA -> "gb" to "gib"
    }
}

object UnitConverter {

    fun convert(value: BigDecimal, quantity: Quantity, fromId: String, toId: String): Outcome<BigDecimal> = outcomeOf {
        val units = Units.of(quantity)
        val from = units.firstOrNull { it.id == fromId } ?: fail("Unité inconnue.")
        val to = units.firstOrNull { it.id == toId } ?: fail("Unité inconnue.")
        if (quantity == Quantity.TEMPERATURE) convertTemperature(value, from.id, to.id)
        else {
            if (quantity in nonNegative && value.signum() < 0) fail("Une ${quantity.label.lowercase()} ne peut pas être négative.")
            value.multiply(from.factor).divide(to.factor, Num.MC)
        }
    }

    /** Convertit vers toutes les unités de la grandeur. */
    fun convertAll(value: BigDecimal, quantity: Quantity, fromId: String): Outcome<List<Pair<UnitDef, BigDecimal>>> = outcomeOf {
        Units.of(quantity).map { unit ->
            when (val r = convert(value, quantity, fromId, unit.id)) {
                is Outcome.Ok -> unit to r.value
                is Outcome.Err -> fail(r.message)
            }
        }
    }

    private val nonNegative = setOf(Quantity.LENGTH, Quantity.AREA, Quantity.VOLUME, Quantity.MASS, Quantity.DATA)

    private val ABSOLUTE_ZERO_C = BigDecimal("-273.15")
    private val K_OFFSET = BigDecimal("273.15")
    private val NINE_FIFTHS = BigDecimal("1.8")
    private val F_OFFSET = BigDecimal("32")
    private val R_OFFSET = BigDecimal("491.67")

    private fun convertTemperature(value: BigDecimal, from: String, to: String): BigDecimal {
        val celsius = when (from) {
            "c" -> value
            "f" -> value.subtract(F_OFFSET).divide(NINE_FIFTHS, Num.MC)
            "k" -> value.subtract(K_OFFSET)
            "r" -> value.subtract(R_OFFSET).divide(NINE_FIFTHS, Num.MC)
            else -> fail("Unité inconnue.")
        }
        if (celsius < ABSOLUTE_ZERO_C) fail("Température inférieure au zéro absolu (-273,15 °C) : impossible.")
        return when (to) {
            "c" -> celsius
            "f" -> celsius.multiply(NINE_FIFTHS).add(F_OFFSET)
            "k" -> celsius.add(K_OFFSET)
            "r" -> celsius.add(K_OFFSET).multiply(NINE_FIFTHS)
            else -> fail("Unité inconnue.")
        }
    }
}
