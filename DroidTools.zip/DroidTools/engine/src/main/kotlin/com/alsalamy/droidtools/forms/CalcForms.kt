package com.alsalamy.droidtools.forms

import com.alsalamy.droidtools.core.Num
import com.alsalamy.droidtools.tools.calc.BillSplitter
import com.alsalamy.droidtools.tools.calc.Discount
import com.alsalamy.droidtools.tools.calc.Percentages
import com.alsalamy.droidtools.tools.calc.Ratio
import com.alsalamy.droidtools.tools.calc.RuleOfThree
import com.alsalamy.droidtools.tools.calc.Stats
import com.alsalamy.droidtools.tools.calc.Vat
import com.alsalamy.droidtools.tools.convert.NumberBase
import com.alsalamy.droidtools.tools.convert.Quantity
import com.alsalamy.droidtools.tools.convert.Radix
import com.alsalamy.droidtools.tools.convert.UnitConverter
import com.alsalamy.droidtools.tools.convert.Units
import java.math.BigDecimal

internal object CalcForms {

    val percentages: ToolForm = ToolForm(
        fields = listOf(
            ChoiceInput(
                "mode", "Calcul",
                listOf(
                    Choice("of", "X % de Y"),
                    Choice("share", "Part en %"),
                    Choice("change", "Évolution"),
                    Choice("apply", "Hausse / baisse"),
                ),
            ),
            TextInput("p", "Pourcentage", InputKind.NUMBER, placeholder = "15", suffix = "%", visibleWhen = visibleIf("mode", "of")),
            TextInput("x", "Valeur", InputKind.NUMBER, placeholder = "80", visibleWhen = visibleIf("mode", "of")),
            TextInput("part", "Partie", InputKind.NUMBER, placeholder = "30", visibleWhen = visibleIf("mode", "share")),
            TextInput("total", "Total", InputKind.NUMBER, placeholder = "120", visibleWhen = visibleIf("mode", "share")),
            TextInput("from", "Valeur de départ", InputKind.NUMBER, placeholder = "80", visibleWhen = visibleIf("mode", "change")),
            TextInput("to", "Valeur d'arrivée", InputKind.NUMBER, placeholder = "100", visibleWhen = visibleIf("mode", "change")),
            TextInput("value", "Valeur", InputKind.NUMBER, placeholder = "100", visibleWhen = visibleIf("mode", "apply")),
            TextInput(
                "rate", "Variation", InputKind.NUMBER, placeholder = "-20", suffix = "%",
                supportingText = "Valeur négative pour une baisse", visibleWhen = visibleIf("mode", "apply"),
            ),
        ),
    ) { v, _ ->
        when (v["mode"]) {
            "of" -> {
                val p = v.number("p", "Pourcentage")
                val x = v.number("x", "Valeur")
                FormResult(ResultRow("${fmt(p)} % de ${fmt(x)}", fmt(Percentages.percentOf(p, x)), emphasis = true))
            }
            "share" -> {
                val part = v.number("part", "Partie")
                val total = v.number("total", "Total")
                val r = Percentages.share(part, total).orFail()
                FormResult(ResultRow("${fmt(part)} sur ${fmt(total)}", percent(r), emphasis = true))
            }
            "change" -> {
                val from = v.number("from", "Valeur de départ")
                val to = v.number("to", "Valeur d'arrivée")
                val r = Percentages.change(from, to).orFail()
                val diff = to.subtract(from)
                FormResult(
                    ResultRow("Évolution", signed(percent(r), r), emphasis = true),
                    ResultRow("Différence", signed(fmt(diff), diff)),
                    ResultRow("Coefficient multiplicateur", fmt(to.divide(from, Num.MC))),
                )
            }
            else -> {
                val value = v.number("value", "Valeur")
                val rate = v.number("rate", "Variation")
                val r = Percentages.applyChange(value, rate)
                val diff = r.subtract(value)
                FormResult(
                    ResultRow("Résultat", fmt(r), emphasis = true),
                    ResultRow("Variation", signed(fmt(diff), diff)),
                )
            }
        }
    }

    val vat: ToolForm = ToolForm(
        fields = listOf(
            ChoiceInput("from", "Montant saisi", listOf(Choice("ht", "Hors taxes (HT)"), Choice("ttc", "Toutes taxes (TTC)"))),
            TextInput("amount", "Montant", InputKind.NUMBER, placeholder = "100"),
            ChoiceInput(
                "rate", "Taux de TVA",
                listOf(Choice("20", "20 %"), Choice("10", "10 %"), Choice("5.5", "5,5 %"), Choice("2.1", "2,1 %"), Choice("custom", "Autre")),
            ),
            TextInput("customRate", "Taux personnalisé", InputKind.NUMBER, placeholder = "8,5", suffix = "%", visibleWhen = visibleIf("rate", "custom")),
        ),
        intro = "Taux français proposés par défaut. Montants arrondis au centime.",
    ) { v, _ ->
        val amount = v.number("amount", "Montant")
        val rate = if (v["rate"] == "custom") v.number("customRate", "Taux de TVA") else BigDecimal(v["rate"])
        val fromHt = v["from"] == "ht"
        val r = (if (fromHt) Vat.fromExcludingTax(amount, rate) else Vat.fromIncludingTax(amount, rate)).orFail()
        FormResult(
            ResultRow("Montant HT", money(r.excludingTax), emphasis = !fromHt),
            ResultRow("TVA à ${fmt(rate)} %", money(r.vat)),
            ResultRow("Montant TTC", money(r.includingTax), emphasis = fromHt),
        )
    }

    val discount: ToolForm = ToolForm(
        fields = listOf(
            TextInput("price", "Prix initial", InputKind.NUMBER, placeholder = "59,90"),
            TextInput("r1", "Remise", InputKind.NUMBER, placeholder = "30", suffix = "%"),
            TextInput("r2", "Remise supplémentaire (facultative)", InputKind.NUMBER, placeholder = "10", suffix = "%",
                supportingText = "Appliquée sur le prix déjà remisé"),
        ),
    ) { v, _ ->
        val price = v.number("price", "Prix")
        val rates = listOfNotNull(v.number("r1", "Remise"), v.optionalNumber("r2", "Remise supplémentaire"))
        val r = Discount.apply(price, rates).orFail()
        val items = mutableListOf<ResultItem>(
            ResultRow("Prix final", money(r.finalPrice), emphasis = true),
            ResultRow("Économie", money(r.savings)),
        )
        if (rates.size > 1) items += ResultRow("Remise totale équivalente", percent(r.effectiveRate))
        FormResult(items)
    }

    val ruleOfThree: ToolForm = ToolForm(
        fields = listOf(
            TextInput("a", "A", InputKind.NUMBER, placeholder = "3"),
            TextInput("b", "correspond à B", InputKind.NUMBER, placeholder = "4,50"),
            TextInput("c", "C", InputKind.NUMBER, placeholder = "5"),
        ),
        intro = "Si A correspond à B, alors C correspond à X = B × C ÷ A.",
    ) { v, _ ->
        val a = v.number("a", "A")
        val b = v.number("b", "B")
        val c = v.number("c", "C")
        val x = RuleOfThree.solve(a, b, c).orFail()
        FormResult(ResultRow("X (pour C = ${fmt(c)})", fmt(x), emphasis = true))
    }

    val billSplit: ToolForm = ToolForm(
        fields = listOf(
            TextInput("amount", "Montant de l'addition", InputKind.NUMBER, placeholder = "86,40"),
            TextInput("tip", "Pourboire", InputKind.NUMBER, default = "0", suffix = "%"),
            TextInput("people", "Nombre de personnes", InputKind.INTEGER, default = "2"),
        ),
    ) { v, _ ->
        val amount = v.number("amount", "Montant")
        val tip = v.optionalNumber("tip", "Pourboire") ?: BigDecimal.ZERO
        val people = v.integer("people", "Nombre de personnes", 1..1000)
        val r = BillSplitter.split(amount, tip, people).orFail()
        val items = mutableListOf<ResultItem>(
            ResultRow("Par personne", money(r.share), emphasis = true),
            ResultRow("Total à payer", money(r.total)),
        )
        if (r.tip.signum() > 0) items += ResultRow("Dont pourboire", money(r.tip))
        if (r.peoplePayingOneMoreCent > 0) {
            val more = r.peoplePayingOneMoreCent
            items += ResultNotice(
                "Pour tomber juste : ${plural(more, "personne paie", "personnes paient")} ${money(r.share.add(BigDecimal("0.01")))}, " +
                    "${plural(r.people - more, "personne paie", "personnes paient")} ${money(r.share)}.",
            )
        }
        FormResult(items)
    }

    val average: ToolForm = ToolForm(
        fields = listOf(
            TextInput("values", "Valeurs", InputKind.MULTILINE, placeholder = "12 15,5 9 18",
                supportingText = "Séparées par des espaces, des retours à la ligne ou des points-virgules"),
            TextInput("weights", "Coefficients (facultatif)", InputKind.MULTILINE, placeholder = "1 2 1 3",
                supportingText = "Un coefficient par valeur, dans le même ordre"),
        ),
    ) { v, _ ->
        val values = Stats.parseList(v.requiredText("values"), "Valeurs")
        if (values.isEmpty()) awaiting()
        val weights = if (v.isBlank("weights")) null else Stats.parseList(v["weights"], "Coefficients")
        val s = Stats.compute(values, weights).orFail()
        val items = mutableListOf<ResultItem>(ResultRow("Moyenne", fmt(s.mean), emphasis = true))
        s.weightedMean?.let { items += ResultRow("Moyenne pondérée", fmt(it)) }
        items += listOf(
            ResultRow("Médiane", fmt(s.median)),
            ResultRow("Nombre de valeurs", count(s.count)),
            ResultRow("Somme", fmt(s.sum)),
            ResultRow("Minimum", fmt(s.min)),
            ResultRow("Maximum", fmt(s.max)),
            ResultRow("Écart type (population)", Num.formatDouble(s.populationStdDev)),
        )
        s.sampleStdDev?.let { items += ResultRow("Écart type (échantillon)", Num.formatDouble(it)) }
        FormResult(items)
    }

    val ratio: ToolForm = ToolForm(
        fields = listOf(
            ChoiceInput("mode", "Calcul", listOf(Choice("simplify", "Simplifier a:b"), Choice("solve", "Résoudre a:b = c:x"))),
            TextInput("a", "a", InputKind.NUMBER, placeholder = "16"),
            TextInput("b", "b", InputKind.NUMBER, placeholder = "9"),
            TextInput("c", "c", InputKind.NUMBER, placeholder = "1920", visibleWhen = visibleIf("mode", "solve")),
        ),
    ) { v, _ ->
        val a = v.number("a", "a")
        val b = v.number("b", "b")
        if (v["mode"] == "solve") {
            val c = v.number("c", "c")
            val x = Ratio.solve(a, b, c).orFail()
            FormResult(ResultRow("${fmt(a)}:${fmt(b)} = ${fmt(c)}:x", "x = ${fmt(x)}", emphasis = true))
        } else {
            val r = Ratio.simplify(a, b).orFail()
            FormResult(
                ResultRow("Ratio simplifié", "${r.left}:${r.right}", emphasis = true),
                ResultRow("Quotient a ÷ b", fmt(r.quotient)),
                ResultRow("Part de a dans a + b", percent(r.leftShare)),
            )
        }
    }

    fun conversion(quantity: Quantity): ToolForm {
        val units = Units.of(quantity)
        val (fromDefault, toDefault) = Units.defaults(quantity)
        return ToolForm(
            fields = listOf(
                TextInput("value", "Valeur", InputKind.NUMBER, default = "1"),
                ChoiceInput("unit", "Unité de départ", units.map { Choice(it.id, "${it.label} (${it.symbol})") }, default = fromDefault),
            ),
        ) { v, _ ->
            val value = v.number("value", "Valeur")
            val source = units.first { it.id == v["unit"] }
            val all = UnitConverter.convertAll(value, quantity, source.id).orFail()
            FormResult(
                listOf<ResultItem>(ResultHeader("${fmt(value)} ${source.symbol} =")) +
                    all.filter { it.first.id != source.id }.map { (unit, result) ->
                        ResultRow(unit.label, "${fmt(result, 10)} ${unit.symbol}", emphasis = unit.id == toDefault)
                    },
            )
        }
    }

    val numberBase: ToolForm = ToolForm(
        fields = listOf(
            TextInput("input", "Nombre", InputKind.CODE, placeholder = "255"),
            ChoiceInput(
                "radix", "Base de départ",
                Radix.entries.map { Choice(it.name, "${it.label} (${it.base})") }, default = Radix.DECIMAL.name,
            ),
        ),
        intro = "Préfixes acceptés : 0x (hexadécimal), 0b (binaire), 0o (octal). Entiers jusqu'à 4096 bits.",
    ) { v, _ ->
        val r = NumberBase.convert(v.requiredText("input"), Radix.valueOf(v["radix"])).orFail()
        val items = mutableListOf<ResultItem>(
            ResultRow("Décimal", r.decimal, monospace = true),
            ResultRow("Hexadécimal", r.hexadecimal, monospace = true),
            ResultRow("Binaire", NumberBase.groupBinary(r.binary), monospace = true),
            ResultRow("Octal", r.octal, monospace = true),
            ResultRow("Taille", plural(r.bitLength, "bit"), copyable = false),
        )
        r.twosComplement?.let { items += ResultRow("Complément à deux", it, monospace = true) }
        FormResult(items)
    }
}
