package com.alsalamy.droidtools.tools.time

import com.alsalamy.droidtools.core.Outcome
import com.alsalamy.droidtools.core.fail
import com.alsalamy.droidtools.core.outcomeOf
import java.security.SecureRandom
import java.time.Instant
import java.util.UUID

/**
 * ULID (https://github.com/ulid/spec) : 48 bits d'horodatage en millisecondes
 * + 80 bits d'aléa cryptographique, encodés en Base32 de Crockford (26 caractères).
 */
object Ulid {
    private const val ALPHABET = "0123456789ABCDEFGHJKMNPQRSTVWXYZ"
    const val MAX_TIMESTAMP = 0xFFFFFFFFFFFFL // 2^48 - 1

    fun generate(timeMillis: Long, random: SecureRandom): String {
        val randomness = ByteArray(10).also(random::nextBytes)
        return encode(timeMillis, randomness)
    }

    /** Encode un horodatage et 10 octets d'aléa. */
    fun encode(timeMillis: Long, randomness: ByteArray): String {
        require(timeMillis in 0..MAX_TIMESTAMP) { "Horodatage hors limites" }
        require(randomness.size == 10) { "10 octets d'aléa attendus" }
        val chars = CharArray(26)
        // Horodatage : 10 caractères (50 bits, dont 2 bits de tête nuls).
        var t = timeMillis
        for (i in 9 downTo 0) {
            chars[i] = ALPHABET[(t and 31).toInt()]
            t = t ushr 5
        }
        // Aléa : 80 bits = 16 caractères de 5 bits.
        var bitBuffer = 0L
        var bitCount = 0
        var out = 10
        for (b in randomness) {
            bitBuffer = (bitBuffer shl 8) or (b.toLong() and 0xFF)
            bitCount += 8
            while (bitCount >= 5) {
                bitCount -= 5
                chars[out++] = ALPHABET[((bitBuffer ushr bitCount) and 31).toInt()]
            }
        }
        return String(chars)
    }

    data class Decoded(val timestamp: Instant, val randomHex: String)

    fun decode(input: String): Outcome<Decoded> = outcomeOf {
        val s = input.trim().uppercase().replace('I', '1').replace('L', '1').replace('O', '0')
        if (s.length != 26) fail("Un ULID comporte exactement 26 caractères (ici : ${s.length}).")
        val values = s.mapIndexed { i, c ->
            val v = ALPHABET.indexOf(c)
            if (v < 0) fail("Caractère « $c » invalide (position ${i + 1}).")
            v
        }
        if (values[0] > 7) fail("ULID invalide : l'horodatage dépasse 48 bits.")
        var time = 0L
        for (i in 0 until 10) time = (time shl 5) or values[i].toLong()
        val sb = StringBuilder()
        var bitBuffer = 0L
        var bitCount = 0
        for (i in 10 until 26) {
            bitBuffer = (bitBuffer shl 5) or values[i].toLong()
            bitCount += 5
            while (bitCount >= 8) {
                bitCount -= 8
                sb.append("%02x".format(((bitBuffer ushr bitCount) and 0xFF).toInt()))
            }
        }
        Decoded(Instant.ofEpochMilli(time), sb.toString())
    }
}

enum class UuidVersion(val label: String) {
    V4("v4 — aléatoire"),
    V7("v7 — horodaté (RFC 9562)"),
}

object Uuids {
    /** UUID v4 : 122 bits issus de SecureRandom. */
    fun v4(random: SecureRandom): UUID {
        val bytes = ByteArray(16).also(random::nextBytes)
        bytes[6] = ((bytes[6].toInt() and 0x0F) or 0x40).toByte()
        bytes[8] = ((bytes[8].toInt() and 0x3F) or 0x80).toByte()
        return fromBytes(bytes)
    }

    /** UUID v7 : 48 bits d'horodatage Unix (ms) + 74 bits d'aléa (RFC 9562, section 5.7). */
    fun v7(timeMillis: Long, random: SecureRandom): UUID {
        require(timeMillis in 0..Ulid.MAX_TIMESTAMP)
        val bytes = ByteArray(16).also(random::nextBytes)
        for (i in 0 until 6) bytes[i] = (timeMillis ushr (40 - 8 * i)).toByte()
        bytes[6] = ((bytes[6].toInt() and 0x0F) or 0x70).toByte()
        bytes[8] = ((bytes[8].toInt() and 0x3F) or 0x80).toByte()
        return fromBytes(bytes)
    }

    fun v7Timestamp(uuid: UUID): Long? =
        if (uuid.version() == 7) uuid.mostSignificantBits ushr 16 else null

    private fun fromBytes(b: ByteArray): UUID {
        var msb = 0L
        var lsb = 0L
        for (i in 0 until 8) msb = (msb shl 8) or (b[i].toLong() and 0xFF)
        for (i in 8 until 16) lsb = (lsb shl 8) or (b[i].toLong() and 0xFF)
        return UUID(msb, lsb)
    }

    fun format(uuid: UUID, uppercase: Boolean, hyphens: Boolean): String {
        var s = uuid.toString()
        if (!hyphens) s = s.replace("-", "")
        return if (uppercase) s.uppercase() else s
    }
}
