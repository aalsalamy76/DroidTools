package com.alsalamy.droidtools.tools.time

import com.alsalamy.droidtools.core.Outcome
import com.alsalamy.droidtools.core.fail
import com.alsalamy.droidtools.core.outcomeOf
import java.math.BigInteger
import java.time.DateTimeException
import java.time.DayOfWeek
import java.time.Duration
import java.time.Instant
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.LocalTime
import java.time.OffsetDateTime
import java.time.Period
import java.time.ZoneId
import java.time.ZonedDateTime
import java.time.format.DateTimeFormatter
import java.time.format.DateTimeParseException
import java.time.format.ResolverStyle
import java.time.format.TextStyle
import java.time.temporal.ChronoUnit
import java.time.temporal.IsoFields
import java.util.Locale

enum class TimestampUnit(val label: String) {
    AUTO("Détection automatique"),
    SECONDS("Secondes"),
    MILLISECONDS("Millisecondes"),
    MICROSECONDS("Microsecondes"),
    NANOSECONDS("Nanosecondes"),
}

data class TimestampInfo(
    val instant: Instant,
    val detectedUnit: TimestampUnit,
    val utcIso: String,
    val localIso: String,
    val localReadable: String,
    val zone: String,
    val epochSeconds: Long,
    val epochMillis: Long,
    val relative: String,
    val dayOfYear: Int,
    val isoWeek: Int,
)

data class DateToTimestamp(
    val epochSeconds: Long,
    val epochMillis: Long,
    val utcIso: String,
    val zonedIso: String,
    /** Avertissement en cas de changement d'heure (heure inexistante ou ambiguë). */
    val dstWarning: String?,
)

data class DateDifference(
    val period: Period,
    val totalDays: Long,
    val weeks: Long,
    val remainingDays: Long,
    val businessDays: Long,
    val totalMonths: Long,
    val negative: Boolean,
)

data class AgeResult(
    val years: Int,
    val months: Int,
    val days: Int,
    val totalDays: Long,
    val totalMonths: Long,
    val bornOn: String,
    val nextBirthday: LocalDate,
    val daysUntilNextBirthday: Long,
    val nextAge: Int,
    val isBirthdayToday: Boolean,
)

data class CountdownResult(
    val past: Boolean,
    val days: Long,
    val hours: Long,
    val minutes: Long,
    val seconds: Long,
    val totalSeconds: Long,
)

object TimeTools {
    private val FR = Locale.FRENCH
    private val readable = DateTimeFormatter.ofPattern("EEEE d MMMM uuuu 'à' HH:mm:ss", FR)

    /** Limites raisonnables : années 1 à 9999. */
    private val MIN_INSTANT = Instant.parse("0001-01-01T00:00:00Z")
    private val MAX_INSTANT = Instant.parse("9999-12-31T23:59:59Z")

    // ------------------------------------------------------------ Timestamp → date

    fun fromTimestamp(input: String, unit: TimestampUnit, zone: ZoneId, now: Instant): Outcome<TimestampInfo> = outcomeOf {
        val cleaned = input.trim().replace(" ", "").replace("_", "").replace('−', '-')
        if (cleaned.isEmpty()) fail("Saisissez un timestamp.")
        if (!Regex("-?\\d{1,25}").matches(cleaned)) fail("Un timestamp est un nombre entier (ex. 1700000000).")
        val value = BigInteger(cleaned)
        val digits = value.abs().toString().length
        val resolved = if (unit != TimestampUnit.AUTO) unit else when {
            digits <= 11 -> TimestampUnit.SECONDS
            digits <= 14 -> TimestampUnit.MILLISECONDS
            digits <= 17 -> TimestampUnit.MICROSECONDS
            else -> TimestampUnit.NANOSECONDS
        }
        val nanosPerUnit = when (resolved) {
            TimestampUnit.SECONDS, TimestampUnit.AUTO -> BigInteger.valueOf(1_000_000_000)
            TimestampUnit.MILLISECONDS -> BigInteger.valueOf(1_000_000)
            TimestampUnit.MICROSECONDS -> BigInteger.valueOf(1_000)
            TimestampUnit.NANOSECONDS -> BigInteger.ONE
        }
        val totalNanos = value.multiply(nanosPerUnit)
        val billion = BigInteger.valueOf(1_000_000_000)
        val parts = totalNanos.divideAndRemainder(billion)
        var seconds = parts[0]
        var nanos = parts[1]
        if (nanos.signum() < 0) { seconds = seconds.subtract(BigInteger.ONE); nanos = nanos.add(billion) }
        if (seconds < BigInteger.valueOf(MIN_INSTANT.epochSecond) || seconds > BigInteger.valueOf(MAX_INSTANT.epochSecond)) {
            fail("Date hors de la plage prise en charge (années 1 à 9999).")
        }
        val instant = Instant.ofEpochSecond(seconds.toLong(), nanos.toLong())
        describe(instant, resolved, zone, now)
    }

    fun describe(instant: Instant, unit: TimestampUnit, zone: ZoneId, now: Instant): TimestampInfo {
        val zoned = instant.atZone(zone)
        val offset = zoned.offset.id.let { if (it == "Z") "+00:00" else it }
        return TimestampInfo(
            instant = instant,
            detectedUnit = unit,
            utcIso = DateTimeFormatter.ISO_INSTANT.format(instant),
            localIso = zoned.toOffsetDateTime().format(DateTimeFormatter.ISO_OFFSET_DATE_TIME),
            localReadable = zoned.format(readable).replaceFirstChar { it.titlecase(FR) },
            zone = "${zone.id} (UTC$offset)",
            epochSeconds = instant.epochSecond,
            epochMillis = instant.toEpochMilli(),
            relative = relative(instant, now),
            dayOfYear = zoned.dayOfYear,
            isoWeek = zoned.get(IsoFields.WEEK_OF_WEEK_BASED_YEAR),
        )
    }

    fun relative(instant: Instant, now: Instant): String {
        val seconds = Duration.between(now, instant).seconds
        val future = seconds > 0
        val abs = kotlin.math.abs(seconds)
        val text = when {
            abs < 60 -> return "à l'instant"
            abs < 3600 -> plural(abs / 60, "minute")
            abs < 86_400 -> plural(abs / 3600, "heure")
            abs < 86_400L * 30 -> plural(abs / 86_400, "jour")
            abs < 86_400L * 365 -> "${abs / (86_400L * 30)} mois"
            else -> plural(abs / (86_400L * 365), "an")
        }
        return if (future) "dans $text" else "il y a $text"
    }

    private fun plural(n: Long, word: String) = "$n $word" + if (n > 1) "s" else ""

    // ------------------------------------------------------------ Date → timestamp

    private val dateTimeFormats: List<Pair<DateTimeFormatter, Boolean>> = listOf(
        "dd/MM/uuuu HH:mm:ss", "dd/MM/uuuu HH:mm", "dd/MM/uuuu",
        "dd-MM-uuuu HH:mm:ss", "dd-MM-uuuu HH:mm", "dd-MM-uuuu",
        "dd.MM.uuuu HH:mm:ss", "dd.MM.uuuu HH:mm", "dd.MM.uuuu",
        "uuuu-MM-dd HH:mm:ss", "uuuu-MM-dd HH:mm", "uuuu-MM-dd",
        "uuuu-MM-dd'T'HH:mm:ss", "uuuu-MM-dd'T'HH:mm",
    ).map { DateTimeFormatter.ofPattern(it, FR).withResolverStyle(ResolverStyle.STRICT) to it.contains("HH") }

    /** Lit une date (et heure facultative) au format JJ/MM/AAAA [HH:MM[:SS]] ou ISO. */
    fun parseLocalDateTime(input: String): LocalDateTime {
        val s = input.trim()
        if (s.isEmpty()) fail("Saisissez une date.")
        for ((formatter, hasTime) in dateTimeFormats) {
            try {
                return if (hasTime) LocalDateTime.parse(s, formatter) else LocalDate.parse(s, formatter).atStartOfDay()
            } catch (e: DateTimeParseException) {
                // Format suivant.
            }
        }
        fail("Date invalide ou inexistante. Formats acceptés : JJ/MM/AAAA, JJ/MM/AAAA HH:MM, AAAA-MM-JJ HH:MM:SS.")
    }

    fun parseLocalDate(input: String): LocalDate {
        val dt = parseLocalDateTime(input)
        if (dt.toLocalTime() != LocalTime.MIDNIGHT && input.contains(':')) fail("Saisissez une date sans heure.")
        return dt.toLocalDate()
    }

    fun toTimestamp(input: String, zone: ZoneId): Outcome<DateToTimestamp> = outcomeOf {
        val s = input.trim()
        // Date ISO avec décalage explicite (ex. 2024-03-01T10:00:00+01:00 ou …Z).
        val withOffset = try { OffsetDateTime.parse(s) } catch (e: DateTimeParseException) { null }
        if (withOffset != null) {
            val instant = withOffset.toInstant()
            return@outcomeOf DateToTimestamp(instant.epochSecond, instant.toEpochMilli(),
                DateTimeFormatter.ISO_INSTANT.format(instant), withOffset.format(DateTimeFormatter.ISO_OFFSET_DATE_TIME), null)
        }
        val local = parseLocalDateTime(s)
        val offsets = zone.rules.getValidOffsets(local)
        val warning = when (offsets.size) {
            0 -> "Cette heure n'existe pas dans le fuseau ${zone.id} (passage à l'heure d'été) : elle a été décalée."
            2 -> "Cette heure existe deux fois dans le fuseau ${zone.id} (passage à l'heure d'hiver) : la première occurrence est utilisée."
            else -> null
        }
        val zoned = ZonedDateTime.of(local, zone)
        val instant = zoned.toInstant()
        DateToTimestamp(instant.epochSecond, instant.toEpochMilli(), DateTimeFormatter.ISO_INSTANT.format(instant),
            zoned.toOffsetDateTime().format(DateTimeFormatter.ISO_OFFSET_DATE_TIME), warning)
    }

    // ------------------------------------------------------------ Différence de dates

    fun difference(start: LocalDate, end: LocalDate, includeEndDay: Boolean = false): DateDifference {
        val negative = end < start
        val from = if (negative) end else start
        var to = if (negative) start else end
        if (includeEndDay) to = to.plusDays(1)
        val totalDays = ChronoUnit.DAYS.between(from, to)
        return DateDifference(
            period = Period.between(from, to),
            totalDays = totalDays,
            weeks = totalDays / 7,
            remainingDays = totalDays % 7,
            businessDays = businessDaysBetween(from, to),
            totalMonths = ChronoUnit.MONTHS.between(from, to),
            negative = negative,
        )
    }

    /** Jours du lundi au vendredi dans [from, to[ (jours fériés non déduits). */
    fun businessDaysBetween(from: LocalDate, to: LocalDate): Long {
        val total = ChronoUnit.DAYS.between(from, to)
        if (total <= 0) return 0
        val fullWeeks = total / 7
        var count = fullWeeks * 5
        var day = from.plusDays(fullWeeks * 7)
        while (day < to) {
            if (day.dayOfWeek != DayOfWeek.SATURDAY && day.dayOfWeek != DayOfWeek.SUNDAY) count++
            day = day.plusDays(1)
        }
        return count
    }

    // ------------------------------------------------------------ Âge

    fun age(birth: LocalDate, today: LocalDate): Outcome<AgeResult> = outcomeOf {
        if (birth > today) fail("La date de naissance est dans le futur.")
        if (ChronoUnit.YEARS.between(birth, today) > 150) fail("Date de naissance trop ancienne (plus de 150 ans).")
        val p = Period.between(birth, today)
        // withYear() ramène un 29 février au 28 février les années non bissextiles.
        val thisYear = birth.withYear(today.year)
        val next = if (thisYear > today) thisYear else birth.withYear(today.year + 1)
        AgeResult(
            years = p.years,
            months = p.months,
            days = p.days,
            totalDays = ChronoUnit.DAYS.between(birth, today),
            totalMonths = ChronoUnit.MONTHS.between(birth, today),
            bornOn = birth.dayOfWeek.getDisplayName(TextStyle.FULL, FR),
            nextBirthday = next,
            daysUntilNextBirthday = ChronoUnit.DAYS.between(today, next),
            nextAge = next.year - birth.year,
            isBirthdayToday = thisYear == today,
        )
    }

    // ------------------------------------------------------------ Compte à rebours

    fun countdown(target: LocalDateTime, zone: ZoneId, now: Instant): Outcome<CountdownResult> = outcomeOf {
        val targetInstant = try { ZonedDateTime.of(target, zone).toInstant() } catch (e: DateTimeException) { fail("Date invalide.") }
        val d = Duration.between(now, targetInstant)
        val past = d.isNegative
        val total = kotlin.math.abs(d.seconds)
        CountdownResult(past, total / 86_400, (total % 86_400) / 3600, (total % 3600) / 60, total % 60, total)
    }
}
