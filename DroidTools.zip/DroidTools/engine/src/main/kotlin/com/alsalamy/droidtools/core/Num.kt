package com.alsalamy.droidtools.core

import java.math.BigDecimal
import java.math.MathContext
import java.math.RoundingMode

/**
 * Lecture et affichage des nombres saisis par l'utilisateur (format français par défaut).
 *
 * Lecture : accepte « 1234,5 », « 1 234,5 », « 1234.5 », « 1,234.5 », « 1.234,5 », « -3 », « 2E5 ».
 * Affichage : séparateur décimal « , », groupes de milliers séparés par une espace insécable.
 */
object Num {
    /** Contexte de calcul à 34 chiffres significatifs. */
    val MC: MathContext = MathContext.DECIMAL128

    /** Limite de taille pour refuser les nombres déraisonnables (protection mémoire/CPU). */
    const val MAX_INPUT_LENGTH = 80

    private val spaces = Regex("[\\s\\u00A0\\u202F\\u2009']")

    /** Retourne la valeur lue, ou null si le champ est vide. Lève [UserInputException] si invalide. */
    fun parseOrNull(input: String, field: String = "Valeur"): BigDecimal? {
        val trimmed = input.trim()
        if (trimmed.isEmpty()) return null
        if (trimmed.length > MAX_INPUT_LENGTH) fail("$field : nombre trop long.")
        var s = trimmed.replace(spaces, "").replace('−', '-')
        val lastComma = s.lastIndexOf(',')
        val lastDot = s.lastIndexOf('.')
        s = when {
            lastComma >= 0 && lastDot >= 0 -> {
                if (lastComma > lastDot) s.replace(".", "").replace(',', '.') else s.replace(",", "")
            }
            lastComma >= 0 -> {
                if (s.count { it == ',' } > 1) s.replace(",", "") else s.replace(',', '.')
            }
            lastDot >= 0 && s.count { it == '.' } > 1 -> s.replace(".", "")
            else -> s
        }
        if (!Regex("[+-]?(\\d+\\.?\\d*|\\.\\d+)([eE][+-]?\\d{1,4})?").matches(s)) {
            fail("$field : « $trimmed » n'est pas un nombre valide.")
        }
        val value = try {
            BigDecimal(s)
        } catch (e: NumberFormatException) {
            fail("$field : « $trimmed » n'est pas un nombre valide.")
        }
        if (value.abs() > BigDecimal("1E100")) fail("$field : nombre trop grand.")
        return value
    }

    fun parse(input: String, field: String = "Valeur"): BigDecimal =
        parseOrNull(input, field) ?: fail("$field : champ vide.")

    fun parseInt(input: String, field: String, range: IntRange): Int {
        val value = parse(input, field)
        val intValue = try {
            value.stripTrailingZeros().intValueExact()
        } catch (e: ArithmeticException) {
            fail("$field : un nombre entier est attendu.")
        }
        if (intValue !in range) fail("$field : doit être compris entre ${range.first} et ${range.last}.")
        return intValue
    }

    /** Affiche un nombre avec au plus [maxSignificant] chiffres significatifs. */
    fun format(value: BigDecimal, maxSignificant: Int = 12, maxFractionDigits: Int? = null): String {
        var v = value
        if (maxFractionDigits != null) v = v.setScale(maxFractionDigits, RoundingMode.HALF_UP)
        v = v.round(MathContext(maxSignificant, RoundingMode.HALF_EVEN))
        if (v.signum() == 0) return "0"
        v = v.stripTrailingZeros()
        val abs = v.abs()
        if (abs >= BigDecimal("1E15") || abs < BigDecimal("1E-6")) return scientific(v)
        return groupPlain(v.toPlainString())
    }

    /** Affiche un montant avec exactement [decimals] décimales (arrondi commercial). */
    fun formatFixed(value: BigDecimal, decimals: Int = 2): String =
        groupPlain(value.setScale(decimals, RoundingMode.HALF_UP).toPlainString())

    fun formatDouble(value: Double, maxSignificant: Int = 12): String = when {
        value.isNaN() -> "Indéfini"
        value == Double.POSITIVE_INFINITY -> "∞"
        value == Double.NEGATIVE_INFINITY -> "-∞"
        else -> format(BigDecimal(value), maxSignificant)
    }

    /** Représentation sans groupement, réinjectable dans une expression (notation E si besoin). */
    fun plain(value: Double, maxSignificant: Int = 15): String {
        if (value.isNaN() || value.isInfinite()) return ""
        var v = BigDecimal(value).round(MathContext(maxSignificant, RoundingMode.HALF_EVEN))
        if (v.signum() == 0) return "0"
        v = v.stripTrailingZeros()
        val abs = v.abs()
        return if (abs >= BigDecimal("1E15") || abs < BigDecimal("1E-6")) {
            v.toString().replace("E+", "E")
        } else {
            v.toPlainString()
        }
    }

    private fun scientific(v: BigDecimal): String {
        val exponent = v.precision() - v.scale() - 1
        val mantissa = v.movePointLeft(exponent).stripTrailingZeros()
        return groupPlain(mantissa.toPlainString()) + " × 10" + superscript(exponent)
    }

    private fun groupPlain(plain: String): String {
        val negative = plain.startsWith("-")
        val body = if (negative) plain.substring(1) else plain
        val dot = body.indexOf('.')
        val intPart = if (dot >= 0) body.substring(0, dot) else body
        val fracPart = if (dot >= 0) body.substring(dot + 1) else ""
        val grouped = StringBuilder()
        intPart.forEachIndexed { index, c ->
            if (index > 0 && (intPart.length - index) % 3 == 0) grouped.append(' ')
            grouped.append(c)
        }
        val sign = if (negative) "-" else ""
        return if (fracPart.isEmpty()) sign + grouped else "$sign$grouped,$fracPart"
    }

    private val superDigits = charArrayOf('⁰', '¹', '²', '³', '⁴', '⁵', '⁶', '⁷', '⁸', '⁹')

    fun superscript(n: Int): String {
        val s = n.toString()
        return buildString {
            for (c in s) append(if (c == '-') '⁻' else superDigits[c - '0'])
        }
    }
}
