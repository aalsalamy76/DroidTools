package com.alsalamy.droidtools.tools.xml

import com.alsalamy.droidtools.core.Outcome
import com.alsalamy.droidtools.core.fail
import com.alsalamy.droidtools.core.outcomeOf

/**
 * Formateur XML sans dépendance : découpe le texte en jetons, vérifie la bonne formation
 * (balises appariées, attributs, racine unique) puis réindente.
 *
 * Sécurité : aucune entité n'est développée et aucun DTD externe n'est chargé
 * (immunité contre XXE et « billion laughs »).
 */
object XmlFormatter {
    const val MAX_INPUT_CHARS = 5_000_000
    private const val MAX_DEPTH = 1000

    private sealed interface Tok {
        val start: Int
        data class Decl(val raw: String, override val start: Int) : Tok          // <?…?>, <!DOCTYPE…>
        data class Comment(val raw: String, override val start: Int) : Tok
        data class CData(val raw: String, override val start: Int) : Tok
        data class Open(val name: String, val raw: String, override val start: Int) : Tok
        data class Empty(val name: String, val raw: String, override val start: Int) : Tok
        data class Close(val name: String, val raw: String, override val start: Int) : Tok
        data class Text(val raw: String, override val start: Int) : Tok
    }

    private val nameRegex = Regex("[\\p{L}_:][\\p{L}\\p{N}_:.\\-]*")
    private val attrRegex = Regex("\\s+([\\p{L}_:][\\p{L}\\p{N}_:.\\-]*)\\s*=\\s*(\"[^\"<]*\"|'[^'<]*')")

    fun format(xml: String, indent: String = "  "): Outcome<String> = outcomeOf { render(tokenize(xml), indent) }

    fun minify(xml: String): Outcome<String> = outcomeOf { render(tokenize(xml), null) }

    private fun lineCol(text: String, index: Int): String {
        var line = 1
        var col = 1
        for (i in 0 until minOf(index, text.length)) {
            if (text[i] == '\n') { line++; col = 1 } else col++
        }
        return "ligne $line, colonne $col"
    }

    private fun tokenize(xml: String): List<Tok> {
        if (xml.length > MAX_INPUT_CHARS) fail("Texte trop volumineux.")
        if (xml.isBlank()) fail("Saisissez un document XML.")
        val tokens = ArrayList<Tok>()
        val stack = ArrayDeque<Pair<String, Int>>()
        var rootCount = 0
        var i = 0
        while (i < xml.length) {
            if (xml[i] != '<') {
                val end = xml.indexOf('<', i).let { if (it < 0) xml.length else it }
                val raw = xml.substring(i, end)
                if (raw.isNotBlank() && stack.isEmpty()) fail("Texte en dehors de l'élément racine (${lineCol(xml, i)}).")
                tokens += Tok.Text(raw, i)
                i = end
                continue
            }
            when {
                xml.startsWith("<!--", i) -> {
                    val end = xml.indexOf("-->", i + 4)
                    if (end < 0) fail("Commentaire non fermé (${lineCol(xml, i)}).")
                    tokens += Tok.Comment(xml.substring(i, end + 3), i)
                    i = end + 3
                }
                xml.startsWith("<![CDATA[", i) -> {
                    if (stack.isEmpty()) fail("Section CDATA en dehors de l'élément racine (${lineCol(xml, i)}).")
                    val end = xml.indexOf("]]>", i + 9)
                    if (end < 0) fail("Section CDATA non fermée (${lineCol(xml, i)}).")
                    tokens += Tok.CData(xml.substring(i, end + 3), i)
                    i = end + 3
                }
                xml.startsWith("<?", i) -> {
                    val end = xml.indexOf("?>", i + 2)
                    if (end < 0) fail("Instruction de traitement non fermée (${lineCol(xml, i)}).")
                    tokens += Tok.Decl(xml.substring(i, end + 2), i)
                    i = end + 2
                }
                xml.startsWith("<!", i) -> {
                    // <!DOCTYPE …> avec éventuel sous-ensemble interne […] : conservé tel quel, jamais interprété.
                    var j = i + 2
                    var bracket = 0
                    while (j < xml.length) {
                        val c = xml[j]
                        if (c == '[') bracket++ else if (c == ']') bracket-- else if (c == '>' && bracket <= 0) break
                        j++
                    }
                    if (j >= xml.length) fail("Déclaration non fermée (${lineCol(xml, i)}).")
                    tokens += Tok.Decl(xml.substring(i, j + 1), i)
                    i = j + 1
                }
                else -> {
                    val end = findTagEnd(xml, i)
                    val raw = xml.substring(i, end + 1)
                    if (raw.startsWith("</")) {
                        val name = raw.substring(2, raw.length - 1).trim()
                        if (!nameRegex.matches(name)) fail("Balise fermante invalide « $raw » (${lineCol(xml, i)}).")
                        val open = stack.removeLastOrNull()
                            ?: fail("Balise fermante « $raw » sans balise ouvrante (${lineCol(xml, i)}).")
                        if (open.first != name) fail("Balise « </$name> » trouvée, « </${open.first}> » attendue (${lineCol(xml, i)}).")
                        tokens += Tok.Close(name, raw, i)
                    } else {
                        val selfClosing = raw.endsWith("/>")
                        val inner = raw.substring(1, raw.length - if (selfClosing) 2 else 1)
                        val name = nameRegex.find(inner)?.takeIf { it.range.first == 0 }?.value
                            ?: fail("Nom de balise invalide « $raw » (${lineCol(xml, i)}).")
                        validateAttributes(inner.substring(name.length), raw, xml, i)
                        if (stack.isEmpty()) {
                            rootCount++
                            if (rootCount > 1) fail("Plusieurs éléments racines : un document XML n'en a qu'un (${lineCol(xml, i)}).")
                        }
                        if (selfClosing) tokens += Tok.Empty(name, raw, i)
                        else {
                            if (stack.size >= MAX_DEPTH) fail("Imbrication trop profonde.")
                            stack.addLast(name to i)
                            tokens += Tok.Open(name, raw, i)
                        }
                    }
                    i = end + 1
                }
            }
        }
        stack.lastOrNull()?.let { (name, at) -> fail("Balise « <$name> » jamais fermée (${lineCol(xml, at)}).") }
        if (rootCount == 0) fail("Aucun élément racine trouvé.")
        return tokens
    }

    private fun findTagEnd(xml: String, start: Int): Int {
        var quote: Char? = null
        var j = start + 1
        while (j < xml.length) {
            val c = xml[j]
            if (quote != null) {
                if (c == quote) quote = null
            } else when (c) {
                '"', '\'' -> quote = c
                '<' -> fail("« < » inattendu dans une balise (${lineCol(xml, j)}).")
                '>' -> return j
            }
            j++
        }
        fail("Balise non fermée : « > » manquant (${lineCol(xml, start)}).")
    }

    private fun validateAttributes(attrs: String, raw: String, xml: String, at: Int) {
        if (attrs.isBlank()) return
        var rest = attrs
        val seen = HashSet<String>()
        while (rest.isNotBlank()) {
            val m = attrRegex.find(rest)
            if (m == null || m.range.first != 0) fail("Attribut mal formé dans « ${raw.take(80)} » (${lineCol(xml, at)}).")
            val attrName = m.groupValues[1]
            if (!seen.add(attrName)) fail("Attribut « $attrName » répété (${lineCol(xml, at)}).")
            rest = rest.substring(m.range.last + 1)
        }
    }

    private fun render(tokens: List<Tok>, indent: String?): String {
        val sb = StringBuilder()
        var level = 0
        var i = 0
        fun line(content: String) {
            if (indent != null) {
                if (sb.isNotEmpty()) sb.append('\n')
                repeat(level) { sb.append(indent) }
            }
            sb.append(content)
        }
        while (i < tokens.size) {
            when (val t = tokens[i]) {
                is Tok.Text -> {
                    val trimmed = t.raw.trim()
                    if (trimmed.isNotEmpty()) line(if (indent != null) trimmed else t.raw.trim())
                }
                is Tok.Open -> {
                    // <a>texte</a> reste sur une seule ligne.
                    val next = tokens.getOrNull(i + 1)
                    val after = tokens.getOrNull(i + 2)
                    if (next is Tok.Text && after is Tok.Close && after.name == t.name) {
                        line(t.raw + next.raw.trim() + after.raw)
                        i += 3
                        continue
                    }
                    if (next is Tok.Close && next.name == t.name) {
                        line(t.raw + next.raw)
                        i += 2
                        continue
                    }
                    line(t.raw)
                    level++
                }
                is Tok.Close -> { level--; line(t.raw) }
                is Tok.Empty -> line(t.raw)
                is Tok.Comment -> line(t.raw)
                is Tok.CData -> line(t.raw)
                is Tok.Decl -> line(t.raw)
            }
            i++
        }
        return sb.toString()
    }
}
