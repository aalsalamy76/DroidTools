package com.alsalamy.droidtools.domain

import com.alsalamy.droidtools.domain.SensitiveResource.CAMERA
import com.alsalamy.droidtools.domain.SensitiveResource.FILES
import com.alsalamy.droidtools.domain.SensitiveResource.LOCATION
import com.alsalamy.droidtools.domain.SensitiveResource.MICROPHONE
import com.alsalamy.droidtools.domain.SensitiveResource.NETWORK
import com.alsalamy.droidtools.domain.ToolCategory.AUDIO
import com.alsalamy.droidtools.domain.ToolCategory.CALCULATIONS
import com.alsalamy.droidtools.domain.ToolCategory.CONVERSIONS
import com.alsalamy.droidtools.domain.ToolCategory.DAILY
import com.alsalamy.droidtools.domain.ToolCategory.DEVICE_TESTS
import com.alsalamy.droidtools.domain.ToolCategory.DOCUMENTS
import com.alsalamy.droidtools.domain.ToolCategory.IMAGES
import com.alsalamy.droidtools.domain.ToolCategory.QR
import com.alsalamy.droidtools.domain.ToolCategory.SECURITY
import com.alsalamy.droidtools.domain.ToolCategory.SENSORS
import com.alsalamy.droidtools.domain.ToolCategory.TEXT_DEV
import com.alsalamy.droidtools.domain.ToolStatus.FUNCTIONAL
import com.alsalamy.droidtools.domain.ToolStatus.NOT_IMPLEMENTED
import com.alsalamy.droidtools.domain.ToolStatus.PARTIAL

/**
 * Catalogue de tous les outils DroidTools (cahier des charges : 145 entrées, doublons fusionnés).
 *
 * Règles :
 * - un outil FONCTIONNEL ou PARTIEL possède une fiche de confidentialité exacte ;
 * - un outil NON IMPLÉMENTÉ n'en possède pas (on n'affirme rien sur un code inexistant) ;
 * - chaque numéro 1..145 du cahier des charges est couvert une seule fois (vérifié par les tests).
 */
object ToolCatalog {

    private const val NO_STORAGE =
        "Aucune : les données saisies restent en mémoire et disparaissent quand vous quittez l'outil."
    private const val DEST_LOCAL =
        "Aucune transmission : cet outil n'effectue aucune connexion réseau. Aucune donnée n'est envoyée à DroidTools."
    private const val NO_DEPENDENCY = "Aucune bibliothèque externe : API standard Java/Kotlin uniquement."
    private const val NO_RESOURCE = "Aucune ressource sensible (caméra, micro, localisation, fichiers, réseau)."
    private const val CLIPBOARD_NOTE =
        "Le bouton « Copier » place le résultat dans le presse-papiers Android, uniquement sur votre action."
    private const val SENSITIVE_NOTE =
        "Les valeurs générées ne sont ni enregistrées, ni journalisées, ni ajoutées à l'historique. " +
            "La copie est signalée comme sensible à Android (13 et plus) pour masquer l'aperçu du presse-papiers. " +
            "L'écran bloque les captures d'écran et masque son contenu dans la liste des applications récentes."
    private const val SECURE_RANDOM_NOTE =
        "Aléa produit par SecureRandom, le générateur cryptographiquement sûr d'Android."

    private fun local(
        data: String,
        storage: String = NO_STORAGE,
        notes: List<String> = listOf(CLIPBOARD_NOTE),
        resources: Set<SensitiveResource> = emptySet(),
        usage: String = NO_RESOURCE,
        dependencies: String = NO_DEPENDENCY,
    ) = PrivacySheet(
        processing = Processing.LOCAL,
        resources = resources,
        permissions = emptyList(),
        resourceUsage = usage,
        dataHandled = data,
        storage = storage,
        destination = DEST_LOCAL,
        externalDependencies = dependencies,
        notes = notes,
    )

    private fun tool(
        id: String,
        name: String,
        description: String,
        category: ToolCategory,
        icon: ToolIcon,
        keywords: List<String>,
        spec: List<Int>,
        privacy: PrivacySheet,
        status: ToolStatus = FUNCTIONAL,
        limitations: List<String> = emptyList(),
    ) = ToolDefinition(id, name, description, category, icon, keywords, status, privacy, emptySet(), limitations, spec)

    private fun planned(
        id: String,
        name: String,
        description: String,
        category: ToolCategory,
        icon: ToolIcon,
        keywords: List<String>,
        spec: List<Int>,
        resources: Set<SensitiveResource> = emptySet(),
    ) = ToolDefinition(id, name, description, category, icon, keywords, NOT_IMPLEMENTED, null, resources, emptyList(), spec)

    private val numbers = local("Nombres que vous saisissez.")
    private val text = local("Texte que vous saisissez ou collez.")

    /**
     * Toutes les entrées du cahier des charges, y compris les outils NON IMPLÉMENTÉS.
     * Ces derniers forment la feuille de route : ils ne sont jamais proposés dans l'application.
     */
    val entries: List<ToolDefinition> = listOf(
        // ---------------------------------------------------------------- CALCULS
        tool("calculator", "Calculatrice", "Opérations courantes avec priorités et pourcentages", CALCULATIONS, ToolIcon.CALCULATE,
            listOf("calculatrice", "calcul", "addition", "multiplication", "calculator"), listOf(1), numbers),
        tool("scientific_calculator", "Calculatrice scientifique", "Trigonométrie, logarithmes, puissances, factorielles", CALCULATIONS, ToolIcon.FUNCTIONS,
            listOf("scientifique", "sinus", "cosinus", "log", "racine", "puissance", "scientific"), listOf(2), numbers),
        tool("percentages", "Pourcentages", "X % de Y, part en %, évolution, hausse ou baisse", CALCULATIONS, ToolIcon.PERCENT,
            listOf("pourcentage", "percent", "evolution", "hausse", "baisse", "%"), listOf(3), numbers),
        tool("vat", "TVA HT / TTC", "Conversion hors taxes / toutes taxes et montant de TVA", CALCULATIONS, ToolIcon.RECEIPT,
            listOf("tva", "ht", "ttc", "taxe", "vat", "facture"), listOf(4), numbers),
        tool("discount", "Remises", "Prix après remise, économie, remises successives", CALCULATIONS, ToolIcon.OFFER,
            listOf("remise", "solde", "reduction", "promo", "discount", "prix"), listOf(5), numbers),
        tool("rule_of_three", "Règle de trois", "Proportionnalité : A → B, C → ?", CALCULATIONS, ToolIcon.BALANCE,
            listOf("regle de trois", "proportion", "produit en croix", "proportionnalite"), listOf(6), numbers),
        tool("bill_split", "Partage d'addition", "Répartition au centime près, pourboire inclus", CALCULATIONS, ToolIcon.GROUP,
            listOf("addition", "partage", "restaurant", "pourboire", "diviser", "split"), listOf(7), numbers),
        tool("average", "Moyenne et statistiques", "Moyenne, moyenne pondérée, médiane, écart type", CALCULATIONS, ToolIcon.CHART,
            listOf("moyenne", "mediane", "ecart type", "statistique", "notes", "average"), listOf(8), numbers),
        tool("ratio", "Ratios", "Simplifier un ratio, résoudre a:b = c:x", CALCULATIONS, ToolIcon.COMPARE,
            listOf("ratio", "rapport", "proportion", "simplifier", "format"), listOf(9), numbers),

        // ---------------------------------------------------------------- CONVERSIONS
        tool("convert_length", "Longueur", "mm, cm, m, km, pouces, pieds, miles…", CONVERSIONS, ToolIcon.RULER,
            listOf("longueur", "distance", "metre", "pouce", "pied", "mile", "length"), listOf(10), numbers),
        tool("convert_area", "Surface", "m², hectares, ares, acres, pieds carrés…", CONVERSIONS, ToolIcon.AREA,
            listOf("surface", "aire", "m2", "hectare", "acre", "area"), listOf(11), numbers),
        tool("convert_volume", "Volume", "Litres, m³, gallons, tasses, cuillères…", CONVERSIONS, ToolIcon.VOLUME,
            listOf("volume", "litre", "gallon", "m3", "cuillere", "tasse"), listOf(12), numbers),
        tool("convert_mass", "Masse", "g, kg, tonnes, livres, onces, carats…", CONVERSIONS, ToolIcon.MASS,
            listOf("masse", "poids", "kilo", "livre", "once", "mass", "weight"), listOf(13), numbers),
        tool("convert_temperature", "Température", "Celsius, Fahrenheit, Kelvin, Rankine", CONVERSIONS, ToolIcon.TEMPERATURE,
            listOf("temperature", "celsius", "fahrenheit", "kelvin", "degre"), listOf(14), numbers),
        tool("convert_speed", "Vitesse", "km/h, m/s, mph, nœuds…", CONVERSIONS, ToolIcon.SPEED,
            listOf("vitesse", "kmh", "mph", "noeud", "speed"), listOf(15), numbers),
        tool("convert_pressure", "Pression", "Pa, hPa, bar, atm, psi, mmHg…", CONVERSIONS, ToolIcon.PRESSURE,
            listOf("pression", "bar", "psi", "pascal", "atm", "pressure"), listOf(16), numbers),
        tool("convert_energy", "Énergie", "J, kJ, cal, kcal, Wh, kWh, eV, BTU…", CONVERSIONS, ToolIcon.ENERGY,
            listOf("energie", "joule", "calorie", "kwh", "energy"), listOf(17), numbers),
        tool("convert_power", "Puissance", "W, kW, chevaux, BTU/h…", CONVERSIONS, ToolIcon.POWER,
            listOf("puissance", "watt", "cheval", "ch", "hp", "power"), listOf(18), numbers),
        tool("convert_time", "Temps", "Secondes, minutes, heures, jours, années…", CONVERSIONS, ToolIcon.TIME,
            listOf("temps", "duree", "seconde", "heure", "jour", "time"), listOf(19), numbers),
        tool("convert_angle", "Angles", "Degrés, radians, grades, minutes d'arc…", CONVERSIONS, ToolIcon.ANGLE,
            listOf("angle", "degre", "radian", "grade"), listOf(20), numbers),
        tool("convert_storage", "Stockage numérique", "Octets, Ko, Mo, Go, Kio, Mio, bits…", CONVERSIONS, ToolIcon.STORAGE,
            listOf("stockage", "octet", "go", "mo", "byte", "bit", "storage"), listOf(21), numbers),
        tool("number_base", "Binaire / décimal / hexadécimal", "Conversion entre bases 2, 8, 10 et 16", CONVERSIONS, ToolIcon.NUMBERS,
            listOf("binaire", "hexadecimal", "hex", "decimal", "octal", "base", "binary"), listOf(22), numbers),

        // ---------------------------------------------------------------- RÉSEAU / IT
        planned("wifi_info", "Informations Wi-Fi", "SSID, fréquence, débit du Wi-Fi connecté", ToolCategory.NETWORK, ToolIcon.WIFI,
            listOf("wifi", "ssid", "reseau sans fil"), listOf(23), setOf(LOCATION, NETWORK)),
        planned("signal_strength", "Force du signal", "Niveau du signal Wi-Fi en dBm", ToolCategory.NETWORK, ToolIcon.SIGNAL,
            listOf("wifi", "signal", "dbm", "rssi"), listOf(24), setOf(LOCATION, NETWORK)),
        planned("local_ip", "Adresse IP locale", "Adresses IPv4/IPv6 de l'appareil", ToolCategory.NETWORK, ToolIcon.DEVICES,
            listOf("ip", "adresse ip", "locale", "ipv6"), listOf(25), setOf(NETWORK)),
        planned("network_info", "Informations réseau", "Type de connexion, passerelle, MTU", ToolCategory.NETWORK, ToolIcon.ROUTER,
            listOf("reseau", "passerelle", "gateway", "connexion"), listOf(26), setOf(NETWORK)),
        planned("dns_lookup", "DNS Lookup", "Résolution d'un nom de domaine", ToolCategory.NETWORK, ToolIcon.DNS,
            listOf("dns", "domaine", "resolution", "nslookup"), listOf(27), setOf(NETWORK)),
        planned("ping", "Ping", "Test de joignabilité d'un hôte", ToolCategory.NETWORK, ToolIcon.NETWORK_CHECK,
            listOf("ping", "latence", "joignable", "icmp"), listOf(28), setOf(NETWORK)),
        tool("ipv4_calculator", "Calculateur IPv4", "Réseau, broadcast, plage d'hôtes, masque, type d'adresse", ToolCategory.NETWORK, ToolIcon.LAN,
            listOf("ip", "ipv4", "masque", "subnet", "broadcast", "passerelle"), listOf(29),
            local("Adresses IP et masques que vous saisissez.", notes = listOf(CLIPBOARD_NOTE, "Calcul hors ligne : aucune requête réseau n'est émise."))),
        tool("cidr_calculator", "Calculateur CIDR", "Plage d'un bloc CIDR et plage → blocs CIDR", ToolCategory.NETWORK, ToolIcon.HUB,
            listOf("cidr", "ip", "plage", "range", "prefixe"), listOf(30),
            local("Blocs CIDR et plages d'adresses que vous saisissez.", notes = listOf(CLIPBOARD_NOTE, "Calcul hors ligne : aucune requête réseau n'est émise."))),
        tool("ipv4_to_binary", "IPv4 vers binaire", "Adresse IPv4 en binaire, hexadécimal et entier", ToolCategory.NETWORK, ToolIcon.NUMBERS,
            listOf("ip", "ipv4", "binaire", "binary"), listOf(31), local("Adresses IP que vous saisissez.")),
        tool("binary_to_ipv4", "Binaire vers IPv4", "32 bits (avec ou sans points) vers adresse IPv4", ToolCategory.NETWORK, ToolIcon.NUMBERS,
            listOf("ip", "ipv4", "binaire", "binary"), listOf(32), local("Valeurs binaires que vous saisissez.")),
        tool("subnet_analysis", "Analyse de sous-réseau", "Découpage en sous-réseaux, appartenance d'une adresse", ToolCategory.NETWORK, ToolIcon.LAN,
            listOf("sous reseau", "subnet", "decoupage", "vlsm", "ip"), listOf(33),
            local("Réseaux et adresses que vous saisissez.", notes = listOf(CLIPBOARD_NOTE, "Calcul hors ligne : aucune requête réseau n'est émise."))),
        planned("lan_scanner", "Scanner réseau local", "Appareils présents sur votre réseau local (autorisé)", ToolCategory.NETWORK, ToolIcon.DEVICES,
            listOf("scanner", "lan", "appareils", "reseau local"), listOf(34), setOf(NETWORK)),
        planned("port_scanner", "Scanner de ports", "Ports ouverts d'un hôte que vous administrez", ToolCategory.NETWORK, ToolIcon.NETWORK_CHECK,
            listOf("port", "scanner", "tcp"), listOf(35), setOf(NETWORK)),
        planned("dns_info", "Informations DNS", "Serveurs DNS utilisés par l'appareil", ToolCategory.NETWORK, ToolIcon.DNS,
            listOf("dns", "serveur dns", "resolveur"), listOf(36), setOf(NETWORK)),
        planned("http_headers", "En-têtes HTTP", "En-têtes de réponse d'une URL", ToolCategory.NETWORK, ToolIcon.HTTP,
            listOf("http", "headers", "en tetes", "url"), listOf(37), setOf(NETWORK)),
        planned("tls_certificate", "Certificat SSL/TLS", "Chaîne de certificats d'un site", ToolCategory.NETWORK, ToolIcon.LOCK,
            listOf("ssl", "tls", "certificat", "https"), listOf(38), setOf(NETWORK)),
        tool("user_agent_parser", "Analyse de User-Agent", "Navigateur, moteur, système et type d'appareil", ToolCategory.NETWORK, ToolIcon.DEVICES,
            listOf("user agent", "ua", "navigateur", "browser"), listOf(39), text,
            status = PARTIAL,
            limitations = listOf(
                "Analyse heuristique : un User-Agent peut être falsifié.",
                "Les navigateurs récents figent la version du système et le modèle d'appareil (« UA reduction ») : ces informations peuvent être approximatives.",
            )),

        // ---------------------------------------------------------------- QR
        planned("qr_scanner", "Scanner QR", "Lecture de QR codes avec la caméra", QR, ToolIcon.QR_SCAN,
            listOf("qr", "scanner", "lire", "scan"), listOf(40), setOf(CAMERA)),
        planned("qr_generator", "Générateur QR", "Création de QR codes : texte, URL, Wi-Fi, contact", QR, ToolIcon.QR_CODE,
            listOf("qr", "generer", "creer", "url", "wifi", "contact", "vcard"), listOf(41, 44, 45, 46, 47)),
        planned("barcode_scanner", "Scanner code-barres", "Lecture EAN, UPC, Code 128…", QR, ToolIcon.BARCODE,
            listOf("code barre", "barcode", "ean", "scanner"), listOf(42), setOf(CAMERA)),
        planned("barcode_generator", "Générateur code-barres", "Création de codes EAN-13, Code 128…", QR, ToolIcon.BARCODE,
            listOf("code barre", "barcode", "generer", "ean"), listOf(43)),
        planned("scan_history", "Historique des scans", "Historique local et facultatif des codes lus", QR, ToolIcon.HISTORY,
            listOf("historique", "qr", "scan"), listOf(48)),

        // ---------------------------------------------------------------- PDF & DOCUMENTS
        planned("document_scanner", "Scanner document", "Numérisation de documents avec la caméra", DOCUMENTS, ToolIcon.DOCUMENT_SCAN,
            listOf("scanner", "document", "numeriser", "pdf"), listOf(49), setOf(CAMERA, FILES)),
        planned("images_to_pdf", "Images vers PDF", "Assembler des images en un PDF", DOCUMENTS, ToolIcon.PDF,
            listOf("pdf", "image", "convertir", "photo"), listOf(50, 69), setOf(FILES)),
        planned("pdf_merge", "Fusion PDF", "Combiner plusieurs PDF", DOCUMENTS, ToolIcon.MERGE,
            listOf("pdf", "fusion", "fusionner", "merge"), listOf(51), setOf(FILES)),
        planned("pdf_split", "Division PDF", "Scinder un PDF en plusieurs fichiers", DOCUMENTS, ToolIcon.SPLIT,
            listOf("pdf", "diviser", "scinder", "split"), listOf(52), setOf(FILES)),
        planned("pdf_extract_pages", "Extraire des pages", "Créer un PDF avec une sélection de pages", DOCUMENTS, ToolIcon.CUT,
            listOf("pdf", "extraire", "pages"), listOf(53), setOf(FILES)),
        planned("pdf_reorder", "Réorganiser les pages", "Changer l'ordre des pages d'un PDF", DOCUMENTS, ToolIcon.REORDER,
            listOf("pdf", "ordre", "reorganiser", "pages"), listOf(54), setOf(FILES)),
        planned("pdf_rotate", "Rotation de pages", "Pivoter des pages d'un PDF", DOCUMENTS, ToolIcon.ROTATE,
            listOf("pdf", "rotation", "pivoter"), listOf(55), setOf(FILES)),
        planned("pdf_compress", "Compression PDF", "Réduire la taille d'un PDF", DOCUMENTS, ToolIcon.COMPRESS,
            listOf("pdf", "compresser", "taille", "compression"), listOf(56), setOf(FILES)),
        planned("pdf_text", "Extraction de texte PDF", "Récupérer le texte d'un PDF", DOCUMENTS, ToolIcon.TEXT_SNIPPET,
            listOf("pdf", "texte", "extraire", "ocr"), listOf(57), setOf(FILES)),

        // ---------------------------------------------------------------- IMAGES
        planned("image_resize", "Redimensionnement", "Changer la taille d'une image", IMAGES, ToolIcon.RESIZE,
            listOf("image", "redimensionner", "taille", "resize", "photo"), listOf(60), setOf(FILES)),
        planned("image_compress", "Compression d'image", "Réduire le poids d'une image", IMAGES, ToolIcon.COMPRESS,
            listOf("image", "compresser", "jpeg", "poids", "photo"), listOf(61), setOf(FILES)),
        planned("image_crop", "Recadrage", "Recadrer une image", IMAGES, ToolIcon.CROP,
            listOf("image", "recadrer", "crop", "photo"), listOf(62), setOf(FILES)),
        planned("image_rotate", "Rotation d'image", "Pivoter une image", IMAGES, ToolIcon.ROTATE,
            listOf("image", "rotation", "pivoter", "photo"), listOf(63), setOf(FILES)),
        planned("color_picker", "Détecteur de couleur", "Couleur d'un point d'une image", IMAGES, ToolIcon.COLORIZE,
            listOf("couleur", "pipette", "image", "color picker"), listOf(64), setOf(FILES)),
        tool("color_converter", "Couleurs RGB ↔ HEX", "HEX, RGB, HSL, HSV, CMJN et contraste WCAG", IMAGES, ToolIcon.PALETTE,
            listOf("couleur", "rgb", "hex", "hsl", "color", "contraste"), listOf(65, 66), local("Codes couleur que vous saisissez.")),
        planned("exif_inspector", "Inspecteur EXIF", "Métadonnées d'une photo (appareil, date, GPS…)", IMAGES, ToolIcon.INFO,
            listOf("exif", "metadonnees", "photo", "gps"), listOf(67), setOf(FILES)),
        planned("exif_remover", "Suppression des métadonnées EXIF", "Créer une copie sans métadonnées", IMAGES, ToolIcon.HIDE_IMAGE,
            listOf("exif", "metadonnees", "supprimer", "confidentialite", "photo"), listOf(68), setOf(FILES)),
        planned("magnifier", "Loupe", "Agrandir avec la caméra", IMAGES, ToolIcon.ZOOM,
            listOf("loupe", "zoom", "agrandir"), listOf(70), setOf(CAMERA)),

        // ---------------------------------------------------------------- TEXTE & DÉVELOPPEMENT
        tool("text_counter", "Compteur de texte", "Mots, caractères, lignes, paragraphes, octets", TEXT_DEV, ToolIcon.TEXT_FIELDS,
            listOf("compteur", "mots", "caracteres", "lignes", "word count", "longueur"), listOf(58, 59, 71, 72, 73), text),
        tool("text_uppercase", "Majuscules", "Convertir un texte en MAJUSCULES", TEXT_DEV, ToolIcon.CASE,
            listOf("majuscule", "uppercase", "casse"), listOf(74), text),
        tool("text_lowercase", "Minuscules", "Convertir un texte en minuscules", TEXT_DEV, ToolIcon.CASE,
            listOf("minuscule", "lowercase", "casse"), listOf(75), text),
        tool("text_capitalize", "Capitalisation", "Majuscule à chaque mot ou à chaque phrase", TEXT_DEV, ToolIcon.CASE,
            listOf("capitaliser", "capitalisation", "titre", "casse"), listOf(76), text),
        tool("text_clean_spaces", "Nettoyage des espaces", "Espaces multiples, tabulations, lignes vides", TEXT_DEV, ToolIcon.CLEAN,
            listOf("espaces", "nettoyer", "trim", "blancs"), listOf(77), text),
        tool("text_dedupe_lines", "Suppression des doublons", "Supprimer les lignes en double", TEXT_DEV, ToolIcon.FILTER,
            listOf("doublons", "lignes", "unique", "dedupe"), listOf(78), text),
        tool("text_sort_lines", "Trier les lignes", "Ordre alphabétique (français), inverse, numérique", TEXT_DEV, ToolIcon.SORT,
            listOf("trier", "tri", "lignes", "alphabetique", "sort"), listOf(79), text),
        tool("text_reverse", "Inverser le texte", "Inverser les caractères ou l'ordre des lignes", TEXT_DEV, ToolIcon.REVERSE,
            listOf("inverser", "miroir", "reverse"), listOf(80), text),
        tool("find_replace", "Rechercher / remplacer", "Texte simple ou expression régulière", TEXT_DEV, ToolIcon.FIND_REPLACE,
            listOf("rechercher", "remplacer", "replace", "regex"), listOf(81), text),
        tool("base64_encode", "Base64 : encoder", "Texte UTF-8 vers Base64 (standard ou URL)", TEXT_DEV, ToolIcon.CODE,
            listOf("base64", "encoder", "encode"), listOf(82), text),
        tool("base64_decode", "Base64 : décoder", "Base64 vers texte, ou hexadécimal si binaire", TEXT_DEV, ToolIcon.CODE,
            listOf("base64", "decoder", "decode"), listOf(83), text),
        tool("url_encode", "URL : encoder", "Encodage pourcent (RFC 3986 ou formulaire)", TEXT_DEV, ToolIcon.LINK,
            listOf("url", "encoder", "encode", "pourcent", "percent"), listOf(84), text),
        tool("url_decode", "URL : décoder", "Décodage pourcent", TEXT_DEV, ToolIcon.LINK,
            listOf("url", "decoder", "decode", "pourcent"), listOf(85), text),
        tool("json_formatter", "JSON : formater", "Indentation lisible, tri des clés facultatif", TEXT_DEV, ToolIcon.DATA_OBJECT,
            listOf("json", "formater", "pretty", "indenter", "beautify"), listOf(86), text),
        tool("json_validator", "JSON : valider", "Vérification stricte (RFC 8259) avec ligne et colonne", TEXT_DEV, ToolIcon.DATA_OBJECT,
            listOf("json", "valider", "validator", "erreur"), listOf(87), text),
        tool("json_minifier", "JSON : minifier", "Supprimer les espaces inutiles", TEXT_DEV, ToolIcon.DATA_OBJECT,
            listOf("json", "minifier", "compact", "minify"), listOf(88), text),
        tool("xml_formatter", "XML : formater", "Indentation et vérification de la structure", TEXT_DEV, ToolIcon.CODE,
            listOf("xml", "formater", "indenter", "html"), listOf(89), text,
            status = PARTIAL,
            limitations = listOf(
                "Vérifie la structure (balises, imbrication, attributs) mais pas un schéma XSD/DTD.",
                "Les entités ne sont jamais développées (protection contre XXE) : elles sont conservées telles quelles.",
                "Dans un contenu mixte (texte + balises), les espaces peuvent être normalisés.",
            )),
        tool("regex_tester", "Testeur d'expressions régulières", "Correspondances, groupes, remplacement", TEXT_DEV, ToolIcon.REGEX,
            listOf("regex", "expression reguliere", "regexp", "pattern"), listOf(90),
            local("Expression et texte que vous saisissez.", notes = listOf(CLIPBOARD_NOTE, "Le résultat est abandonné après 2 secondes si l'expression provoque trop de retours arrière. " +
                    "Sous Android, le moteur regex natif ne peut pas être interrompu : un calcul abandonné continue en arrière-plan jusqu'à sa fin, " +
                    "et DroidTools refuse les nouvelles évaluations tant que 2 calculs abandonnés sont encore actifs."))),
        tool("string_escape", "Échappement de chaînes", "JSON, Java/Kotlin, HTML, XML : échapper / déséchapper", TEXT_DEV, ToolIcon.CODE,
            listOf("echappement", "escape", "unescape", "html", "json", "chaine"), listOf(91), text),
        tool("unicode_inspector", "Inspecteur Unicode", "Points de code, noms, caractères invisibles", TEXT_DEV, ToolIcon.UNICODE,
            listOf("unicode", "utf8", "caractere", "emoji", "invisible", "code point"), listOf(92), text),
        tool("unix_timestamp", "Timestamp Unix actuel", "Heure actuelle en secondes et millisecondes", TEXT_DEV, ToolIcon.CLOCK,
            listOf("timestamp", "unix", "epoch", "heure"), listOf(93),
            local("Heure de l'appareil et fuseau horaire.", notes = listOf(CLIPBOARD_NOTE))),
        tool("timestamp_to_date", "Timestamp → date", "Secondes, ms, µs ou ns vers date lisible", TEXT_DEV, ToolIcon.CLOCK,
            listOf("timestamp", "date", "epoch", "convertir"), listOf(94), numbers),
        tool("date_to_timestamp", "Date → timestamp", "Date et heure vers timestamp Unix", TEXT_DEV, ToolIcon.CLOCK,
            listOf("timestamp", "date", "epoch", "convertir"), listOf(95), local("Dates que vous saisissez.")),
        tool("uuid_generator", "Générateur UUID", "UUID v4 (aléatoire) et v7 (horodaté)", TEXT_DEV, ToolIcon.FINGERPRINT,
            listOf("uuid", "guid", "identifiant", "generer"), listOf(96, 102),
            local("Identifiants générés localement.", notes = listOf(CLIPBOARD_NOTE, SECURE_RANDOM_NOTE))),
        tool("ulid_generator", "Générateur ULID", "Identifiants triables (spécification ULID)", TEXT_DEV, ToolIcon.FINGERPRINT,
            listOf("ulid", "identifiant", "generer"), listOf(97),
            local("Identifiants générés localement.", notes = listOf(CLIPBOARD_NOTE, SECURE_RANDOM_NOTE))),

        // ---------------------------------------------------------------- SÉCURITÉ
        tool("password_generator", "Générateur de mots de passe", "Mots de passe aléatoires robustes", SECURITY, ToolIcon.PASSWORD,
            listOf("mot de passe", "password", "generer", "aleatoire", "random", "securite"), listOf(98),
            local("Mots de passe générés localement.", notes = listOf(SENSITIVE_NOTE, SECURE_RANDOM_NOTE))),
        tool("passphrase_generator", "Générateur de phrases de passe", "Suite de mots aléatoires faciles à retenir", SECURITY, ToolIcon.KEY,
            listOf("passphrase", "phrase de passe", "mot de passe", "diceware", "password"), listOf(99),
            local("Phrases de passe générées localement à partir d'une liste de mots intégrée.", notes = listOf(SENSITIVE_NOTE, SECURE_RANDOM_NOTE))),
        tool("pin_generator", "Générateur de code PIN", "PIN aléatoire, codes triviaux exclus", SECURITY, ToolIcon.PIN,
            listOf("pin", "code", "chiffres", "generer"), listOf(100),
            local("Codes PIN générés localement.", notes = listOf(SENSITIVE_NOTE, SECURE_RANDOM_NOTE))),
        tool("password_strength", "Analyse de robustesse", "Estimation locale de la solidité d'un mot de passe", SECURITY, ToolIcon.SHIELD,
            listOf("robustesse", "mot de passe", "password", "force", "strength", "securite"), listOf(101),
            local("Mot de passe que vous saisissez, analysé en mémoire uniquement.",
                notes = listOf(
                    "Le mot de passe saisi n'est jamais enregistré, copié, journalisé ni transmis.",
                    "Le champ est masqué par défaut et déclaré comme champ de mot de passe, que les claviers ne doivent pas mémoriser.",
                    "L'écran bloque les captures d'écran et masque son contenu dans la liste des applications récentes.",
                    "Estimation indicative fondée sur des règles locales : elle ne garantit pas la sécurité.",
                ))),
        tool("random_token", "Générateur aléatoire", "Jetons aléatoires (hex, Base64 URL) de 8 à 256 octets", SECURITY, ToolIcon.DICE,
            listOf("aleatoire", "token", "jeton", "random", "cle", "secret"), listOf(103),
            local("Jetons générés localement.", notes = listOf(SENSITIVE_NOTE, SECURE_RANDOM_NOTE))),
        tool("hash_sha256", "SHA-256", "Empreinte SHA-256 d'un texte", SECURITY, ToolIcon.HASH,
            listOf("sha256", "sha", "hash", "empreinte", "checksum"), listOf(104), text),
        tool("hash_sha512", "SHA-512", "Empreinte SHA-512 d'un texte", SECURITY, ToolIcon.HASH,
            listOf("sha512", "sha", "hash", "empreinte"), listOf(105), text),
        tool("hash_md5", "MD5 (compatibilité)", "Somme MD5 pour vérifier une intégrité non sécuritaire", SECURITY, ToolIcon.HASH,
            listOf("md5", "hash", "checksum", "empreinte"), listOf(106),
            local("Texte que vous saisissez.", notes = listOf(CLIPBOARD_NOTE, "MD5 est cassé : ne l'utilisez jamais pour protéger des mots de passe ni dans un nouveau système de sécurité."))),
        tool("hash_compare", "Comparaison de hash", "Comparer deux empreintes (comparaison à temps constant)", SECURITY, ToolIcon.COMPARE,
            listOf("comparer", "hash", "empreinte", "verifier", "checksum"), listOf(107), local("Empreintes que vous saisissez.")),
        tool("file_hash", "Hash de fichier", "SHA-256, SHA-512, SHA-1 ou MD5 d'un fichier choisi", SECURITY, ToolIcon.FILE,
            listOf("fichier", "hash", "checksum", "sha256", "verifier", "telechargement"), listOf(108),
            PrivacySheet(
                processing = Processing.LOCAL,
                resources = setOf(FILES),
                permissions = emptyList(),
                resourceUsage = "Accès en lecture au seul fichier que vous choisissez dans le sélecteur système Android, " +
                    "le temps du calcul. Aucune permission de stockage n'est demandée.",
                dataHandled = "Contenu du fichier choisi, lu en flux (par blocs de 64 Ko) sans le charger entièrement en mémoire.",
                storage = "Aucune : ni le fichier ni son empreinte ne sont enregistrés. Le fichier original n'est jamais modifié.",
                destination = DEST_LOCAL,
                externalDependencies = NO_DEPENDENCY,
                notes = listOf(CLIPBOARD_NOTE, "Le calcul peut être annulé à tout moment."),
            )),
        planned("vault", "Coffre-fort local chiffré", "Notes secrètes chiffrées (AES-GCM, Android Keystore)", SECURITY, ToolIcon.VAULT,
            listOf("coffre", "vault", "chiffre", "secret", "mot de passe"), listOf(109)),

        // ---------------------------------------------------------------- CAPTEURS
        planned("level", "Niveau", "Niveau à bulle", SENSORS, ToolIcon.LEVEL, listOf("niveau", "bulle", "inclinaison"), listOf(110)),
        planned("plumb", "Fil à plomb", "Verticalité", SENSORS, ToolIcon.LEVEL, listOf("fil a plomb", "vertical", "aplomb"), listOf(111)),
        planned("compass", "Boussole", "Orientation par rapport au nord magnétique", SENSORS, ToolIcon.COMPASS, listOf("boussole", "nord", "compass", "cap"), listOf(112)),
        planned("accelerometer", "Accéléromètre", "Accélération sur 3 axes", SENSORS, ToolIcon.SENSORS, listOf("accelerometre", "acceleration", "capteur"), listOf(113)),
        planned("gyroscope", "Gyroscope", "Vitesse de rotation sur 3 axes", SENSORS, ToolIcon.SENSORS, listOf("gyroscope", "rotation", "capteur"), listOf(114)),
        planned("magnetometer", "Magnétomètre", "Champ magnétique sur 3 axes", SENSORS, ToolIcon.SENSORS, listOf("magnetometre", "magnetique", "capteur"), listOf(115)),
        planned("magnetic_detector", "Détecteur de champ magnétique", "Intensité du champ magnétique", SENSORS, ToolIcon.SENSORS, listOf("metal", "magnetique", "detecteur"), listOf(116)),
        planned("lux_meter", "Luxmètre", "Luminosité ambiante en lux", SENSORS, ToolIcon.LIGHT, listOf("lux", "lumiere", "luminosite"), listOf(117)),
        planned("barometer", "Baromètre", "Pression atmosphérique (si capteur présent)", SENSORS, ToolIcon.BAROMETER, listOf("barometre", "pression", "altitude"), listOf(118)),
        planned("vibrometer", "Vibromètre", "Intensité des vibrations", SENSORS, ToolIcon.VIBRATION, listOf("vibration", "vibrometre", "seisme"), listOf(119)),
        planned("decibel_meter", "Décibelmètre", "Niveau sonore approximatif", SENSORS, ToolIcon.MIC, listOf("decibel", "bruit", "son", "db"), listOf(120), setOf(MICROPHONE)),
        planned("gps_speed", "Compteur de vitesse GPS", "Vitesse calculée par GPS", SENSORS, ToolIcon.SPEED, listOf("gps", "vitesse", "compteur"), listOf(121), setOf(LOCATION)),
        planned("gps_coordinates", "Coordonnées GPS", "Latitude, longitude, altitude, précision", SENSORS, ToolIcon.GPS, listOf("gps", "coordonnees", "latitude", "position"), listOf(122), setOf(LOCATION)),
        planned("sensor_list", "Liste des capteurs", "Capteurs présents sur l'appareil", SENSORS, ToolIcon.SENSORS, listOf("capteurs", "liste", "sensor"), listOf(123)),
        planned("device_info", "Informations appareil", "Modèle, version d'Android, écran", SENSORS, ToolIcon.PHONE, listOf("appareil", "modele", "android", "device"), listOf(124)),
        planned("battery_info", "Informations batterie", "Niveau, température, santé, charge", SENSORS, ToolIcon.BATTERY, listOf("batterie", "battery", "charge"), listOf(125)),

        // ---------------------------------------------------------------- TESTS APPAREIL
        planned("screen_test", "Test écran", "Couleurs plein écran", DEVICE_TESTS, ToolIcon.SCREEN, listOf("ecran", "test", "couleurs"), listOf(126)),
        planned("pixel_test", "Test pixels", "Détection de pixels morts", DEVICE_TESTS, ToolIcon.SCREEN, listOf("pixel", "pixels morts", "ecran"), listOf(127)),
        planned("touch_test", "Test tactile", "Zones tactiles de l'écran", DEVICE_TESTS, ToolIcon.TOUCH, listOf("tactile", "touch", "ecran"), listOf(128)),
        planned("vibration_test", "Test vibration", "Moteur de vibration", DEVICE_TESTS, ToolIcon.VIBRATION, listOf("vibration", "vibreur", "test"), listOf(129)),
        planned("speaker_test", "Test haut-parleur", "Lecture d'une tonalité de test", DEVICE_TESTS, ToolIcon.SPEAKER, listOf("haut parleur", "son", "test"), listOf(130)),
        planned("microphone_test", "Test microphone", "Enregistrement et relecture courts", DEVICE_TESTS, ToolIcon.MIC, listOf("micro", "microphone", "test"), listOf(131), setOf(MICROPHONE)),

        // ---------------------------------------------------------------- AUDIO
        planned("voice_recorder", "Enregistreur vocal", "Enregistrement audio local", AUDIO, ToolIcon.RECORD, listOf("enregistreur", "dictaphone", "voix", "audio"), listOf(132), setOf(MICROPHONE, FILES)),
        planned("speech_to_text", "Reconnaissance vocale", "Dictée (si un service est disponible)", AUDIO, ToolIcon.SPEECH, listOf("dictee", "speech", "voix", "texte"), listOf(133), setOf(MICROPHONE)),
        planned("text_to_speech", "Synthèse vocale", "Lecture à voix haute d'un texte", AUDIO, ToolIcon.TTS, listOf("synthese vocale", "tts", "lire", "voix"), listOf(134)),
        planned("tone_generator", "Générateur de tonalités", "Fréquence et forme d'onde réglables", AUDIO, ToolIcon.TONE, listOf("tonalite", "frequence", "son", "hz"), listOf(135)),
        planned("audio_player", "Lecteur audio", "Lecture de fichiers audio locaux", AUDIO, ToolIcon.PLAY, listOf("lecteur", "audio", "mp3", "musique"), listOf(136), setOf(FILES)),

        // ---------------------------------------------------------------- QUOTIDIEN
        tool("stopwatch", "Chronomètre", "Chronomètre avec tours", DAILY, ToolIcon.STOPWATCH,
            listOf("chronometre", "chrono", "tour", "stopwatch"), listOf(137),
            local("Temps mesurés.", notes = listOf(
                CLIPBOARD_NOTE,
                "Basé sur l'horloge monotone d'Android : insensible aux changements d'heure.",
                "La mesure continue quand l'application passe en arrière-plan ; elle est perdue si vous fermez l'outil ou si Android arrête l'application.",
            ))),
        tool("timer", "Minuteur", "Compte à rebours d'une durée", DAILY, ToolIcon.TIMER,
            listOf("minuteur", "timer", "cuisine", "alarme"), listOf(138),
            local("Durée choisie.", notes = listOf("Aucune notification ni alarme système : l'alerte (bip sonore généré localement) n'a lieu que si l'outil est ouvert.")),
            status = PARTIAL,
            limitations = listOf(
                "En arrière-plan, le décompte continue mais l'alerte n'est émise qu'à votre retour dans l'outil (aucune notification).",
                "Le minuteur est perdu si vous fermez l'outil ou si Android arrête l'application.",
                "À l'échéance, l'outil affiche « Temps écoulé » et émet un bip sonore.",
                "L'écran reste allumé pendant le décompte pour que le minuteur continue.",
            )),
        tool("countdown", "Compte à rebours", "Temps restant jusqu'à une date", DAILY, ToolIcon.HOURGLASS,
            listOf("compte a rebours", "countdown", "date", "evenement"), listOf(139), local("Date cible que vous saisissez.")),
        tool("date_difference", "Différence entre deux dates", "Jours, semaines, mois, jours ouvrés", DAILY, ToolIcon.EVENT,
            listOf("date", "difference", "jours", "duree", "entre"), listOf(140), local("Dates que vous saisissez.")),
        tool("age_calculator", "Calcul d'âge", "Âge exact et prochain anniversaire", DAILY, ToolIcon.CAKE,
            listOf("age", "anniversaire", "naissance"), listOf(141), local("Date de naissance que vous saisissez (jamais enregistrée).")),
        tool("random_numbers", "Nombres aléatoires", "Tirage dans un intervalle, avec ou sans répétition", DAILY, ToolIcon.SHUFFLE,
            listOf("aleatoire", "tirage", "nombre", "hasard", "loterie", "random"), listOf(142),
            local("Bornes que vous saisissez.", notes = listOf(CLIPBOARD_NOTE, SECURE_RANDOM_NOTE))),
        tool("dice", "Dé", "Lancer de 1 à 20 dés (4 à 100 faces)", DAILY, ToolIcon.DICE,
            listOf("de", "des", "dice", "jeu", "hasard"), listOf(143), local("Résultats des lancers.", notes = listOf(SECURE_RANDOM_NOTE))),
        tool("coin_flip", "Pile ou face", "Tirage équitable", DAILY, ToolIcon.COIN,
            listOf("pile", "face", "piece", "coin", "hasard"), listOf(144), local("Résultats des tirages.", notes = listOf(SECURE_RANDOM_NOTE))),
        tool("checklist", "Checklist", "Liste de tâches enregistrée sur l'appareil", DAILY, ToolIcon.CHECKLIST,
            listOf("checklist", "liste", "taches", "todo", "courses"), listOf(145),
            local("Éléments de liste que vous saisissez.",
                storage = "Enregistrés localement dans l'espace privé de l'application (non chiffré), jusqu'à ce que vous les supprimiez. " +
                    "Exclus des sauvegardes Android.",
                notes = listOf("Ne stockez pas d'informations secrètes dans une checklist : elle n'est pas chiffrée."),
                dependencies = "Jetpack DataStore (bibliothèque Google, stockage local uniquement).")),
    )

    /** Outils proposés dans l'application : uniquement ceux qui fonctionnent (FONCTIONNEL ou PARTIEL). */
    val all: List<ToolDefinition> = entries.filter { it.isAvailable }

    /** Outils prévus mais non implémentés : documentés dans TOOL_STATUS.md, absents de l'application. */
    val roadmap: List<ToolDefinition> = entries.filterNot { it.isAvailable }

    /** Catégories contenant au moins un outil disponible, dans l'ordre d'affichage. */
    val categories: List<ToolCategory> = ToolCategory.entries.filter { c -> all.any { it.category == c } }

    private val byId: Map<String, ToolDefinition> = all.associateBy { it.id }

    /** Recherche un outil disponible ; un outil non implémenté n'est jamais renvoyé. */
    fun find(id: String): ToolDefinition? = byId[id]

    fun byCategory(category: ToolCategory): List<ToolDefinition> = all.filter { it.category == category }
}
