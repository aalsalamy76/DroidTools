package com.alsalamy.droidtools.tools.text

import com.alsalamy.droidtools.core.Outcome
import com.alsalamy.droidtools.core.fail
import com.alsalamy.droidtools.core.outcomeOf

enum class EscapeFormat(val label: String) {
    JSON("JSON"),
    JAVA_KOTLIN("Java / Kotlin"),
    HTML("HTML"),
    XML("XML"),
}

/** Échappement et déséchappement de chaînes pour différents langages. */
object StringEscaper {

    fun escape(text: String, format: EscapeFormat): String = when (format) {
        EscapeFormat.JSON -> escapeCLike(text, escapeSlashDollar = false)
        EscapeFormat.JAVA_KOTLIN -> escapeCLike(text, escapeSlashDollar = true)
        EscapeFormat.HTML -> escapeMarkup(text, apos = "&#39;")
        EscapeFormat.XML -> escapeMarkup(text, apos = "&apos;")
    }

    fun unescape(text: String, format: EscapeFormat): Outcome<String> = outcomeOf {
        when (format) {
            EscapeFormat.JSON, EscapeFormat.JAVA_KOTLIN -> unescapeCLike(text, format)
            EscapeFormat.HTML, EscapeFormat.XML -> unescapeMarkup(text)
        }
    }

    private fun escapeCLike(text: String, escapeSlashDollar: Boolean): String {
        val sb = StringBuilder(text.length + 16)
        for (c in text) {
            when (c) {
                '"' -> sb.append("\\\"")
                '\\' -> sb.append("\\\\")
                '\n' -> sb.append("\\n")
                '\r' -> sb.append("\\r")
                '\t' -> sb.append("\\t")
                '\b' -> sb.append("\\b")
                '\u000C' -> sb.append(if (escapeSlashDollar) "\\u000C" else "\\f")
                '$' -> sb.append(if (escapeSlashDollar) "\\$" else "$")
                else -> if (c < ' ' || c == ' ' || c == ' ') {
                    sb.append(String.format(java.util.Locale.ROOT, "\\u%04X", c.code))
                } else sb.append(c)
            }
        }
        return sb.toString()
    }

    private fun unescapeCLike(text: String, format: EscapeFormat): String {
        val sb = StringBuilder(text.length)
        var i = 0
        while (i < text.length) {
            val c = text[i]
            if (c != '\\') { sb.append(c); i++; continue }
            if (i + 1 >= text.length) fail("Barre oblique inverse isolée en fin de texte.")
            when (val e = text[i + 1]) {
                '"' -> sb.append('"')
                '\'' -> sb.append('\'')
                '\\' -> sb.append('\\')
                '/' -> sb.append('/')
                'n' -> sb.append('\n')
                'r' -> sb.append('\r')
                't' -> sb.append('\t')
                'b' -> sb.append('\b')
                'f' -> sb.append('\u000C')
                '$' -> if (format == EscapeFormat.JAVA_KOTLIN) sb.append('$') else fail("Séquence « \\$ » invalide en JSON (position ${i + 1}).")
                'u' -> {
                    if (i + 6 > text.length) fail("Séquence \\u incomplète (position ${i + 1}).")
                    val hex = text.substring(i + 2, i + 6)
                    val code = hex.toIntOrNull(16) ?: fail("Séquence « \\u$hex » invalide (position ${i + 1}).")
                    sb.append(code.toChar())
                    i += 6
                    continue
                }
                else -> fail("Séquence d'échappement « \\$e » inconnue (position ${i + 1}).")
            }
            i += 2
        }
        return sb.toString()
    }

    private fun escapeMarkup(text: String, apos: String): String {
        val sb = StringBuilder(text.length + 16)
        for (c in text) {
            when (c) {
                '&' -> sb.append("&amp;")
                '<' -> sb.append("&lt;")
                '>' -> sb.append("&gt;")
                '"' -> sb.append("&quot;")
                '\'' -> sb.append(apos)
                else -> sb.append(c)
            }
        }
        return sb.toString()
    }

    private val named = mapOf(
        "amp" to "&", "lt" to "<", "gt" to ">", "quot" to "\"", "apos" to "'", "nbsp" to " ",
        "eacute" to "é", "egrave" to "è", "ecirc" to "ê", "agrave" to "à", "ccedil" to "ç", "ugrave" to "ù",
        "ocirc" to "ô", "icirc" to "î", "euro" to "€", "copy" to "©", "reg" to "®", "hellip" to "…",
        "laquo" to "«", "raquo" to "»", "mdash" to "—", "ndash" to "–",
    )

    private fun unescapeMarkup(text: String): String {
        val sb = StringBuilder(text.length)
        var i = 0
        while (i < text.length) {
            val c = text[i]
            if (c != '&') { sb.append(c); i++; continue }
            val end = text.indexOf(';', i)
            if (end < 0 || end - i > 12) { sb.append(c); i++; continue }
            val entity = text.substring(i + 1, end)
            val decoded: String? = when {
                entity.startsWith("#x") || entity.startsWith("#X") -> entity.substring(2).toIntOrNull(16)?.let(::codePointToString)
                entity.startsWith("#") -> entity.substring(1).toIntOrNull()?.let(::codePointToString)
                else -> named[entity]
            }
            if (decoded == null) { sb.append(c); i++; continue }
            sb.append(decoded)
            i = end + 1
        }
        return sb.toString()
    }

    private fun codePointToString(cp: Int): String? =
        if (Character.isValidCodePoint(cp)) String(Character.toChars(cp)) else null
}
