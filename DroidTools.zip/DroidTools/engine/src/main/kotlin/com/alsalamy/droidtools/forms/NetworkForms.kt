package com.alsalamy.droidtools.forms

import com.alsalamy.droidtools.tools.color.ColorConverter
import com.alsalamy.droidtools.tools.net.Ipv4
import com.alsalamy.droidtools.tools.net.Ipv4Calculator
import com.alsalamy.droidtools.tools.net.SubnetInfo
import com.alsalamy.droidtools.tools.net.UserAgentParser
import java.util.Locale

internal object NetworkForms {

    private const val OFFLINE = "Calcul hors ligne : aucune requête réseau n'est émise."

    private fun range(info: SubnetInfo) = "${info.firstHost} → ${info.lastHost}"

    private fun subnetRows(info: SubnetInfo): List<ResultItem> = listOf(
        ResultRow("Réseau", "${info.network}/${info.prefix}", monospace = true, emphasis = true),
        ResultRow("Masque", "${info.mask}  (/${info.prefix})", monospace = true),
        ResultRow("Masque inverse (wildcard)", info.wildcard.toString(), monospace = true),
        ResultRow("Adresse de diffusion", info.broadcast.toString(), monospace = true),
        ResultRow("Plage utilisable", range(info), monospace = true),
        ResultRow("Hôtes utilisables", count(info.usableHosts)),
        ResultRow("Adresses au total", count(info.totalAddresses)),
        ResultRow("Classe (historique)", info.addressClass, copyable = false),
        ResultRow("Type d'adresse", info.addressType, copyable = false),
    )

    val ipv4Calculator: ToolForm = ToolForm(
        fields = listOf(
            TextInput("address", "Adresse IPv4 ou bloc CIDR", InputKind.CODE, placeholder = "192.168.1.10/24"),
            TextInput("mask", "Masque (si absent de l'adresse)", InputKind.CODE, placeholder = "24 ou 255.255.255.0"),
        ),
        intro = OFFLINE,
    ) { v, _ ->
        val address = v.requiredText("address")
        if (!address.contains('/') && v.isBlank("mask")) awaiting("Indiquez le masque ou le préfixe (ex. /24).")
        val info = Ipv4Calculator.calculate(address, v["mask"]).orFail()
        val items = mutableListOf<ResultItem>(ResultRow("Adresse", info.address.toString(), monospace = true))
        items += subnetRows(info)
        if (info.prefix == 31) items += ResultNotice("/31 : liaison point à point (RFC 3021), les deux adresses sont utilisables.")
        FormResult(items)
    }

    val cidrCalculator: ToolForm = ToolForm(
        fields = listOf(
            ChoiceInput("mode", "Conversion", listOf(Choice("block", "Bloc CIDR → plage"), Choice("range", "Plage → blocs CIDR"))),
            TextInput("cidr", "Bloc CIDR", InputKind.CODE, placeholder = "10.0.0.0/22", visibleWhen = visibleIf("mode", "block")),
            TextInput("start", "Première adresse", InputKind.CODE, placeholder = "10.0.0.0", visibleWhen = visibleIf("mode", "range")),
            TextInput("end", "Dernière adresse", InputKind.CODE, placeholder = "10.0.2.255", visibleWhen = visibleIf("mode", "range")),
        ),
        intro = OFFLINE,
    ) { v, _ ->
        if (v["mode"] == "range") {
            val start = Ipv4.parse(v.requiredText("start"), "Première adresse")
            val end = Ipv4.parse(v.requiredText("end"), "Dernière adresse")
            val blocks = Ipv4Calculator.rangeToCidrs(start, end).orFail()
            val total = end.value - start.value + 1
            FormResult(
                listOf<ResultItem>(ResultHeader("${plural(blocks.size, "bloc")} pour ${plural(total, "adresse")}")) +
                    blocks.mapIndexed { i, (ip, prefix) -> ResultRow("Bloc ${i + 1}", "$ip/$prefix", monospace = true) } +
                    ResultText("Tous les blocs", blocks.joinToString("\n") { (ip, prefix) -> "$ip/$prefix" }, monospace = true),
            )
        } else {
            val (ip, prefix) = Ipv4Calculator.parseCidr(v.requiredText("cidr"))
            val info = Ipv4Calculator.calculate(ip, prefix)
            val items = mutableListOf<ResultItem>(
                ResultRow("Plage complète", "${info.network} → ${info.broadcast}", monospace = true, emphasis = true),
            )
            if (info.network != ip) items += ResultNotice("${ip} n'est pas l'adresse de réseau : le bloc commence à ${info.network}.", NoticeLevel.WARNING)
            items += subnetRows(info).drop(1)
            FormResult(items)
        }
    }

    val ipv4ToBinary: ToolForm = ToolForm(
        fields = listOf(TextInput("ip", "Adresse IPv4", InputKind.CODE, placeholder = "192.168.1.10")),
    ) { v, _ ->
        val ip = Ipv4.parse(v.requiredText("ip"))
        FormResult(
            ResultRow("Binaire", ip.toBinary(dotted = true), monospace = true, emphasis = true),
            ResultRow("Binaire (32 bits)", ip.toBinary(dotted = false), monospace = true),
            ResultRow("Hexadécimal", ip.toHex(), monospace = true),
            ResultRow("Entier non signé", ip.value.toString(), monospace = true),
        )
    }

    val binaryToIpv4: ToolForm = ToolForm(
        fields = listOf(
            TextInput("bits", "Adresse en binaire", InputKind.CODE, placeholder = "11000000.10101000.00000001.00001010",
                supportingText = "32 bits, avec ou sans points"),
        ),
    ) { v, _ ->
        val ip = Ipv4.fromBinary(v.requiredText("bits"))
        FormResult(
            ResultRow("Adresse IPv4", ip.toString(), monospace = true, emphasis = true),
            ResultRow("Hexadécimal", ip.toHex(), monospace = true),
            ResultRow("Entier non signé", ip.value.toString(), monospace = true),
            ResultRow("Type d'adresse", Ipv4Calculator.addressType(ip), copyable = false),
        )
    }

    val subnetAnalysis: ToolForm = ToolForm(
        fields = listOf(
            ChoiceInput(
                "mode", "Analyse",
                listOf(Choice("split", "Découper un réseau"), Choice("contains", "Appartenance"), Choice("hosts", "Taille pour N hôtes")),
            ),
            TextInput("network", "Réseau (CIDR)", InputKind.CODE, placeholder = "192.168.0.0/24", visibleWhen = visibleIf("mode", "split", "contains")),
            ChoiceInput("by", "Découper selon", listOf(Choice("count", "Nombre de sous-réseaux"), Choice("prefix", "Nouveau préfixe")),
                visibleWhen = visibleIf("mode", "split")),
            TextInput("count", "Nombre de sous-réseaux", InputKind.INTEGER, placeholder = "4",
                visibleWhen = { it["mode"] == "split" && it["by"] == "count" }),
            TextInput("newPrefix", "Nouveau préfixe", InputKind.INTEGER, placeholder = "26",
                visibleWhen = { it["mode"] == "split" && it["by"] == "prefix" }),
            TextInput("address", "Adresse à tester", InputKind.CODE, placeholder = "192.168.0.77", visibleWhen = visibleIf("mode", "contains")),
            TextInput("hosts", "Nombre d'hôtes nécessaires", InputKind.INTEGER, placeholder = "50", visibleWhen = visibleIf("mode", "hosts")),
        ),
        intro = OFFLINE,
    ) { v, _ ->
        when (v["mode"]) {
            "contains" -> {
                val network = v.requiredText("network")
                val address = v.requiredText("address")
                val inside = Ipv4Calculator.contains(network, address).orFail()
                val (net, prefix) = Ipv4Calculator.parseCidr(network)
                val info = Ipv4Calculator.calculate(net, prefix)
                FormResult(
                    ResultNotice(
                        if (inside) "${address.trim()} appartient à ${info.network}/${info.prefix}."
                        else "${address.trim()} n'appartient pas à ${info.network}/${info.prefix}.",
                        if (inside) NoticeLevel.SUCCESS else NoticeLevel.WARNING,
                    ),
                    ResultRow("Plage du réseau", "${info.network} → ${info.broadcast}", monospace = true),
                )
            }
            "hosts" -> {
                val hosts = v.longInteger("hosts", "Nombre d'hôtes")
                val prefix = Ipv4Calculator.prefixForHosts(hosts).orFail()
                val info = Ipv4Calculator.calculate(Ipv4(0), prefix)
                FormResult(
                    ResultRow("Préfixe minimal", "/$prefix", emphasis = true),
                    ResultRow("Masque", info.mask.toString(), monospace = true),
                    ResultRow("Hôtes utilisables", count(info.usableHosts)),
                    ResultRow("Adresses au total", count(info.totalAddresses)),
                )
            }
            else -> {
                val (net, prefix) = Ipv4Calculator.parseCidr(v.requiredText("network"))
                val newPrefix = if (v["by"] == "prefix") {
                    v.integer("newPrefix", "Nouveau préfixe", 0..32)
                } else {
                    Ipv4Calculator.prefixForSubnetCount(prefix, v.integer("count", "Nombre de sous-réseaux", 1..1_000_000)).orFail()
                }
                val split = Ipv4Calculator.split(net, prefix, newPrefix).orFail()
                val first = split.subnets.first()
                val items = mutableListOf<ResultItem>(
                    ResultHeader("${plural(split.totalSubnets, "sous-réseau")} /${split.prefix} — ${plural(first.usableHosts, "hôte")} utilisables chacun"),
                )
                split.subnets.forEachIndexed { i, s ->
                    items += ResultRow("Sous-réseau ${i + 1}", "${s.network}/${s.prefix}  ·  ${range(s)}", monospace = true)
                }
                if (split.truncated) items += ResultNotice("Seuls les ${split.subnets.size} premiers sous-réseaux sont listés.")
                FormResult(items)
            }
        }
    }

    val userAgent: ToolForm = ToolForm(
        fields = listOf(
            TextInput("ua", "User-Agent", InputKind.CODE_BLOCK, placeholder = "Mozilla/5.0 (Linux; Android 14; …)"),
        ),
        intro = "Analyse locale et heuristique : un User-Agent peut être falsifié et les navigateurs récents en réduisent le contenu.",
    ) { v, _ ->
        val r = UserAgentParser.parse(v.requiredText("ua")) ?: awaiting()
        val items = mutableListOf<ResultItem>(
            ResultRow("Navigateur", listOfNotNull(r.browser, r.browserVersion).joinToString(" "), emphasis = true),
            ResultRow("Moteur de rendu", r.engine),
            ResultRow("Système", listOfNotNull(r.os, r.osVersion).joinToString(" ")),
            ResultRow("Type d'appareil", r.deviceType),
        )
        r.deviceModel?.let { items += ResultRow("Modèle", it) }
        items += ResultRow("Robot ou automatisation", yesNo(r.isBot), copyable = false)
        if (r.isBot) items += ResultNotice("Ce User-Agent se présente comme un robot ou un outil automatisé.", NoticeLevel.WARNING)
        r.notes.forEach { items += ResultNotice(it) }
        FormResult(items)
    }

    val color: ToolForm = ToolForm(
        fields = listOf(
            TextInput("color", "Couleur", InputKind.CODE, placeholder = "#1E88E5 ou 30, 136, 229",
                supportingText = "HEX (#RGB, #RRGGBB, #RRGGBBAA) ou RGB (r, g, b[, opacité])"),
        ),
    ) { v, _ ->
        val r = ColorConverter.parse(v.requiredText("color")).orFail()
        fun wcag(ratio: Double): String {
            val value = String.format(Locale.FRENCH, "%.2f", ratio) + ":1"
            val level = when {
                ratio >= 7 -> "AAA ✓"
                ratio >= 4.5 -> "AA ✓"
                ratio >= 3 -> "AA grand texte uniquement"
                else -> "insuffisant ✗"
            }
            return "$value — $level"
        }
        val items = mutableListOf<ResultItem>(
            ResultRow("Aperçu", r.hex, monospace = true, emphasis = true, swatchArgb = r.color.argb),
            ResultRow("HEX", r.hex, monospace = true),
        )
        r.hexWithAlpha?.let { items += ResultRow("HEX avec opacité", it, monospace = true) }
        items += listOf(
            ResultRow("RGB", r.rgb, monospace = true),
            ResultRow("HSL", r.hsl, monospace = true),
            ResultRow("HSV", r.hsv, monospace = true),
            ResultRow("CMJN (indicatif, sans profil ICC)", r.cmyk, monospace = true),
            ResultHeader("Contraste (WCAG 2.x)"),
            ResultRow("Texte blanc sur cette couleur", wcag(r.contrastWithWhite), copyable = false),
            ResultRow("Texte noir sur cette couleur", wcag(r.contrastWithBlack), copyable = false),
        )
        if (r.color.alpha != 255) items += ResultNotice("Le contraste est calculé sans tenir compte de l'opacité.")
        FormResult(items)
    }
}
