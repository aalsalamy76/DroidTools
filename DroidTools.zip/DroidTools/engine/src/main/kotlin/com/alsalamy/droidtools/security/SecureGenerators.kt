package com.alsalamy.droidtools.security

import com.alsalamy.droidtools.core.Outcome
import com.alsalamy.droidtools.core.fail
import com.alsalamy.droidtools.core.outcomeOf
import com.alsalamy.droidtools.tools.codec.Hex
import java.security.SecureRandom
import java.util.Base64
import kotlin.math.ln

/**
 * Générateurs aléatoires. Tous exigent un [SecureRandom] : le type empêche
 * d'utiliser par erreur un java.util.Random prévisible.
 */
object SecureGenerators {

    const val LOWER = "abcdefghijklmnopqrstuvwxyz"
    const val UPPER = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
    const val DIGITS = "0123456789"
    const val SYMBOLS = "!#$%&()*+,-./:;<=>?@[]^_{|}~"
    /** Caractères facilement confondus à l'écrit ou à l'écran. */
    const val AMBIGUOUS = "Il1O0oS5Z2B8|"

    data class PasswordOptions(
        val length: Int = 20,
        val lowercase: Boolean = true,
        val uppercase: Boolean = true,
        val digits: Boolean = true,
        val symbols: Boolean = true,
        val excludeAmbiguous: Boolean = false,
    )

    data class Generated(val value: String, val entropyBits: Double)

    fun log2(x: Double): Double = ln(x) / ln(2.0)

    /** Entier uniforme dans [0, bound[ (SecureRandom.nextInt(bound) est sans biais). */
    private fun SecureRandom.below(bound: Int): Int = nextInt(bound)

    fun password(options: PasswordOptions, random: SecureRandom): Outcome<Generated> = outcomeOf {
        if (options.length !in 4..128) fail("La longueur doit être comprise entre 4 et 128.")
        fun filter(set: String) = if (options.excludeAmbiguous) set.filterNot { it in AMBIGUOUS } else set
        val classes = buildList {
            if (options.lowercase) add(filter(LOWER))
            if (options.uppercase) add(filter(UPPER))
            if (options.digits) add(filter(DIGITS))
            if (options.symbols) add(filter(SYMBOLS))
        }
        if (classes.isEmpty()) fail("Sélectionnez au moins un type de caractères.")
        val pool = classes.joinToString("")
        val chars = CharArray(options.length)
        // Au moins un caractère de chaque type choisi, puis complétion depuis l'ensemble, puis mélange.
        var index = 0
        for (set in classes) {
            if (index < chars.size) chars[index++] = set[random.below(set.length)]
        }
        while (index < chars.size) chars[index++] = pool[random.below(pool.length)]
        for (i in chars.size - 1 downTo 1) {
            val j = random.below(i + 1)
            val tmp = chars[i]; chars[i] = chars[j]; chars[j] = tmp
        }
        Generated(String(chars), options.length * log2(pool.length.toDouble()))
    }

    data class PinOptions(val length: Int = 6, val avoidTrivial: Boolean = true)

    fun pin(options: PinOptions, random: SecureRandom): Outcome<Generated> = outcomeOf {
        if (options.length !in 4..12) fail("La longueur doit être comprise entre 4 et 12 chiffres.")
        var attempts = 0
        var value: String
        do {
            value = buildString { repeat(options.length) { append(DIGITS[random.below(10)]) } }
            attempts++
        } while (options.avoidTrivial && isTrivialPin(value) && attempts < 1000)
        Generated(value, options.length * log2(10.0))
    }

    private val commonPins = setOf(
        "1234", "1111", "0000", "1212", "7777", "1004", "2000", "4444", "2222", "6969", "9999", "3333",
        "5555", "6666", "1122", "1313", "8888", "4321", "2001", "1010", "123456", "654321", "121212",
        "112233", "123123", "696969", "159753", "147258", "1478", "2580", "0852", "1590",
    )

    /** PIN trivial : très courant, un seul chiffre répété, suite croissante/décroissante, motif répété. */
    fun isTrivialPin(pin: String): Boolean {
        if (pin in commonPins) return true
        if (pin.all { it == pin[0] }) return true
        val steps = pin.zipWithNext { a, b -> (b - a + 10) % 10 }
        if (steps.all { it == 1 } || steps.all { it == 9 }) return true
        for (period in 1..pin.length / 2) {
            if (pin.length % period == 0 && pin == pin.substring(0, period).repeat(pin.length / period)) return true
        }
        return false
    }

    enum class TokenFormat(val label: String) { HEX("Hexadécimal"), BASE64URL("Base64 URL"), BASE64("Base64") }

    fun token(bytes: Int, format: TokenFormat, random: SecureRandom): Outcome<Generated> = outcomeOf {
        if (bytes !in 8..256) fail("La taille doit être comprise entre 8 et 256 octets.")
        val data = ByteArray(bytes).also(random::nextBytes)
        val value = when (format) {
            TokenFormat.HEX -> Hex.encode(data)
            TokenFormat.BASE64URL -> Base64.getUrlEncoder().withoutPadding().encodeToString(data)
            TokenFormat.BASE64 -> Base64.getEncoder().encodeToString(data)
        }
        data.fill(0)
        Generated(value, bytes * 8.0)
    }

    /** Entier uniforme dans [min, max] (bornes incluses), y compris pour de grands intervalles. */
    fun uniformLong(min: Long, max: Long, random: SecureRandom): Long {
        require(min <= max)
        val span = max - min + 1 // peut déborder si l'intervalle couvre tout Long
        if (span <= 0) {
            // Intervalle plus grand que Long.MAX_VALUE : tirage par rejet.
            while (true) {
                val v = random.nextLong()
                if (v in min..max) return v
            }
        }
        // Rejet pour éliminer le biais du modulo.
        val limit = Long.MAX_VALUE - (Long.MAX_VALUE % span)
        while (true) {
            val r = random.nextLong() ushr 1
            if (r < limit) return min + r % span
        }
    }

    data class RandomNumbersOptions(val min: Long, val max: Long, val count: Int, val unique: Boolean, val sorted: Boolean)

    fun randomNumbers(options: RandomNumbersOptions, random: SecureRandom): Outcome<List<Long>> = outcomeOf {
        if (options.min > options.max) fail("Le minimum doit être inférieur ou égal au maximum.")
        if (options.count !in 1..1000) fail("Le nombre de tirages doit être compris entre 1 et 1000.")
        val rangeSize = options.max.toBigInteger() - options.min.toBigInteger() + java.math.BigInteger.ONE
        if (options.unique && rangeSize < options.count.toBigInteger()) {
            fail("Impossible de tirer ${options.count} nombres distincts dans un intervalle de $rangeSize valeurs.")
        }
        val result = ArrayList<Long>(options.count)
        if (options.unique) {
            val seen = HashSet<Long>()
            while (result.size < options.count) {
                val v = uniformLong(options.min, options.max, random)
                if (seen.add(v)) result += v
            }
        } else {
            repeat(options.count) { result += uniformLong(options.min, options.max, random) }
        }
        if (options.sorted) result.sort()
        result
    }

    val diceFaces = listOf(4, 6, 8, 10, 12, 20, 100)

    fun rollDice(count: Int, faces: Int, random: SecureRandom): Outcome<List<Int>> = outcomeOf {
        if (count !in 1..20) fail("Entre 1 et 20 dés.")
        if (faces !in 2..1000) fail("Nombre de faces invalide.")
        List(count) { random.below(faces) + 1 }
    }

    /** true = pile, false = face. */
    fun flipCoin(random: SecureRandom): Boolean = random.nextBoolean()
}
