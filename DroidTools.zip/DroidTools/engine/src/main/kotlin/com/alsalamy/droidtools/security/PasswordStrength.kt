package com.alsalamy.droidtools.security

import com.alsalamy.droidtools.core.TextNormalizer
import kotlin.math.max
import kotlin.math.min

/**
 * Estimation LOCALE et INDICATIVE de la robustesse d'un mot de passe.
 *
 * Méthode : entropie théorique (longueur × log2(taille de l'alphabet utilisé)), puis pénalités
 * pour les motifs prévisibles (mots de passe courants, suites, répétitions, lignes de clavier,
 * dates, substitutions « l33t »). Le mot de passe n'est jamais stocké ni transmis.
 */
object PasswordStrength {

    enum class Level(val label: String, val score: Int) {
        VERY_WEAK("Très faible", 0),
        WEAK("Faible", 1),
        FAIR("Moyen", 2),
        STRONG("Fort", 3),
        VERY_STRONG("Très fort", 4),
    }

    data class Report(
        val level: Level,
        val effectiveBits: Double,
        val theoreticalBits: Double,
        val length: Int,
        val charsetSize: Int,
        val warnings: List<String>,
        val suggestions: List<String>,
    )

    /** Mots de passe parmi les plus répandus (listes publiques de fuites), incluant des variantes françaises. */
    private val common = setOf(
        "123456", "123456789", "12345678", "12345", "1234567", "1234567890", "111111", "000000", "123123",
        "password", "motdepasse", "azerty", "azertyuiop", "qwerty", "qwertyuiop", "abc123", "iloveyou",
        "admin", "administrateur", "welcome", "bienvenue", "soleil", "doudou", "loulou", "chouchou",
        "marseille", "paris", "football", "dragon", "monkey", "letmein", "sunshine", "princess", "princesse",
        "master", "superman", "batman", "shadow", "michael", "nicolas", "jordan", "chocolat", "bonjour",
        "coucou", "jetaime", "secret", "passw0rd", "p@ssw0rd", "toto", "titi", "tata", "test", "test123",
        "azerty123", "qwerty123", "password1", "password123", "aaaaaa", "abcdef", "abcd1234", "1q2w3e4r",
        "zaq12wsx", "trustno1", "starwars", "pokemon", "minecraft", "freedom", "whatever", "changeme",
        "default", "root", "toor", "user", "guest", "login", "access", "hello", "charlie", "camille",
        "olivier", "thomas", "anthony", "julien", "maxime", "alexandre", "vacances", "maison", "famille",
    )

    private val keyboardRows = listOf(
        "azertyuiop", "qsdfghjklm", "wxcvbn", "qwertyuiop", "asdfghjkl", "zxcvbnm", "1234567890",
        "&é\"'(-è_çà",
    )

    private val leet = mapOf('@' to 'a', '4' to 'a', '3' to 'e', '1' to 'i', '!' to 'i', '0' to 'o', '$' to 's', '5' to 's', '7' to 't', '+' to 't')

    fun analyze(password: String): Report {
        val length = password.codePointCount(0, password.length)
        if (length == 0) {
            return Report(Level.VERY_WEAK, 0.0, 0.0, 0, 0, emptyList(), listOf("Saisissez un mot de passe à analyser."))
        }
        var charset = 0
        if (password.any { it in 'a'..'z' }) charset += 26
        if (password.any { it in 'A'..'Z' }) charset += 26
        if (password.any { it in '0'..'9' }) charset += 10
        if (password.any { it.code in 32..126 && !it.isLetterOrDigit() }) charset += 33
        if (password.any { it.code > 126 }) charset += 100
        val theoretical = length * SecureGenerators.log2(max(charset, 1).toDouble())

        val warnings = ArrayList<String>()
        val suggestions = ArrayList<String>()
        var penaltyChars = 0.0

        val lower = password.lowercase()
        val unleet = lower.map { leet[it] ?: it }.joinToString("")
        val stripped = unleet.trimEnd { it.isDigit() || it == '!' || it == '.' }
        val normalized = TextNormalizer.normalize(password).replace(" ", "")

        val isCommon = lower in common || unleet in common || stripped in common || normalized in common
        if (isCommon) warnings += "Ce mot de passe figure parmi les plus utilisés : il est deviné en quelques secondes."

        val containsCommonWord = !isCommon && common.any { it.length >= 5 && unleet.contains(it) }
        if (containsCommonWord) {
            warnings += "Contient un mot de passe courant, même avec des substitutions (@ → a, 0 → o…)."
            penaltyChars += 4.0
        }

        // Suites (abc, 123, cba, 987) et lignes de clavier.
        var sequenceChars = 0
        var run = 1
        for (i in 1 until lower.length) {
            val d = lower[i] - lower[i - 1]
            if ((d == 1 || d == -1) && lower[i].isLetterOrDigit()) run++ else {
                if (run >= 3) sequenceChars += run - 1
                run = 1
            }
        }
        if (run >= 3) sequenceChars += run - 1
        for (row in keyboardRows) {
            for (window in 4 downTo 3) {
                for (start in 0..row.length - window) {
                    val piece = row.substring(start, start + window)
                    if (lower.contains(piece) || lower.contains(piece.reversed())) { sequenceChars += window - 1; break }
                }
            }
        }
        if (sequenceChars > 0) {
            warnings += "Contient des suites prévisibles (abc, 123, azerty…)."
            penaltyChars += min(sequenceChars.toDouble(), length * 0.7)
        }

        // Répétitions (aaa, ababab).
        val repeated = Regex("(.+?)\\1{2,}").findAll(password).sumOf { it.value.length - it.groupValues[1].length }
        if (repeated > 0) {
            warnings += "Contient des répétitions (aaa, abab…)."
            penaltyChars += repeated * 0.8
        }

        // Dates et années.
        if (Regex("(19|20)\\d{2}").containsMatchIn(password) || Regex("\\d{2}[/.\\-]?\\d{2}[/.\\-]?\\d{2,4}").containsMatchIn(password)) {
            warnings += "Contient une date ou une année, souvent facile à deviner."
            penaltyChars += 2.5
        }

        // Majuscule initiale + chiffres finaux : schéma très courant.
        if (Regex("^[A-Z][a-z]+\\d{1,4}[!.?]?$").matches(password)) {
            warnings += "Schéma très courant : majuscule au début, chiffres à la fin."
            penaltyChars += 3.0
        }

        val bitsPerChar = theoretical / length
        var effective = theoretical - penaltyChars * bitsPerChar
        if (isCommon) effective = min(effective, 5.0)
        if (effective < 0) effective = 0.0

        if (length < 12) suggestions += "Visez au moins 12 caractères (16 ou plus pour un compte important)."
        if (charset <= 36 && length < 16) suggestions += "Mélangez minuscules, majuscules, chiffres et symboles, ou allongez le mot de passe."
        if (warnings.isNotEmpty()) suggestions += "Préférez un mot de passe aléatoire ou une phrase de passe générée."
        suggestions += "Utilisez un mot de passe différent pour chaque service, idéalement avec un gestionnaire de mots de passe."

        val level = when {
            effective < 28 -> Level.VERY_WEAK
            effective < 40 -> Level.WEAK
            effective < 60 -> Level.FAIR
            effective < 80 -> Level.STRONG
            else -> Level.VERY_STRONG
        }
        return Report(level, effective, theoretical, length, charset, warnings, suggestions)
    }
}
