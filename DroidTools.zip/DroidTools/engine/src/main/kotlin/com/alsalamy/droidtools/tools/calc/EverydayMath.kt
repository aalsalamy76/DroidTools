package com.alsalamy.droidtools.tools.calc

import com.alsalamy.droidtools.core.Num
import com.alsalamy.droidtools.core.Outcome
import com.alsalamy.droidtools.core.fail
import com.alsalamy.droidtools.core.outcomeOf
import java.math.BigDecimal
import java.math.BigInteger
import java.math.RoundingMode
import kotlin.math.sqrt

private val HUNDRED = BigDecimal(100)
private val CENT = BigDecimal("0.01")

private fun BigDecimal.divMc(other: BigDecimal): BigDecimal = divide(other, Num.MC)
private fun money(v: BigDecimal): BigDecimal = v.setScale(2, RoundingMode.HALF_UP)

private fun requireRate(rate: BigDecimal, field: String, max: BigDecimal = HUNDRED) {
    if (rate.signum() < 0) fail("$field : une valeur négative n'a pas de sens ici.")
    if (rate > max) fail("$field : doit être inférieur ou égal à ${max.toPlainString()} %.")
}

private fun requireNonNegative(value: BigDecimal, field: String) {
    if (value.signum() < 0) fail("$field : une valeur négative n'a pas de sens ici.")
}

/** Calculs de pourcentages. */
object Percentages {
    /** p % de x. */
    fun percentOf(p: BigDecimal, x: BigDecimal): BigDecimal = x.multiply(p).divMc(HUNDRED)

    /** part représente quel pourcentage de total. */
    fun share(part: BigDecimal, total: BigDecimal): Outcome<BigDecimal> = outcomeOf {
        if (total.signum() == 0) fail("Le total ne peut pas être nul (division par zéro).")
        part.divMc(total).multiply(HUNDRED)
    }

    /** Évolution en pourcentage de [from] vers [to]. */
    fun change(from: BigDecimal, to: BigDecimal): Outcome<BigDecimal> = outcomeOf {
        if (from.signum() == 0) fail("La valeur de départ ne peut pas être nulle (division par zéro).")
        to.subtract(from).divMc(from.abs()).multiply(HUNDRED)
    }

    /** Applique une hausse (p > 0) ou une baisse (p < 0) de p %. */
    fun applyChange(x: BigDecimal, p: BigDecimal): BigDecimal =
        x.multiply(BigDecimal.ONE.add(p.divMc(HUNDRED)))
}

data class VatResult(val excludingTax: BigDecimal, val vat: BigDecimal, val includingTax: BigDecimal)

/** TVA : montants arrondis au centime (arrondi commercial). */
object Vat {
    val frenchRates = listOf(BigDecimal("20"), BigDecimal("10"), BigDecimal("5.5"), BigDecimal("2.1"))

    fun fromExcludingTax(ht: BigDecimal, rate: BigDecimal): Outcome<VatResult> = outcomeOf {
        requireNonNegative(ht, "Montant HT")
        requireRate(rate, "Taux de TVA")
        val ht2 = money(ht)
        val vat = money(ht.multiply(rate).divMc(HUNDRED))
        VatResult(ht2, vat, ht2.add(vat))
    }

    fun fromIncludingTax(ttc: BigDecimal, rate: BigDecimal): Outcome<VatResult> = outcomeOf {
        requireNonNegative(ttc, "Montant TTC")
        requireRate(rate, "Taux de TVA")
        val ttc2 = money(ttc)
        val ht = money(ttc.divMc(BigDecimal.ONE.add(rate.divMc(HUNDRED))))
        VatResult(ht, ttc2.subtract(ht), ttc2)
    }
}

data class DiscountResult(
    val finalPrice: BigDecimal,
    val savings: BigDecimal,
    /** Remise totale équivalente, en %. */
    val effectiveRate: BigDecimal,
)

object Discount {
    /** Applique une ou plusieurs remises successives (en %). */
    fun apply(price: BigDecimal, rates: List<BigDecimal>): Outcome<DiscountResult> = outcomeOf {
        requireNonNegative(price, "Prix")
        if (rates.isEmpty()) fail("Indiquez au moins une remise.")
        var current = price
        rates.forEachIndexed { i, r ->
            requireRate(r, if (rates.size > 1) "Remise ${i + 1}" else "Remise")
            current = current.multiply(BigDecimal.ONE.subtract(r.divMc(HUNDRED)))
        }
        val final = money(current)
        val savings = money(price).subtract(final)
        val effective = if (price.signum() == 0) BigDecimal.ZERO else
            BigDecimal.ONE.subtract(current.divMc(price)).multiply(HUNDRED)
        DiscountResult(final, savings, effective)
    }
}

object RuleOfThree {
    /** Si [a] correspond à [b], alors [c] correspond à b × c / a. */
    fun solve(a: BigDecimal, b: BigDecimal, c: BigDecimal): Outcome<BigDecimal> = outcomeOf {
        if (a.signum() == 0) fail("La première valeur (A) ne peut pas être nulle (division par zéro).")
        b.multiply(c).divMc(a)
    }
}

data class BillSplit(
    val total: BigDecimal,
    val tip: BigDecimal,
    /** Part de base par personne. */
    val share: BigDecimal,
    /** Nombre de personnes qui paient un centime de plus pour tomber juste. */
    val peoplePayingOneMoreCent: Int,
    val people: Int,
)

object BillSplitter {
    fun split(amount: BigDecimal, tipPercent: BigDecimal, people: Int): Outcome<BillSplit> = outcomeOf {
        requireNonNegative(amount, "Montant")
        requireRate(tipPercent, "Pourboire")
        if (people < 1) fail("Il faut au moins une personne.")
        if (people > 1000) fail("Maximum 1000 personnes.")
        val tip = money(amount.multiply(tipPercent).divMc(HUNDRED))
        val total = money(amount).add(tip)
        val cents = total.movePointRight(2).toBigIntegerExact()
        val qr = cents.divideAndRemainder(BigInteger.valueOf(people.toLong()))
        BillSplit(
            total = total,
            tip = tip,
            share = BigDecimal(qr[0]).multiply(CENT),
            peoplePayingOneMoreCent = qr[1].toInt(),
            people = people,
        )
    }
}

data class Statistics(
    val count: Int,
    val sum: BigDecimal,
    val mean: BigDecimal,
    val weightedMean: BigDecimal?,
    val median: BigDecimal,
    val min: BigDecimal,
    val max: BigDecimal,
    val populationStdDev: Double,
    val sampleStdDev: Double?,
)

object Stats {
    const val MAX_VALUES = 10_000
    private val separators = Regex("[\\s;]+")

    /** Lit une liste de nombres séparés par des espaces, retours à la ligne ou points-virgules. */
    fun parseList(input: String, field: String): List<BigDecimal> {
        val parts = input.split(separators).filter { it.isNotBlank() }
        if (parts.size > MAX_VALUES) fail("$field : maximum $MAX_VALUES valeurs.")
        return parts.mapIndexed { i, p -> Num.parse(p, "$field (valeur ${i + 1})") }
    }

    fun compute(values: List<BigDecimal>, weights: List<BigDecimal>? = null): Outcome<Statistics> = outcomeOf {
        if (values.isEmpty()) fail("Saisissez au moins une valeur.")
        val n = values.size
        val sum = values.fold(BigDecimal.ZERO, BigDecimal::add)
        val mean = sum.divMc(BigDecimal(n))
        val sorted = values.sorted()
        val median = if (n % 2 == 1) sorted[n / 2] else sorted[n / 2 - 1].add(sorted[n / 2]).divMc(BigDecimal(2))
        val variance = values.fold(BigDecimal.ZERO) { acc, v -> acc.add(v.subtract(mean).pow(2)) }
        val weighted = weights?.let { w ->
            if (w.size != n) fail("Il faut autant de coefficients (${w.size}) que de valeurs ($n).")
            if (w.any { it.signum() < 0 }) fail("Les coefficients ne peuvent pas être négatifs.")
            val wSum = w.fold(BigDecimal.ZERO, BigDecimal::add)
            if (wSum.signum() == 0) fail("La somme des coefficients ne peut pas être nulle.")
            values.zip(w).fold(BigDecimal.ZERO) { acc, (v, c) -> acc.add(v.multiply(c)) }.divMc(wSum)
        }
        Statistics(
            count = n,
            sum = sum,
            mean = mean,
            weightedMean = weighted,
            median = median,
            min = sorted.first(),
            max = sorted.last(),
            populationStdDev = sqrt(variance.divMc(BigDecimal(n)).toDouble()),
            sampleStdDev = if (n > 1) sqrt(variance.divMc(BigDecimal(n - 1)).toDouble()) else null,
        )
    }
}

data class RatioResult(val left: BigInteger, val right: BigInteger, val quotient: BigDecimal, val leftShare: BigDecimal)

object Ratio {
    /** Simplifie a:b (accepte les décimaux : 1,5:2 → 3:4). */
    fun simplify(a: BigDecimal, b: BigDecimal): Outcome<RatioResult> = outcomeOf {
        if (a.signum() == 0 && b.signum() == 0) fail("Les deux termes ne peuvent pas être nuls.")
        if (a.signum() < 0 || b.signum() < 0) fail("Les termes d'un ratio doivent être positifs.")
        val scale = maxOf(a.stripTrailingZeros().scale(), b.stripTrailingZeros().scale(), 0)
        if (scale > 30) fail("Trop de décimales.")
        val ia = a.movePointRight(scale).toBigIntegerExact()
        val ib = b.movePointRight(scale).toBigIntegerExact()
        val gcd = ia.gcd(ib)
        val left = ia.divide(gcd)
        val right = ib.divide(gcd)
        val quotient = if (b.signum() == 0) fail("Le second terme ne peut pas être nul (division par zéro).") else a.divMc(b)
        RatioResult(left, right, quotient, a.divMc(a.add(b)).multiply(HUNDRED))
    }

    /** Résout a:b = c:x. */
    fun solve(a: BigDecimal, b: BigDecimal, c: BigDecimal): Outcome<BigDecimal> = RuleOfThree.solve(a, b, c)
}
