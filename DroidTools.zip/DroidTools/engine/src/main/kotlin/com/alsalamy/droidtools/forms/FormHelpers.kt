package com.alsalamy.droidtools.forms

import com.alsalamy.droidtools.core.Num
import com.alsalamy.droidtools.core.fail
import java.math.BigDecimal

/** Nombre obligatoire : attend la saisie si le champ est vide, erreur lisible s'il est invalide. */
internal fun FormValues.number(key: String, label: String): BigDecimal =
    Num.parseOrNull(this[key], label) ?: awaiting()

/** Nombre facultatif : null si le champ est vide. */
internal fun FormValues.optionalNumber(key: String, label: String): BigDecimal? =
    Num.parseOrNull(this[key], label)

internal fun FormValues.integer(key: String, label: String, range: IntRange): Int {
    if (isBlank(key)) awaiting()
    return Num.parseInt(this[key], label, range)
}

internal fun FormValues.longInteger(key: String, label: String): Long {
    val value = number(key, label)
    return try {
        value.stripTrailingZeros().longValueExact()
    } catch (e: ArithmeticException) {
        fail("$label : un nombre entier compris entre ${Long.MIN_VALUE} et ${Long.MAX_VALUE} est attendu.")
    }
}

/** Texte obligatoire (les espaces seuls comptent comme vide). */
internal fun FormValues.requiredText(key: String, hint: String? = null): String {
    val value = this[key]
    if (value.isBlank()) awaiting(hint)
    return value
}

internal fun fmt(value: BigDecimal, significant: Int = 12): String = Num.format(value, significant)

internal fun money(value: BigDecimal): String = Num.formatFixed(value, 2)

internal fun percent(value: BigDecimal): String = Num.format(value, 10) + " %"

internal fun signed(text: String, value: BigDecimal): String = if (value.signum() > 0) "+$text" else text

internal fun count(value: Long): String = Num.format(BigDecimal(value))

internal fun count(value: Int): String = count(value.toLong())

internal fun plural(n: Long, singular: String, plural: String = singular + "s"): String =
    "${count(n)} ${if (n == 1L || n == -1L || n == 0L) singular else plural}"

internal fun plural(n: Int, singular: String, plural: String = singular + "s"): String = plural(n.toLong(), singular, plural)

internal fun yesNo(value: Boolean): String = if (value) "Oui" else "Non"

/** Taille lisible d'une quantité d'octets. */
internal fun byteSize(bytes: Long): String = com.alsalamy.droidtools.core.ByteFormat.format(bytes)

internal fun visibleIf(key: String, vararg values: String): (FormValues) -> Boolean = { v -> v[key] in values }
