package com.alsalamy.droidtools.security

/**
 * Liste de mots français courants, sans accents, rédigée pour DroidTools (aucune liste tierce reprise).
 * Les doublons éventuels sont éliminés au chargement ; l'entropie affichée utilise la taille réelle.
 */
internal object WordList {
    private const val RAW = """
abeille abricot absolu acajou accord acier acteur adresse affiche agneau agrume aigle aiguille aimant
album alcool algue allee alliance alpage alpin amande amateur ambre ami amour ampoule ancre angle anis
anneau annee antenne aperitif appel arbre arcade archer argent argile armoire arome arrosoir artiste
asperge astre atelier atlas atome aube auberge aurore autruche avenir averse aviron avion avocat avril
badge bagage baguette baie baleine balcon ballon bambou banane banc bandeau banjo banque barque barrage
bassin bateau bazar beignet berceau berger besace beton biche bijou billard biscuit bison blason bleuet
bocal bois boisson bolide bonbon bonnet bordure bosquet botte bouchon bougie boulon bouquet boussole
bouteille bouton branche brebis brique brise brochet bronze brosse brouillard bruine buffet buisson bureau
cabane cabine cactus cadeau cadran cahier caillou caisse calcul calme camion canal canard canette canif
canoe canyon capitaine caramel caravane carnet carotte carpe carreau cartable carton cascade casque castor
cerise chaise chalet chameau champ chandelle chanson chapeau charbon chardon chariot chateau chaton
chemin cheminee chene chenille cheval cheveu chevre chiffre chocolat chorale chou ciboulette cidre ciel
cigale cinema cirque citron citrouille clairon clarinette clavier clef climat cloche clocher clown cobalt
cocotte colibri colline colombe comete compas comptoir concert concombre condor confiture coquelicot
coquillage corail corbeau cordage corde cornet costume coton coude couleur coupole courage courrier
couronne cousin coussin couteau crabe craie crayon creme crepe crevette cristal crochet crocus croissant
cuillere cuisine cuivre cumin cygne cypres dahlia dauphin degre delta dentelle depart desert dessin
detour devise diamant dinde disque docteur domaine domino donjon dragon drapeau dune duvet eclair ecluse
ecole ecorce ecran ecureuil edition eglise elan elephant emeraude encre energie enfant enigme epice epine
equipe erable escalier escargot espace espoir essai estuaire etable etage etang etoile etude evasion
fable facteur faisan falaise famille farine faucon fauteuil fenetre fenouil ferme festin feuille ficelle
figue filet flacon flamant flamme fleur fleuve flocon flute foin fontaine foret forge fougere fourmi
fraise framboise frelon fresque fromage fruit fumee fusee galaxie galet garage gardien gateau gazelle
gazon gelee genet geste girafe glacier gland globe goeland golfe gomme gondole gorille gourde goutte
grain graine grange granit grappe grenier grenouille griffe grillon grotte guepe guide guitare hamac
hameau hamster harpe hautbois herbe heron hibou hirondelle histoire hiver homard horizon horloge hotel
houblon huile huitre humour iceberg idee igloo ile image indice insecte iris ivoire jade jaguar jambon
jardin jasmin jetee jeton jonquille journal journee jument jungle jupe jus kayak kiwi koala lac lagon
lagune laine lampe langue lanterne lapin laurier lavande legume lettre levier lezard libellule lierre
lilas limace limonade lin lion litchi livre loisir losange loupe loutre lucarne lumiere lune lutin lynx
macaron magie mailles maison malle mandarine mangue manege manteau marais marbre marche marelle margelle
marmotte marron masque matin matelas medaille melodie melon menthe merle mesange metal meteore miel
miette mimosa minuit miroir mistral mollet montagne monument morille mosaique moteur mouette moulin
mousse moustique mouton muguet mur muraille murmure musee musique myrtille nacre nappe navire nectar
neige nenuphar nid noisette noix nomade nuage nuit oasis ocean ocre odeur oeillet oignon oiseau olive
ombre ongle opale orage orange orchestre orchidee oreiller orge origami orme ortie otarie ouragan ours
outil ouvrage pagaie paille palais palette palmier pamplemousse panda panier panneau papillon paquet
parapluie parc parfum passage pastel pastis patin pave pavot paysage peche pelage pelican pelouse pendule
peniche pepite perle perroquet persil phare phoque piano pierre pigeon piment pinceau pingouin pirate
piscine piste pistache placard plage planete platane plateau plume poche poesie poire poireau poisson
poivre polaire pomme pompier pont porte portail potager poterie pouce poulain poussin prairie printemps
prisme prune puits pupitre puzzle pyjama quai quartz quiche racine radeau radis rameau rampe raquette
rayon recette recif refuge regard regate reglisse renard requin reseau rhubarbe riviere robot rocher
romarin ronce rondelle roseau rossignol roue rouleau royaume rubis ruche ruelle ruisseau sabot sable
sabre safran salade salon sandale sapin sardine satin sauge saule savane savon scarabee scene secret
seigle sentier serpent serre sifflet signal silence sirop soleil sommet sonnet sorbet source souris
stade statue studio sucre sureau tableau tablier tambour tamis tapis tarte tasse taureau temple tempete
terrain terrasse theiere thym tigre tilleul timbre tiroir tissu toboggan toile toit tomate tonneau
topaze torche tortue toupie tournesol trajet trefle treille tresor tribu tricot trompette tronc trophee
tropique trottoir truffe tulipe tunnel turquoise tuyau union univers usine vague vallee valise vanille
vapeur velours vent verger verre vertige veste viaduc village violon vitrail voile volcan voyage wagon
yaourt zebre zenith zephyr
abime accent actif adroit agile aimable aise alerte allure ample ancien anime ardent argent arrondi
astral audace aveugle azur bavard beige berceuse blanc blond bref brillant bronze brut calin carre
celeste charmant chaud chic clair cocasse comique commun content correct coulant courbe court crispant
cuit curieux delicat dense direct discret divers docile dore doux droit drole dur elegant enorme epais
espiegle etroit exact fameux fatigue fertile fidele fier fin flou fluide fort fragile franc frisson
froid fute gai geant gentil glacial grand gris habile heureux humble ideal immense intime jaune joli
joyeux juste large leger lent libre limpide lisse loyal lumineux magique malin mauve mignon mince
modeste moelleux moyen muet naif natal neuf noble noir normal nouveau obscur ondule opaque orne pale
paisible parfait patient petit plat plein poli precieux prompt propre prudent pur rapide rare rasant
ravi reel riche rigolo robuste rond rose rouge royal rustique sage sain sauvage secret serein serieux
simple sincere solide sombre souple stable subtil sucre superbe tendre tenace tiede timide tranquille
triste vaillant vaste velu vert vif vigilant violet vivant volant
accueil achat adieu agenda alarme ancetre animal annonce appareil appui arche armure arome atelier
attente avenue baladeur balade balai balance bambin bandit baril baron bastion bataille batteur bavoir
benne betail bidon bilan bistrot bitume blague bloc bobine bocage bolet bordeaux borne bourgeon boxeur
bracelet brasier bretelle brindille brioche broche brochure brouette buffle bulle butte cabas cadet
cafard cahute caleche calepin calice camelia campagne canape cantine capuche carafe carillon carrosse
cartouche castagne cavalier cedre cellier cendre cerceau cerf chacal chaland chamois chantier chapelle
charade charpente chasse chaudron chevalier chevet chiot choeur chouette cigogne citadelle civet clairiere
clapotis clavecin clementine cloison club cochon coffre colis collier colonne comptine conte copain
coquille corbeille corniche cortege coteau couloir coupelle courant coureur crapaud credit creneau
crinoline croquis cruche cuve cyclone dague dalle damier danseur debut decor defi delice demeure
dentifrice depot derive desir destin devinette diable dicton digue dindon diner diplome divan dolmen
dossier douane douceur doudou dragee dressoir duel durite eau ebene echarpe echelle echo eclat ecrin
ecuelle ecurie edredon effet egout embleme embruns encrier enclos engin enseigne entrepot envol epee
epopee epuisette ermite escale escrime esquimau essaim estrade etain etau etendard etui eventail evier
fagot faience fanal fanfare farandole fardeau fauve feerie felin fenaison feston feutre fiacre fifre
filature flambeau flanc fleuret flotte flou fondue fortin fossile fouet fourche fourneau foyer fracas
fregate frimas friche fronton fuseau gabarit galette galion galop gamelle gamme garenne gargouille
gaufre gazette gerbe geyser gibier gilet girouette givre glaive glycine gobelet goelette gong gouache
gouffre goujon gradin grelot griffon grimoire grive grosseille guepard guichet guirlande gymnase haie
halte hangar hareng hautain hennin herisson hetre hochet homonyme hublot hutte hymne ibis icone imprimerie
inconnu ivresse jabot jacinthe jarre javelot jockey joyau judo juillet jumelle kiosque labyrinthe
lacet lagopede laitue lambris lame lampion landau lasso latte lavoir layette lecteur legende lessive
licorne lieue liseron litiere livret logis lorgnon louve lustre lyre mache madrier magasin maillet
maillot manchot manivelle maquette marin marmite marteau martinet massif matelot mazurka meandre melisse
menhir merlan meunier micro mille minaret minerai mirabelle mitaine moineau molette monnaie morse mortier
moufle moule mousquet muflier mulet murene mystere nageur nautile negoce nervure nougat nuance obelisque
obus odyssee oeuvre offrande ogive oiselet ombrelle onglet opera oracle orateur orbite ormeau osier
ourlet ouvreuse ovale pagode palet palissade pampa panache pantin papyrus parchemin parquet patio
pavillon pecheur pedale peigne pelerin pelote penne pergola perron pervenche petale petrel peuplier
phalene pharaon pic pichet pilote pinson pipeau pirogue pivoine placide plancher plinthe plongeur
plumier pochoir podium pollen pommade poney portique potiron poudre poulie poutre praline presage
prieure proue psaume pulpe pyramide quadrille quartier quenouille quinquet rabot racloir rafale ragout
raisin ramage rapace rasoir ravin rebond rempart remous renne repas rideau rigole rivage roitelet roquette
rosace rotonde rouet rubicond rucher sacoche saison salamandre sanglier santon sarment satellite saumon
sauterelle scaphandre sceptre seau semaine semoule sequoia serinette sillon sirene soupape sourire
spirale squelette steppe sterne stylo sultan support surplis syrinx tabouret taillis talisman tamarin
tangente tanniere tapir tarot tartine tasseau teck tenor tente terrier tetard theatre tiare tirelire
tisane toise tonnelle torrent totem toucan touche tourbillon tourelle traineau trampoline traverse
tremplin trident tripode troene trombone troupeau truelle tuile tutu ukulele urne vaisseau valet valse
vantail varech vase vautour velin venelle verveine vestige vigie vigne vinaigre virgule vitrine voliere
vouivre zinc
"""

    val words: List<String> by lazy {
        RAW.split(Regex("\\s+"))
            .map { it.trim().lowercase() }
            .filter { it.length in 3..12 && it.all { c -> c in 'a'..'z' } }
            .distinct()
    }
}
