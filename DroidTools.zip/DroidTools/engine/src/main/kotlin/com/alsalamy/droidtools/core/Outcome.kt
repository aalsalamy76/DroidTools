package com.alsalamy.droidtools.core

/**
 * Résultat d'une opération pouvant échouer sur une entrée utilisateur.
 *
 * Les messages d'erreur sont destinés à être affichés tels quels : ils sont
 * rédigés en français, compréhensibles, et ne contiennent jamais de trace technique.
 */
sealed interface Outcome<out T> {
    data class Ok<out T>(val value: T) : Outcome<T>
    data class Err(val message: String) : Outcome<Nothing>

    fun getOrNull(): T? = (this as? Ok<T>)?.value
    fun errorOrNull(): String? = (this as? Err)?.message
}

inline fun <T, R> Outcome<T>.map(transform: (T) -> R): Outcome<R> = when (this) {
    is Outcome.Ok -> Outcome.Ok(transform(value))
    is Outcome.Err -> this
}

inline fun <T, R> Outcome<T>.flatMap(transform: (T) -> Outcome<R>): Outcome<R> = when (this) {
    is Outcome.Ok -> transform(value)
    is Outcome.Err -> this
}

/** Exception interne utilisée pour remonter un message utilisateur depuis un parseur. */
class UserInputException(message: String) : Exception(message)

/** Exécute [block] et convertit toute erreur attendue en [Outcome.Err] lisible. */
inline fun <T> outcomeOf(block: () -> T): Outcome<T> = try {
    Outcome.Ok(block())
} catch (e: UserInputException) {
    Outcome.Err(e.message ?: "Entrée invalide.")
} catch (e: ArithmeticException) {
    Outcome.Err("Calcul impossible avec ces valeurs.")
} catch (e: NumberFormatException) {
    Outcome.Err("Nombre invalide.")
} catch (e: StackOverflowError) {
    Outcome.Err("Entrée trop complexe.")
} catch (e: OutOfMemoryError) {
    Outcome.Err("Entrée trop volumineuse pour être traitée.")
}

fun fail(message: String): Nothing = throw UserInputException(message)
