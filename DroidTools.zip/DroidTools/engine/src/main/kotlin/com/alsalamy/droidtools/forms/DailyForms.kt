package com.alsalamy.droidtools.forms

import com.alsalamy.droidtools.core.fail
import com.alsalamy.droidtools.security.SecureGenerators
import com.alsalamy.droidtools.tools.time.TimeTools
import com.alsalamy.droidtools.tools.time.TimestampUnit
import com.alsalamy.droidtools.tools.time.Ulid
import com.alsalamy.droidtools.tools.time.UuidVersion
import com.alsalamy.droidtools.tools.time.Uuids
import java.time.Period
import java.time.format.DateTimeFormatter
import java.util.Locale

internal object DailyForms {

    private val longDate = DateTimeFormatter.ofPattern("EEEE d MMMM uuuu", Locale.FRENCH)

    internal fun periodText(p: Period): String {
        val parts = buildList {
            if (p.years != 0) add(plural(p.years, "an"))
            if (p.months != 0) add("${count(p.months)} mois")
            if (p.days != 0 || isEmpty()) add(plural(p.days, "jour"))
        }
        return parts.joinToString(", ")
    }

    // ------------------------------------------------------------ Timestamps

    val unixNow: ToolForm = ToolForm(
        fields = emptyList(),
        refreshEveryMillis = 1000,
        intro = "Heure de l'appareil, mise à jour chaque seconde.",
    ) { _, ctx ->
        val now = ctx.now()
        val info = TimeTools.describe(now, TimestampUnit.SECONDS, ctx.zone, now)
        FormResult(
            ResultRow("Secondes depuis le 1er janvier 1970 (UTC)", info.epochSeconds.toString(), monospace = true, emphasis = true),
            ResultRow("Millisecondes", info.epochMillis.toString(), monospace = true),
            ResultRow("UTC (ISO 8601)", info.utcIso, monospace = true),
            ResultRow("Heure locale (ISO 8601)", info.localIso, monospace = true),
            ResultRow("Date lisible", info.localReadable),
            ResultRow("Fuseau horaire", info.zone, copyable = false),
        )
    }

    val timestampToDate: ToolForm = ToolForm(
        fields = listOf(
            TextInput("ts", "Timestamp Unix", InputKind.CODE, placeholder = "1700000000"),
            ChoiceInput("unit", "Unité", TimestampUnit.entries.map { Choice(it.name, it.label) }),
        ),
    ) { v, ctx ->
        val info = TimeTools.fromTimestamp(v.requiredText("ts"), TimestampUnit.valueOf(v["unit"]), ctx.zone, ctx.now()).orFail()
        val items = mutableListOf<ResultItem>(ResultRow("Date locale", info.localReadable, emphasis = true))
        if (TimestampUnit.valueOf(v["unit"]) == TimestampUnit.AUTO) {
            items += ResultRow("Unité détectée", info.detectedUnit.label, copyable = false)
        }
        items += listOf(
            ResultRow("Relatif à maintenant", info.relative, copyable = false),
            ResultRow("Heure locale (ISO 8601)", info.localIso, monospace = true),
            ResultRow("UTC (ISO 8601)", info.utcIso, monospace = true),
            ResultRow("Secondes", info.epochSeconds.toString(), monospace = true),
            ResultRow("Millisecondes", info.epochMillis.toString(), monospace = true),
            ResultRow("Jour de l'année", count(info.dayOfYear), copyable = false),
            ResultRow("Semaine ISO", count(info.isoWeek), copyable = false),
            ResultRow("Fuseau horaire", info.zone, copyable = false),
        )
        FormResult(items)
    }

    val dateToTimestamp: ToolForm = ToolForm(
        fields = listOf(
            TextInput("date", "Date et heure", InputKind.DATE_TIME, placeholder = "31/12/2025 23:59",
                supportingText = "JJ/MM/AAAA [HH:MM[:SS]], ou ISO 8601 avec décalage (2025-12-31T23:59:00+01:00)"),
        ),
    ) { v, ctx ->
        val r = TimeTools.toTimestamp(v.requiredText("date"), ctx.zone).orFail()
        val items = mutableListOf<ResultItem>(
            ResultRow("Secondes", r.epochSeconds.toString(), monospace = true, emphasis = true),
            ResultRow("Millisecondes", r.epochMillis.toString(), monospace = true),
            ResultRow("UTC (ISO 8601)", r.utcIso, monospace = true),
            ResultRow("Avec décalage horaire", r.zonedIso, monospace = true),
        )
        r.dstWarning?.let { items += ResultNotice(it, NoticeLevel.WARNING) }
        FormResult(items)
    }

    // ------------------------------------------------------------ Identifiants

    val uuid: ToolForm = ToolForm(
        fields = listOf(
            ChoiceInput("version", "Version", UuidVersion.entries.map { Choice(it.name, it.label) }),
            SliderInput("count", "Quantité", 1, 50, 1),
            ToggleInput("uppercase", "Majuscules"),
            ToggleInput("hyphens", "Avec tirets", default = true),
        ),
        trigger = Trigger.ON_ACTION_AND_OPEN,
        actionLabel = "Générer",
        intro = "Aléa issu de SecureRandom. La version 7 intègre l'horodatage de génération (triable).",
    ) { v, ctx ->
        val version = UuidVersion.valueOf(v["version"])
        val ids = List(v.int("count", 1)) {
            val uuid = if (version == UuidVersion.V7) Uuids.v7(ctx.now().toEpochMilli(), ctx.random) else Uuids.v4(ctx.random)
            Uuids.format(uuid, v.flag("uppercase"), v.flag("hyphens"))
        }
        identifiers(ids, "UUID")
    }

    val ulid: ToolForm = ToolForm(
        fields = listOf(SliderInput("count", "Quantité", 1, 50, 1)),
        trigger = Trigger.ON_ACTION_AND_OPEN,
        actionLabel = "Générer",
        intro = "ULID : 48 bits d'horodatage + 80 bits d'aléa (SecureRandom), encodés en Crockford Base32.",
    ) { v, ctx ->
        val millis = ctx.now().toEpochMilli()
        if (millis !in 0..Ulid.MAX_TIMESTAMP) fail("L'horloge de l'appareil est hors de la plage ULID.")
        identifiers(List(v.int("count", 1)) { Ulid.generate(millis, ctx.random) }, "ULID")
    }

    private fun identifiers(ids: List<String>, label: String): FormResult =
        if (ids.size == 1) {
            FormResult(ResultRow(label, ids.first(), monospace = true, emphasis = true))
        } else {
            FormResult(ResultText("${ids.size} $label", ids.joinToString("\n"), monospace = true))
        }

    // ------------------------------------------------------------ Dates

    val countdown: ToolForm = ToolForm(
        fields = listOf(
            TextInput("target", "Date cible", InputKind.DATE_TIME, placeholder = "25/12/2026 00:00",
                supportingText = "JJ/MM/AAAA, avec l'heure facultative (HH:MM)"),
        ),
        refreshEveryMillis = 1000,
    ) { v, ctx ->
        val target = TimeTools.parseLocalDateTime(v.requiredText("target"))
        val r = TimeTools.countdown(target, ctx.zone, ctx.now()).orFail()
        val main = "${plural(r.days, "jour")} ${r.hours.toString().padStart(2, '0')} h " +
            "${r.minutes.toString().padStart(2, '0')} min ${r.seconds.toString().padStart(2, '0')} s"
        FormResult(
            ResultRow(if (r.past) "Échéance passée depuis" else "Temps restant", main, emphasis = true, copyable = false),
            ResultRow("En heures", count(r.totalSeconds / 3600), copyable = false),
            ResultRow("En secondes", count(r.totalSeconds), copyable = false),
            ResultRow("Échéance", target.format(DateTimeFormatter.ofPattern("EEEE d MMMM uuuu 'à' HH:mm", Locale.FRENCH)), copyable = false),
        )
    }

    val dateDifference: ToolForm = ToolForm(
        fields = listOf(
            TextInput("start", "Date de début", InputKind.DATE, placeholder = "01/01/2026"),
            TextInput("end", "Date de fin", InputKind.DATE, placeholder = "31/12/2026"),
            ToggleInput("includeEnd", "Inclure le jour de fin"),
        ),
    ) { v, _ ->
        val start = TimeTools.parseLocalDate(v.requiredText("start"))
        val end = TimeTools.parseLocalDate(v.requiredText("end"))
        val d = TimeTools.difference(start, end, v.flag("includeEnd"))
        val items = mutableListOf<ResultItem>(
            ResultRow("Durée", periodText(d.period), emphasis = true),
            ResultRow("Total en jours", plural(d.totalDays, "jour")),
            ResultRow("En semaines", "${plural(d.weeks, "semaine")} et ${plural(d.remainingDays, "jour")}"),
            ResultRow("Mois complets", count(d.totalMonths)),
            ResultRow("Jours ouvrés (lundi–vendredi)", count(d.businessDays)),
            ResultNotice("Les jours fériés ne sont pas déduits des jours ouvrés."),
        )
        if (d.negative) items += ResultNotice("La date de fin précède la date de début : la durée est calculée dans l'autre sens.", NoticeLevel.WARNING)
        FormResult(items)
    }

    val age: ToolForm = ToolForm(
        fields = listOf(TextInput("birth", "Date de naissance", InputKind.DATE, placeholder = "14/07/1990")),
        intro = "La date de naissance reste en mémoire le temps du calcul : elle n'est jamais enregistrée.",
    ) { v, ctx ->
        val birth = TimeTools.parseLocalDate(v.requiredText("birth"))
        val today = ctx.now().atZone(ctx.zone).toLocalDate()
        val r = TimeTools.age(birth, today).orFail()
        val items = mutableListOf<ResultItem>(
            ResultRow("Âge", periodText(Period.of(r.years, r.months, r.days)), emphasis = true, copyable = false),
            ResultRow("Né(e) un", r.bornOn, copyable = false),
            ResultRow("Total en jours", count(r.totalDays), copyable = false),
            ResultRow("Total en mois", count(r.totalMonths), copyable = false),
        )
        items += if (r.isBirthdayToday) {
            ResultNotice("Joyeux anniversaire ! ${r.years} ans aujourd'hui.", NoticeLevel.SUCCESS)
        } else {
            ResultRow("Prochain anniversaire (${r.nextAge} ans)",
                "${r.nextBirthday.format(longDate)} — dans ${plural(r.daysUntilNextBirthday, "jour")}", copyable = false)
        }
        FormResult(items)
    }

    // ------------------------------------------------------------ Hasard

    val randomNumbers: ToolForm = ToolForm(
        fields = listOf(
            TextInput("min", "Minimum", InputKind.INTEGER, default = "1"),
            TextInput("max", "Maximum", InputKind.INTEGER, default = "100"),
            SliderInput("count", "Nombre de tirages", 1, 100, 1),
            ToggleInput("unique", "Sans répétition"),
            ToggleInput("sorted", "Trier les résultats"),
        ),
        trigger = Trigger.ON_ACTION,
        actionLabel = "Tirer",
        intro = "Tirage uniforme (sans biais de modulo) avec SecureRandom.",
    ) { v, ctx ->
        val min = v.longInteger("min", "Minimum")
        val max = v.longInteger("max", "Maximum")
        val values = SecureGenerators.randomNumbers(
            SecureGenerators.RandomNumbersOptions(min, max, v.int("count", 1), v.flag("unique"), v.flag("sorted")),
            ctx.random,
        ).orFail()
        if (values.size == 1) {
            FormResult(ResultRow("Résultat", values.first().toString(), emphasis = true))
        } else {
            FormResult(ResultText("${values.size} nombres", values.joinToString(", ")))
        }
    }

    val dice: ToolForm = ToolForm(
        fields = listOf(
            SliderInput("count", "Nombre de dés", 1, 20, 2),
            ChoiceInput("faces", "Faces", SecureGenerators.diceFaces.map { Choice(it.toString(), "D$it") }, default = "6"),
        ),
        trigger = Trigger.ON_ACTION,
        actionLabel = "Lancer",
    ) { v, ctx ->
        val faces = v["faces"].toIntOrNull() ?: 6
        val rolls = SecureGenerators.rollDice(v.int("count", 2), faces, ctx.random).orFail()
        val items = mutableListOf<ResultItem>(ResultRow("Total", count(rolls.sum()), emphasis = true, copyable = false))
        if (rolls.size > 1) {
            items += ResultRow("Dés", rolls.joinToString("  ·  "), copyable = false)
            items += ResultRow("Plus haut / plus bas", "${rolls.max()} / ${rolls.min()}", copyable = false)
        }
        FormResult(items)
    }

    val coin: ToolForm = ToolForm(
        fields = emptyList(),
        trigger = Trigger.ON_ACTION,
        actionLabel = "Lancer la pièce",
        intro = "Tirage équitable avec SecureRandom.",
    ) { _, ctx ->
        FormResult(ResultRow("Résultat", if (SecureGenerators.flipCoin(ctx.random)) "Pile" else "Face", emphasis = true, copyable = false))
    }
}
