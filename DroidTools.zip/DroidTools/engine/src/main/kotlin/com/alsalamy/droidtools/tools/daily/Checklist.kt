package com.alsalamy.droidtools.tools.daily

import com.alsalamy.droidtools.core.Outcome
import com.alsalamy.droidtools.core.fail
import com.alsalamy.droidtools.core.outcomeOf
import com.alsalamy.droidtools.tools.json.Json
import com.alsalamy.droidtools.tools.json.JsonValue

data class ChecklistItem(val id: Long, val text: String, val done: Boolean)

/** Opérations pures sur la checklist et format de stockage (JSON). */
object Checklist {
    const val MAX_ITEMS = 500
    const val MAX_TEXT_LENGTH = 500

    fun add(items: List<ChecklistItem>, text: String): Outcome<List<ChecklistItem>> = outcomeOf {
        val clean = text.trim().replace(Regex("\\s+"), " ")
        if (clean.isEmpty()) fail("Saisissez un élément.")
        if (clean.length > MAX_TEXT_LENGTH) fail("Élément trop long (maximum $MAX_TEXT_LENGTH caractères).")
        if (items.size >= MAX_ITEMS) fail("La checklist est pleine ($MAX_ITEMS éléments maximum).")
        val nextId = (items.maxOfOrNull { it.id } ?: 0) + 1
        items + ChecklistItem(nextId, clean, done = false)
    }

    fun toggle(items: List<ChecklistItem>, id: Long): List<ChecklistItem> =
        items.map { if (it.id == id) it.copy(done = !it.done) else it }

    fun remove(items: List<ChecklistItem>, id: Long): List<ChecklistItem> = items.filterNot { it.id == id }

    fun clearDone(items: List<ChecklistItem>): List<ChecklistItem> = items.filterNot { it.done }

    fun encode(items: List<ChecklistItem>): String = Json.serialize(
        JsonValue.Arr(
            items.map {
                JsonValue.Obj(
                    listOf(
                        "id" to JsonValue.Num(it.id.toString()),
                        "text" to JsonValue.Str(it.text),
                        "done" to JsonValue.Bool(it.done),
                    ),
                )
            },
        ),
        indentUnit = null,
        sortKeys = false,
    )

    /** Lecture tolérante : un contenu illisible donne une liste vide, un élément invalide est ignoré. */
    fun decode(stored: String?): List<ChecklistItem> {
        if (stored.isNullOrBlank()) return emptyList()
        val root = Json.parse(stored).getOrNull()?.value as? JsonValue.Arr ?: return emptyList()
        val seen = HashSet<Long>()
        return root.items.mapNotNull { node ->
            val obj = node as? JsonValue.Obj ?: return@mapNotNull null
            val fields = obj.members.toMap()
            val id = (fields["id"] as? JsonValue.Num)?.raw?.toLongOrNull() ?: return@mapNotNull null
            val text = (fields["text"] as? JsonValue.Str)?.value?.take(MAX_TEXT_LENGTH) ?: return@mapNotNull null
            val done = (fields["done"] as? JsonValue.Bool)?.value ?: false
            if (!seen.add(id) || text.isBlank()) null else ChecklistItem(id, text, done)
        }.take(MAX_ITEMS)
    }
}
