package com.alsalamy.droidtools.tools.net

/**
 * Analyse heuristique d'une chaîne User-Agent, entièrement locale.
 * Les résultats sont indicatifs : un User-Agent peut être modifié librement par le client.
 */
object UserAgentParser {

    data class Result(
        val browser: String,
        val browserVersion: String?,
        val engine: String,
        val os: String,
        val osVersion: String?,
        val deviceType: String,
        val deviceModel: String?,
        val isBot: Boolean,
        val notes: List<String>,
    )

    private fun version(ua: String, token: String): String? =
        Regex(Regex.escape(token) + "[/ ]([0-9][0-9._]*)").find(ua)?.groupValues?.get(1)?.replace('_', '.')

    fun parse(userAgent: String): Result? {
        val ua = userAgent.trim()
        if (ua.isEmpty()) return null
        val notes = ArrayList<String>()

        val bot = Regex("(?i)(bot|crawler|spider|crawl|slurp|facebookexternalhit|bingpreview|headless)").find(ua)
        val (browser, browserVersion) = when {
            ua.contains("EdgA/") -> "Microsoft Edge (Android)" to version(ua, "EdgA")
            ua.contains("EdgiOS/") -> "Microsoft Edge (iOS)" to version(ua, "EdgiOS")
            ua.contains("Edg/") -> "Microsoft Edge" to version(ua, "Edg")
            ua.contains("OPR/") -> "Opera" to version(ua, "OPR")
            ua.contains("SamsungBrowser/") -> "Samsung Internet" to version(ua, "SamsungBrowser")
            ua.contains("FxiOS/") -> "Firefox (iOS)" to version(ua, "FxiOS")
            ua.contains("Firefox/") -> "Firefox" to version(ua, "Firefox")
            ua.contains("CriOS/") -> "Chrome (iOS)" to version(ua, "CriOS")
            ua.contains("HeadlessChrome/") -> "Chrome sans interface (automatisation)" to version(ua, "HeadlessChrome")
            ua.contains("; wv)") && ua.contains("Chrome/") -> "WebView Android" to version(ua, "Chrome")
            ua.contains("Chrome/") -> "Chrome" to version(ua, "Chrome")
            ua.contains("Safari/") && ua.contains("Version/") -> "Safari" to version(ua, "Version")
            ua.contains("curl/") -> "curl" to version(ua, "curl")
            ua.contains("Wget/") -> "Wget" to version(ua, "Wget")
            bot != null -> "Robot (${bot.value})" to null
            else -> "Inconnu" to null
        }

        val engine = when {
            ua.contains("iPhone") || ua.contains("iPad") || ua.contains("iPod") -> "WebKit (imposé sur iOS)"
            ua.contains("Gecko/") && ua.contains("Firefox/") -> "Gecko"
            ua.contains("Chrome/") || ua.contains("Edg/") || ua.contains("OPR/") -> "Blink"
            ua.contains("AppleWebKit/") -> "WebKit"
            ua.contains("Trident/") -> "Trident (Internet Explorer)"
            else -> "Inconnu"
        }

        var deviceModel: String? = null
        val (os, osVersion) = when {
            ua.contains("Windows NT") -> {
                val nt = version(ua, "Windows NT")
                "Windows" to when (nt) {
                    "10.0" -> "10 ou 11".also { notes += "Windows 10 et 11 envoient la même version (NT 10.0)." }
                    "6.3" -> "8.1"
                    "6.2" -> "8"
                    "6.1" -> "7"
                    else -> nt
                }
            }
            ua.contains("Android") -> {
                val v = Regex("Android ([0-9.]+)").find(ua)?.groupValues?.get(1)
                deviceModel = Regex("Android [0-9.]+; ([^;)]+?)(?: Build/[^;)]*)?\\)").find(ua)?.groupValues?.get(1)?.trim()
                if (deviceModel == "K") {
                    deviceModel = null
                    notes += "Modèle masqué par le navigateur (User-Agent réduit) : « K » est une valeur fixe."
                }
                "Android" to v
            }
            ua.contains("iPhone") || ua.contains("iPad") || ua.contains("iPod") -> {
                deviceModel = when { ua.contains("iPad") -> "iPad"; ua.contains("iPod") -> "iPod"; else -> "iPhone" }
                "iOS / iPadOS" to Regex("OS ([0-9_]+)").find(ua)?.groupValues?.get(1)?.replace('_', '.')
            }
            ua.contains("CrOS") -> "ChromeOS" to null
            ua.contains("Mac OS X") -> {
                val v = Regex("Mac OS X ([0-9_.]+)").find(ua)?.groupValues?.get(1)?.replace('_', '.')
                if (v == "10.15.7") notes += "macOS récent : la version est figée à 10.15.7 par les navigateurs."
                "macOS" to v
            }
            ua.contains("Linux") -> "Linux" to null
            else -> "Inconnu" to null
        }

        val deviceType = when {
            bot != null -> "Robot / outil automatique"
            ua.contains("iPad") || ua.contains("Tablet") || (ua.contains("Android") && !ua.contains("Mobile")) -> "Tablette"
            ua.contains("Mobile") || ua.contains("iPhone") -> "Mobile"
            os == "Inconnu" && browser in listOf("curl", "Wget") -> "Outil en ligne de commande"
            else -> "Ordinateur"
        }

        if (ua.contains("Chrome/") && Regex("Chrome/\\d+\\.0\\.0\\.0").containsMatchIn(ua)) {
            notes += "Version mineure masquée (x.0.0.0) : Chrome réduit volontairement les détails du User-Agent."
        }
        return Result(browser, browserVersion, engine, os, osVersion, deviceType, deviceModel, bot != null, notes)
    }
}
