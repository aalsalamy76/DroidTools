package com.alsalamy.droidtools.forms

import com.alsalamy.droidtools.security.HashAlgorithm
import com.alsalamy.droidtools.tools.convert.Quantity

/**
 * Registre des outils décrits par formulaire.
 *
 * Un outil disponible (FONCTIONNEL ou PARTIEL) doit soit posséder un formulaire ici,
 * soit figurer dans [customScreens] (écran spécifique côté Android). Les tests vérifient
 * cette règle pour tout le catalogue.
 */
object ToolForms {

    /** Outils dont l'interface est un écran Android dédié (clavier de calculatrice, fichiers, chronométrage, stockage). */
    val customScreens: Set<String> = setOf(
        "calculator",
        "scientific_calculator",
        "file_hash",
        "stopwatch",
        "timer",
        "checklist",
    )

    private val forms: Map<String, () -> ToolForm> = buildMap {
        put("percentages") { CalcForms.percentages }
        put("vat") { CalcForms.vat }
        put("discount") { CalcForms.discount }
        put("rule_of_three") { CalcForms.ruleOfThree }
        put("bill_split") { CalcForms.billSplit }
        put("average") { CalcForms.average }
        put("ratio") { CalcForms.ratio }
        Quantity.entries.forEach { q -> put(q.toolId) { CalcForms.conversion(q) } }
        put("number_base") { CalcForms.numberBase }

        put("ipv4_calculator") { NetworkForms.ipv4Calculator }
        put("cidr_calculator") { NetworkForms.cidrCalculator }
        put("ipv4_to_binary") { NetworkForms.ipv4ToBinary }
        put("binary_to_ipv4") { NetworkForms.binaryToIpv4 }
        put("subnet_analysis") { NetworkForms.subnetAnalysis }
        put("user_agent_parser") { NetworkForms.userAgent }
        put("color_converter") { NetworkForms.color }

        put("text_counter") { TextForms.counter }
        put("text_uppercase") { TextForms.uppercase }
        put("text_lowercase") { TextForms.lowercase }
        put("text_capitalize") { TextForms.capitalize }
        put("text_clean_spaces") { TextForms.cleanSpaces }
        put("text_dedupe_lines") { TextForms.dedupe }
        put("text_sort_lines") { TextForms.sortLines }
        put("text_reverse") { TextForms.reverse }
        put("find_replace") { TextForms.findReplace }
        put("base64_encode") { TextForms.base64Encode }
        put("base64_decode") { TextForms.base64Decode }
        put("url_encode") { TextForms.urlEncode }
        put("url_decode") { TextForms.urlDecode }
        put("json_formatter") { TextForms.jsonFormat }
        put("json_validator") { TextForms.jsonValidate }
        put("json_minifier") { TextForms.jsonMinify }
        put("xml_formatter") { TextForms.xml }
        put("regex_tester") { TextForms.regexTester }
        put("string_escape") { TextForms.escape }
        put("unicode_inspector") { TextForms.unicode }
        put("unix_timestamp") { DailyForms.unixNow }
        put("timestamp_to_date") { DailyForms.timestampToDate }
        put("date_to_timestamp") { DailyForms.dateToTimestamp }
        put("uuid_generator") { DailyForms.uuid }
        put("ulid_generator") { DailyForms.ulid }

        put("password_generator") { SecurityForms.password }
        put("passphrase_generator") { SecurityForms.passphrase }
        put("pin_generator") { SecurityForms.pin }
        put("password_strength") { SecurityForms.strength }
        put("random_token") { SecurityForms.token }
        put("hash_sha256") { SecurityForms.hash(HashAlgorithm.SHA256) }
        put("hash_sha512") { SecurityForms.hash(HashAlgorithm.SHA512) }
        put("hash_md5") { SecurityForms.hash(HashAlgorithm.MD5) }
        put("hash_compare") { SecurityForms.compare }

        put("countdown") { DailyForms.countdown }
        put("date_difference") { DailyForms.dateDifference }
        put("age_calculator") { DailyForms.age }
        put("random_numbers") { DailyForms.randomNumbers }
        put("dice") { DailyForms.dice }
        put("coin_flip") { DailyForms.coin }
    }

    val formIds: Set<String> get() = forms.keys

    /** Formulaire de l'outil, ou null s'il n'en a pas (écran dédié ou outil non implémenté). */
    fun forTool(id: String): ToolForm? = forms[id]?.invoke()
}
