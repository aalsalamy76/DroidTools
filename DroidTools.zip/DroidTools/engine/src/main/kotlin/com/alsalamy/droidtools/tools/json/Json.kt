package com.alsalamy.droidtools.tools.json

import com.alsalamy.droidtools.core.Outcome
import com.alsalamy.droidtools.core.UserInputException
import com.alsalamy.droidtools.core.outcomeOf

/** Arbre JSON fidèle : l'ordre des clés et l'écriture exacte des nombres sont conservés. */
sealed interface JsonValue {
    data class Obj(val members: List<Pair<String, JsonValue>>) : JsonValue
    data class Arr(val items: List<JsonValue>) : JsonValue
    data class Str(val value: String) : JsonValue
    /** Le nombre est conservé tel qu'écrit (aucune perte de précision). */
    data class Num(val raw: String) : JsonValue
    data class Bool(val value: Boolean) : JsonValue
    data object Null : JsonValue
}

data class JsonError(val message: String, val line: Int, val column: Int, val excerpt: String)

data class JsonAnalysis(
    val value: JsonValue,
    val duplicateKeys: List<String>,
    val objectCount: Int,
    val arrayCount: Int,
    val maxDepth: Int,
)

enum class JsonIndent(val label: String, val unit: String) {
    TWO("2 espaces", "  "),
    FOUR("4 espaces", "    "),
    TAB("Tabulation", "\t"),
}

/**
 * Analyseur JSON strict conforme à la RFC 8259 (pas de commentaires, pas de virgule finale,
 * pas de guillemets simples). Profondeur limitée pour éviter tout débordement de pile.
 */
object Json {
    const val MAX_DEPTH = 512
    const val MAX_INPUT_CHARS = 10_000_000

    class ParseException(val error: JsonError) : Exception(error.message)

    fun parse(text: String): Result<JsonAnalysis> = try {
        if (text.length > MAX_INPUT_CHARS) throw ParseException(JsonError("Texte trop volumineux (maximum 10 millions de caractères).", 1, 1, ""))
        Result.success(Parser(text).parseDocument())
    } catch (e: ParseException) {
        Result.failure(e)
    }

    fun errorOf(result: Result<JsonAnalysis>): JsonError? = (result.exceptionOrNull() as? ParseException)?.error

    fun format(text: String, indent: JsonIndent = JsonIndent.TWO, sortKeys: Boolean = false): Outcome<String> =
        withParsed(text) { serialize(it, indent.unit, sortKeys) }

    fun minify(text: String): Outcome<String> = withParsed(text) { serialize(it, null, false) }

    private inline fun withParsed(text: String, block: (JsonValue) -> String): Outcome<String> = outcomeOf {
        val result = parse(text)
        val error = errorOf(result)
        if (error != null) throw UserInputException("${error.message} (ligne ${error.line}, colonne ${error.column})")
        block(result.getOrThrow().value)
    }

    fun serialize(value: JsonValue, indentUnit: String?, sortKeys: Boolean): String {
        val sb = StringBuilder()
        write(sb, value, indentUnit, sortKeys, 0)
        return sb.toString()
    }

    private fun write(sb: StringBuilder, value: JsonValue, unit: String?, sortKeys: Boolean, level: Int) {
        when (value) {
            is JsonValue.Obj -> {
                if (value.members.isEmpty()) { sb.append("{}"); return }
                val members = if (sortKeys) value.members.sortedBy { it.first } else value.members
                sb.append('{')
                members.forEachIndexed { i, (key, v) ->
                    if (i > 0) sb.append(',')
                    newline(sb, unit, level + 1)
                    writeString(sb, key)
                    sb.append(if (unit != null) ": " else ":")
                    write(sb, v, unit, sortKeys, level + 1)
                }
                newline(sb, unit, level)
                sb.append('}')
            }
            is JsonValue.Arr -> {
                if (value.items.isEmpty()) { sb.append("[]"); return }
                sb.append('[')
                value.items.forEachIndexed { i, v ->
                    if (i > 0) sb.append(',')
                    newline(sb, unit, level + 1)
                    write(sb, v, unit, sortKeys, level + 1)
                }
                newline(sb, unit, level)
                sb.append(']')
            }
            is JsonValue.Str -> writeString(sb, value.value)
            is JsonValue.Num -> sb.append(value.raw)
            is JsonValue.Bool -> sb.append(value.value)
            JsonValue.Null -> sb.append("null")
        }
    }

    private fun newline(sb: StringBuilder, unit: String?, level: Int) {
        if (unit == null) return
        sb.append('\n')
        repeat(level) { sb.append(unit) }
    }

    private fun writeString(sb: StringBuilder, s: String) {
        sb.append('"')
        for (c in s) {
            when (c) {
                '"' -> sb.append("\\\"")
                '\\' -> sb.append("\\\\")
                '\n' -> sb.append("\\n")
                '\r' -> sb.append("\\r")
                '\t' -> sb.append("\\t")
                '\b' -> sb.append("\\b")
                '\u000C' -> sb.append("\\f")
                else -> if (c < ' ') sb.append("\\u").append(Integer.toHexString(c.code).padStart(4, '0')) else sb.append(c)
            }
        }
        sb.append('"')
    }

    private class Parser(private val text: String) {
        private var pos = 0
        private val duplicates = LinkedHashSet<String>()
        private var objects = 0
        private var arrays = 0
        private var maxDepth = 0

        fun parseDocument(): JsonAnalysis {
            skipWhitespace()
            if (pos >= text.length) error("Le texte est vide : un document JSON est attendu.")
            val value = parseValue(1)
            skipWhitespace()
            if (pos < text.length) error("Contenu inattendu après la fin du document JSON.")
            return JsonAnalysis(value, duplicates.toList(), objects, arrays, maxDepth)
        }

        private fun error(message: String, at: Int = pos): Nothing {
            var line = 1
            var lineStart = 0
            val limit = minOf(at, text.length)
            for (i in 0 until limit) if (text[i] == '\n') { line++; lineStart = i + 1 }
            val lineEnd = text.indexOf('\n', lineStart).let { if (it < 0) text.length else it }
            val from = maxOf(lineStart, limit - 30)
            val to = minOf(lineEnd, limit + 30)
            val excerpt = text.substring(from, to)
            throw ParseException(JsonError(message, line, limit - lineStart + 1, excerpt))
        }

        private fun skipWhitespace() {
            while (pos < text.length) {
                val c = text[pos]
                if (c == ' ' || c == '\t' || c == '\n' || c == '\r') pos++ else break
            }
        }

        private fun parseValue(depth: Int): JsonValue {
            if (depth > MAX_DEPTH) error("Imbrication trop profonde (maximum $MAX_DEPTH niveaux).")
            if (depth > maxDepth) maxDepth = depth
            skipWhitespace()
            if (pos >= text.length) error("Fin du texte inattendue : une valeur est attendue.")
            return when (val c = text[pos]) {
                '{' -> parseObject(depth)
                '[' -> parseArray(depth)
                '"' -> JsonValue.Str(parseString())
                't' -> literal("true", JsonValue.Bool(true))
                'f' -> literal("false", JsonValue.Bool(false))
                'n' -> literal("null", JsonValue.Null)
                else -> if (c == '-' || c in '0'..'9') parseNumber() else when (c) {
                    '\'' -> error("Les chaînes JSON doivent utiliser des guillemets doubles (\").")
                    '/' -> error("Les commentaires ne sont pas autorisés en JSON.")
                    else -> error("Caractère inattendu « $c » : une valeur JSON est attendue.")
                }
            }
        }

        private fun literal(word: String, value: JsonValue): JsonValue {
            if (!text.startsWith(word, pos)) error("Valeur invalide : « $word » attendu.")
            pos += word.length
            return value
        }

        private fun parseObject(depth: Int): JsonValue {
            objects++
            pos++ // {
            val members = ArrayList<Pair<String, JsonValue>>()
            val keys = HashSet<String>()
            skipWhitespace()
            if (pos < text.length && text[pos] == '}') { pos++; return JsonValue.Obj(members) }
            while (true) {
                skipWhitespace()
                if (pos >= text.length) error("Objet non fermé : « } » manquant.")
                if (text[pos] == '}') error("Virgule finale interdite avant « } ».")
                if (text[pos] != '"') error("Nom de propriété attendu entre guillemets doubles.")
                val key = parseString()
                if (!keys.add(key)) duplicates += key
                skipWhitespace()
                if (pos >= text.length || text[pos] != ':') error("« : » attendu après le nom de propriété \"$key\".")
                pos++
                members += key to parseValue(depth + 1)
                skipWhitespace()
                if (pos >= text.length) error("Objet non fermé : « } » manquant.")
                when (text[pos]) {
                    ',' -> pos++
                    '}' -> { pos++; return JsonValue.Obj(members) }
                    else -> error("« , » ou « } » attendu.")
                }
            }
        }

        private fun parseArray(depth: Int): JsonValue {
            arrays++
            pos++ // [
            val items = ArrayList<JsonValue>()
            skipWhitespace()
            if (pos < text.length && text[pos] == ']') { pos++; return JsonValue.Arr(items) }
            while (true) {
                skipWhitespace()
                if (pos < text.length && text[pos] == ']') error("Virgule finale interdite avant « ] ».")
                items += parseValue(depth + 1)
                skipWhitespace()
                if (pos >= text.length) error("Tableau non fermé : « ] » manquant.")
                when (text[pos]) {
                    ',' -> pos++
                    ']' -> { pos++; return JsonValue.Arr(items) }
                    else -> error("« , » ou « ] » attendu.")
                }
            }
        }

        private fun parseString(): String {
            val start = pos
            pos++ // "
            val sb = StringBuilder()
            while (true) {
                if (pos >= text.length) error("Chaîne non fermée : guillemet manquant.", start)
                val c = text[pos]
                when {
                    c == '"' -> { pos++; return sb.toString() }
                    c == '\\' -> {
                        if (pos + 1 >= text.length) error("Séquence d'échappement incomplète.")
                        when (val e = text[pos + 1]) {
                            '"' -> sb.append('"')
                            '\\' -> sb.append('\\')
                            '/' -> sb.append('/')
                            'b' -> sb.append('\b')
                            'f' -> sb.append('\u000C')
                            'n' -> sb.append('\n')
                            'r' -> sb.append('\r')
                            't' -> sb.append('\t')
                            'u' -> {
                                if (pos + 6 > text.length) error("Séquence \\u incomplète.")
                                val hex = text.substring(pos + 2, pos + 6)
                                if (!hex.all { it in '0'..'9' || it in 'a'..'f' || it in 'A'..'F' }) error("Séquence « \\u$hex » invalide.")
                                sb.append(hex.toInt(16).toChar())
                                pos += 6
                                continue
                            }
                            else -> error("Séquence d'échappement « \\$e » invalide.")
                        }
                        pos += 2
                    }
                    c < ' ' -> error("Caractère de contrôle non échappé dans une chaîne (utilisez \\n, \\t…).")
                    else -> { sb.append(c); pos++ }
                }
            }
        }

        private fun parseNumber(): JsonValue {
            val start = pos
            if (text[pos] == '-') pos++
            if (pos >= text.length) error("Nombre incomplet.")
            if (text[pos] == '0') {
                pos++
                if (pos < text.length && text[pos] in '0'..'9') error("Les zéros non significatifs sont interdits en JSON.", start)
            } else if (text[pos] in '1'..'9') {
                while (pos < text.length && text[pos] in '0'..'9') pos++
            } else error("Nombre invalide.")
            if (pos < text.length && text[pos] == '.') {
                pos++
                if (pos >= text.length || text[pos] !in '0'..'9') error("Au moins un chiffre est attendu après le point décimal.")
                while (pos < text.length && text[pos] in '0'..'9') pos++
            }
            if (pos < text.length && (text[pos] == 'e' || text[pos] == 'E')) {
                pos++
                if (pos < text.length && (text[pos] == '+' || text[pos] == '-')) pos++
                if (pos >= text.length || text[pos] !in '0'..'9') error("Exposant invalide.")
                while (pos < text.length && text[pos] in '0'..'9') pos++
            }
            return JsonValue.Num(text.substring(start, pos))
        }
    }
}
