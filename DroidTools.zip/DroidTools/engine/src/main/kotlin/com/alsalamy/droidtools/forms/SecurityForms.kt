package com.alsalamy.droidtools.forms

import com.alsalamy.droidtools.security.HashAlgorithm
import com.alsalamy.droidtools.security.HashComparison
import com.alsalamy.droidtools.security.Hashing
import com.alsalamy.droidtools.security.Passphrase
import com.alsalamy.droidtools.security.PasswordStrength
import com.alsalamy.droidtools.security.SecureGenerators
import kotlin.math.roundToInt

internal object SecurityForms {

    private const val NOT_STORED = "Valeur générée sur l'appareil avec SecureRandom. Elle n'est ni enregistrée, ni journalisée, ni ajoutée à l'historique."

    private fun entropyRow(bits: Double) = ResultRow("Entropie", "≈ ${bits.roundToInt()} bits", copyable = false)

    /** Niveau indicatif d'après l'entropie d'une valeur réellement aléatoire. */
    private fun entropyMeter(bits: Double): ResultMeter {
        val (label, level) = when {
            bits >= 100 -> "Très fort" to NoticeLevel.SUCCESS
            bits >= 72 -> "Fort" to NoticeLevel.SUCCESS
            bits >= 50 -> "Moyen" to NoticeLevel.WARNING
            else -> "Faible" to NoticeLevel.ERROR
        }
        return ResultMeter("Robustesse", (bits / 128.0).coerceIn(0.0, 1.0).toFloat(), label, level)
    }

    val password: ToolForm = ToolForm(
        fields = listOf(
            SliderInput("length", "Longueur", 8, 128, 20, unit = "caractères"),
            ToggleInput("lower", "Minuscules (a-z)", default = true),
            ToggleInput("upper", "Majuscules (A-Z)", default = true),
            ToggleInput("digits", "Chiffres (0-9)", default = true),
            ToggleInput("symbols", "Symboles (!#\$%…)", default = true),
            ToggleInput("noAmbiguous", "Exclure les caractères ambigus (I, l, 1, O, 0…)"),
        ),
        trigger = Trigger.ON_ACTION_AND_OPEN,
        actionLabel = "Générer",
        secureScreen = true,
        intro = NOT_STORED,
    ) { v, ctx ->
        val r = SecureGenerators.password(
            SecureGenerators.PasswordOptions(
                length = v.int("length", 20),
                lowercase = v.flag("lower"),
                uppercase = v.flag("upper"),
                digits = v.flag("digits"),
                symbols = v.flag("symbols"),
                excludeAmbiguous = v.flag("noAmbiguous"),
            ),
            ctx.random,
        ).orFail()
        FormResult(
            ResultRow("Mot de passe", r.value, monospace = true, sensitive = true, emphasis = true),
            entropyMeter(r.entropyBits),
            entropyRow(r.entropyBits),
        )
    }

    val passphrase: ToolForm = ToolForm(
        fields = listOf(
            SliderInput("words", "Nombre de mots", 3, 12, 6, unit = "mots"),
            ChoiceInput(
                "separator", "Séparateur",
                listOf(Choice("-", "Tiret -"), Choice(" ", "Espace"), Choice(".", "Point ."), Choice("_", "Souligné _"), Choice("none", "Aucun")),
            ),
            ToggleInput("capitalize", "Majuscule à chaque mot"),
            ToggleInput("digit", "Ajouter un chiffre"),
        ),
        trigger = Trigger.ON_ACTION_AND_OPEN,
        actionLabel = "Générer",
        secureScreen = true,
        intro = "Mots tirés au hasard dans une liste intégrée de ${Passphrase.dictionarySize} mots. $NOT_STORED",
    ) { v, ctx ->
        val separator = v["separator"].let { if (it == "none") "" else it }
        val r = Passphrase.generate(
            Passphrase.Options(words = v.int("words", 6), separator = separator, capitalize = v.flag("capitalize"), appendDigit = v.flag("digit")),
            ctx.random,
        ).orFail()
        FormResult(
            ResultRow("Phrase de passe", r.value, monospace = true, sensitive = true, emphasis = true),
            entropyMeter(r.entropyBits),
            entropyRow(r.entropyBits),
        )
    }

    val pin: ToolForm = ToolForm(
        fields = listOf(
            SliderInput("length", "Nombre de chiffres", 4, 12, 6, unit = "chiffres"),
            ToggleInput("avoidTrivial", "Exclure les codes évidents (1234, 0000, 2580…)", default = true),
        ),
        trigger = Trigger.ON_ACTION_AND_OPEN,
        actionLabel = "Générer",
        secureScreen = true,
        intro = NOT_STORED,
    ) { v, ctx ->
        val r = SecureGenerators.pin(SecureGenerators.PinOptions(v.int("length", 6), v.flag("avoidTrivial")), ctx.random).orFail()
        FormResult(
            ResultRow("Code PIN", r.value, monospace = true, sensitive = true, emphasis = true),
            entropyRow(r.entropyBits),
        )
    }

    val token: ToolForm = ToolForm(
        fields = listOf(
            SliderInput("bytes", "Taille", 8, 256, 32, unit = "octets"),
            ChoiceInput("format", "Format", SecureGenerators.TokenFormat.entries.map { Choice(it.name, it.label) }),
        ),
        trigger = Trigger.ON_ACTION_AND_OPEN,
        actionLabel = "Générer",
        secureScreen = true,
        intro = NOT_STORED,
    ) { v, ctx ->
        val r = SecureGenerators.token(v.int("bytes", 32), SecureGenerators.TokenFormat.valueOf(v["format"]), ctx.random).orFail()
        FormResult(
            ResultRow("Jeton", r.value, monospace = true, sensitive = true, emphasis = true),
            entropyRow(r.entropyBits),
        )
    }

    val strength: ToolForm = ToolForm(
        fields = listOf(TextInput("password", "Mot de passe à analyser", InputKind.SECRET)),
        secureScreen = true,
        intro = "Analyse entièrement locale, en mémoire. Le mot de passe n'est jamais enregistré, copié, journalisé ni transmis.",
    ) { v, _ ->
        val password = v["password"]
        if (password.isEmpty()) awaiting()
        val r = PasswordStrength.analyze(password)
        val level = when (r.level) {
            PasswordStrength.Level.VERY_WEAK, PasswordStrength.Level.WEAK -> NoticeLevel.ERROR
            PasswordStrength.Level.FAIR -> NoticeLevel.WARNING
            PasswordStrength.Level.STRONG, PasswordStrength.Level.VERY_STRONG -> NoticeLevel.SUCCESS
        }
        val items = mutableListOf<ResultItem>(
            ResultMeter("Robustesse estimée", (r.level.score + 1) / 5f, r.level.label, level),
            ResultRow("Entropie effective estimée", "≈ ${r.effectiveBits.roundToInt()} bits", copyable = false),
            ResultRow("Longueur", plural(r.length, "caractère"), copyable = false),
            ResultRow("Taille de l'alphabet utilisé", count(r.charsetSize), copyable = false),
        )
        r.warnings.forEach { items += ResultNotice(it, NoticeLevel.WARNING) }
        r.suggestions.forEach { items += ResultNotice(it) }
        items += ResultNotice("Estimation indicative fondée sur des règles locales : elle ne garantit pas la sécurité.")
        FormResult(items)
    }

    fun hash(algorithm: HashAlgorithm): ToolForm = ToolForm(
        fields = listOf(
            TextInput("text", "Texte", InputKind.MULTILINE, placeholder = "Texte à hacher (encodé en UTF-8)"),
            ToggleInput("uppercase", "Hexadécimal en majuscules"),
        ),
        warning = if (algorithm == HashAlgorithm.MD5) {
            "MD5 est cassé : ne l'utilisez jamais pour protéger des mots de passe ni dans un nouveau système de sécurité. " +
                "Il reste utile pour vérifier une somme de contrôle publiée en MD5."
        } else {
            null
        },
    ) { v, _ ->
        val text = v["text"]
        if (text.isEmpty()) awaiting()
        val r = Hashing.text(text, algorithm)
        val hex = if (v.flag("uppercase")) r.hex.uppercase() else r.hex
        FormResult(
            ResultRow("${algorithm.label} (hexadécimal)", hex, monospace = true, emphasis = true),
            ResultRow("Base64", r.base64, monospace = true),
            ResultRow("Données hachées", byteSize(text.toByteArray(Charsets.UTF_8).size.toLong()) + " (UTF-8)", copyable = false),
        )
    }

    val compare: ToolForm = ToolForm(
        fields = listOf(
            TextInput("a", "Première empreinte", InputKind.CODE, placeholder = "e3b0c442…"),
            TextInput("b", "Seconde empreinte", InputKind.CODE, placeholder = "e3b0c442…"),
        ),
        intro = "Espaces, deux-points, tirets et casse sont ignorés. Comparaison à temps constant.",
    ) { v, _ ->
        val a = v.requiredText("a")
        val b = v.requiredText("b")
        val result = Hashing.compare(a, b).orFail()
        val items = mutableListOf<ResultItem>(
            when (result) {
                HashComparison.EQUAL -> ResultNotice("Les empreintes sont identiques.", NoticeLevel.SUCCESS)
                HashComparison.DIFFERENT -> ResultNotice("Les empreintes sont différentes.", NoticeLevel.ERROR)
                HashComparison.INVALID -> ResultNotice("Au moins une empreinte n'est pas en hexadécimal : comparaison impossible.", NoticeLevel.WARNING)
            },
        )
        val la = Hashing.guessAlgorithm(a)
        val lb = Hashing.guessAlgorithm(b)
        if (la != null) items += ResultRow("Algorithme probable (1)", la.label, copyable = false)
        if (lb != null && lb != la) items += ResultRow("Algorithme probable (2)", lb.label, copyable = false)
        val na = Hashing.normalize(a).length
        val nb = Hashing.normalize(b).length
        if (result == HashComparison.DIFFERENT && na != nb) {
            items += ResultNotice("Longueurs différentes ($na et $nb caractères) : il s'agit sans doute de deux algorithmes différents.")
        }
        FormResult(items)
    }
}
