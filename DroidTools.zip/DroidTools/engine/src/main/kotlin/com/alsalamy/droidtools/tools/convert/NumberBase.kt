package com.alsalamy.droidtools.tools.convert

import com.alsalamy.droidtools.core.Outcome
import com.alsalamy.droidtools.core.fail
import com.alsalamy.droidtools.core.outcomeOf
import java.math.BigInteger
import java.util.Locale

enum class Radix(val base: Int, val label: String) {
    BINARY(2, "Binaire"),
    OCTAL(8, "Octal"),
    DECIMAL(10, "Décimal"),
    HEXADECIMAL(16, "Hexadécimal"),
}

data class BaseConversion(
    val value: BigInteger,
    val binary: String,
    val octal: String,
    val decimal: String,
    val hexadecimal: String,
    val bitLength: Int,
    /** Représentation en complément à deux sur la plus petite largeur standard (valeurs négatives). */
    val twosComplement: String?,
)

/** Conversion entre bases 2, 8, 10 et 16, sur des entiers de taille arbitraire (limités à 4096 bits). */
object NumberBase {
    private const val MAX_BITS = 4096

    fun convert(input: String, radix: Radix): Outcome<BaseConversion> = outcomeOf {
        var s = input.trim().replace("_", "").replace(" ", "").replace('−', '-')
        if (s.isEmpty()) fail("Saisissez un nombre.")
        val negative = s.startsWith("-")
        if (negative || s.startsWith("+")) s = s.substring(1)
        val lower = s.lowercase(Locale.ROOT)
        s = when {
            radix == Radix.HEXADECIMAL && lower.startsWith("0x") -> s.substring(2)
            radix == Radix.BINARY && lower.startsWith("0b") -> s.substring(2)
            radix == Radix.OCTAL && lower.startsWith("0o") -> s.substring(2)
            else -> s
        }
        if (s.isEmpty()) fail("Saisissez un nombre.")
        val allowed = when (radix) {
            Radix.BINARY -> "01"
            Radix.OCTAL -> "01234567"
            Radix.DECIMAL -> "0123456789"
            Radix.HEXADECIMAL -> "0123456789abcdef"
        }
        s.forEachIndexed { i, c ->
            if (c.lowercaseChar() !in allowed) {
                fail("Caractère « $c » invalide en ${radix.label.lowercase()} (position ${i + 1}).")
            }
        }
        if (s.length > MAX_BITS) fail("Nombre trop long.")
        var value = BigInteger(s, radix.base)
        if (negative) value = value.negate()
        if (value.bitLength() > MAX_BITS) fail("Nombre trop grand (maximum $MAX_BITS bits).")
        BaseConversion(
            value = value,
            binary = value.toString(2),
            octal = value.toString(8),
            decimal = value.toString(10),
            hexadecimal = value.toString(16).uppercase(Locale.ROOT),
            bitLength = value.bitLength(),
            twosComplement = if (value.signum() < 0) twosComplement(value) else null,
        )
    }

    private fun twosComplement(value: BigInteger): String? {
        val width = listOf(8, 16, 32, 64, 128).firstOrNull { value >= BigInteger.ONE.shiftLeft(it - 1).negate() }
            ?: return null
        val modulus = BigInteger.ONE.shiftLeft(width)
        val bits = value.add(modulus).toString(2).padStart(width, '0')
        return "$width bits : " + bits.chunked(4).joinToString(" ")
    }

    /** Groupe une chaîne binaire par paquets de 4 bits pour la lisibilité. */
    fun groupBinary(binary: String): String {
        val negative = binary.startsWith("-")
        val digits = if (negative) binary.substring(1) else binary
        val padded = digits.padStart((digits.length + 3) / 4 * 4, '0')
        return (if (negative) "-" else "") + padded.chunked(4).joinToString(" ")
    }
}
