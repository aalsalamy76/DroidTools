package com.alsalamy.droidtools.forms

import com.alsalamy.droidtools.core.Outcome
import com.alsalamy.droidtools.core.UserInputException
import com.alsalamy.droidtools.core.fail
import java.security.SecureRandom
import java.time.Instant
import java.time.ZoneId

/*
 * Description déclarative d'un outil sous forme de formulaire.
 *
 * Toute la logique (champs, validation, calcul, mise en forme du résultat) vit ici, en Kotlin pur :
 * elle est compilée et testée sans Android. L'application Android se contente d'afficher
 * ces descriptions avec un moteur de rendu générique.
 */

/** Nature d'un champ texte : détermine le clavier et le comportement de saisie côté Android. */
enum class InputKind {
    /** Texte court sur une ligne. */
    TEXT,

    /** Texte libre sur plusieurs lignes. */
    MULTILINE,

    /** Code ou donnée technique sur une ligne : police à chasse fixe, sans correction automatique. */
    CODE,

    /** Bloc de code sur plusieurs lignes (JSON, XML, Base64…). */
    CODE_BLOCK,

    /** Nombre décimal (virgule ou point). */
    NUMBER,

    /** Nombre entier. */
    INTEGER,

    /** Date seule (JJ/MM/AAAA), avec sélecteur de date. */
    DATE,

    /** Date et heure facultative (JJ/MM/AAAA HH:MM). */
    DATE_TIME,

    /** Donnée secrète : masquée, sans suggestions ni apprentissage du clavier. */
    SECRET,
}

sealed interface Field {
    val key: String
    val label: String

    /** Le champ n'est affiché (et pris en compte) que si ce prédicat est vrai. */
    val visibleWhen: ((FormValues) -> Boolean)?
}

class TextInput(
    override val key: String,
    override val label: String,
    val kind: InputKind = InputKind.TEXT,
    val placeholder: String = "",
    val default: String = "",
    val supportingText: String? = null,
    val suffix: String? = null,
    override val visibleWhen: ((FormValues) -> Boolean)? = null,
) : Field

class Choice(val id: String, val label: String)

class ChoiceInput(
    override val key: String,
    override val label: String,
    val options: List<Choice>,
    val default: String = options.first().id,
    override val visibleWhen: ((FormValues) -> Boolean)? = null,
) : Field {
    init {
        require(options.isNotEmpty()) { "Aucune option pour $key" }
        require(options.any { it.id == default }) { "Valeur par défaut inconnue pour $key" }
        require(options.map { it.id }.toSet().size == options.size) { "Options en double pour $key" }
    }
}

class ToggleInput(
    override val key: String,
    override val label: String,
    val default: Boolean = false,
    val supportingText: String? = null,
    override val visibleWhen: ((FormValues) -> Boolean)? = null,
) : Field

class SliderInput(
    override val key: String,
    override val label: String,
    val min: Int,
    val max: Int,
    val default: Int,
    val unit: String = "",
    override val visibleWhen: ((FormValues) -> Boolean)? = null,
) : Field {
    init {
        require(min < max) { "Bornes invalides pour $key" }
        require(default in min..max) { "Valeur par défaut hors bornes pour $key" }
    }
}

/** Valeurs saisies, toutes stockées sous forme de texte (« true »/« false » pour les interrupteurs). */
class FormValues(private val values: Map<String, String>) {
    operator fun get(key: String): String = values[key] ?: ""
    fun flag(key: String): Boolean = values[key] == "true"
    fun int(key: String, fallback: Int): Int = values[key]?.toIntOrNull() ?: fallback
    fun isBlank(key: String): Boolean = this[key].isBlank()
    fun with(key: String, value: String): FormValues = FormValues(values + (key to value))
    fun asMap(): Map<String, String> = values

    companion object {
        fun defaults(form: ToolForm): FormValues = FormValues(form.fields.associate { it.key to defaultOf(it) })

        fun defaultOf(field: Field): String = when (field) {
            is TextInput -> field.default
            is ChoiceInput -> field.default
            is ToggleInput -> field.default.toString()
            is SliderInput -> field.default.toString()
        }
    }
}

/** Environnement injecté (horloge, fuseau, aléa sûr) : permet des tests déterministes. */
class FormContext(
    val now: () -> Instant,
    val zone: ZoneId,
    val random: SecureRandom,
)

enum class NoticeLevel { INFO, SUCCESS, WARNING, ERROR }

sealed interface ResultItem

/** Titre de section dans un résultat. */
data class ResultHeader(val title: String) : ResultItem

/** Ligne libellé / valeur. */
data class ResultRow(
    val label: String,
    val value: String,
    val copyable: Boolean = true,
    val monospace: Boolean = false,
    /** Valeur sensible (mot de passe, PIN, jeton) : copie signalée comme sensible, jamais conservée. */
    val sensitive: Boolean = false,
    /** Résultat principal, affiché en grand. */
    val emphasis: Boolean = false,
    /** Couleur à afficher en aperçu (ARGB 32 bits). */
    val swatchArgb: Long? = null,
) : ResultItem

/** Bloc de texte long (texte transformé, JSON formaté…). */
data class ResultText(
    val label: String,
    val text: String,
    val monospace: Boolean = false,
    val sensitive: Boolean = false,
) : ResultItem

/** Message. Le niveau est toujours accompagné d'une icône et d'un texte (jamais la couleur seule). */
data class ResultNotice(val text: String, val level: NoticeLevel = NoticeLevel.INFO) : ResultItem

/** Jauge (robustesse d'un mot de passe…) : [fraction] de 0 à 1, toujours accompagnée de [valueText]. */
data class ResultMeter(val label: String, val fraction: Float, val valueText: String, val level: NoticeLevel) : ResultItem

data class FormResult(val items: List<ResultItem>) {
    constructor(vararg items: ResultItem) : this(items.toList())
}

/** Issue d'une évaluation, toujours affichable telle quelle. */
sealed interface FormOutcome {
    data class Success(val result: FormResult) : FormOutcome
    data class Invalid(val message: String) : FormOutcome
    data class Waiting(val hint: String?) : FormOutcome
}

/** Levée quand un champ nécessaire est encore vide : on attend la saisie, sans afficher d'erreur. */
class AwaitingInputException(val hint: String? = null) : Exception(hint)

fun awaiting(hint: String? = null): Nothing = throw AwaitingInputException(hint)

/** Déclenchement du calcul. */
enum class Trigger {
    /** À chaque modification (avec un court délai). */
    LIVE,

    /** Uniquement sur le bouton d'action. */
    ON_ACTION,

    /** Sur le bouton d'action, et une fois à l'ouverture de l'outil. */
    ON_ACTION_AND_OPEN,
}

class ToolForm(
    val fields: List<Field>,
    val trigger: Trigger = Trigger.LIVE,
    val actionLabel: String = "Calculer",
    /** Recalcul périodique (horloges, comptes à rebours). */
    val refreshEveryMillis: Long? = null,
    /** Bloque captures d'écran et aperçu dans les applications récentes (données secrètes). */
    val secureScreen: Boolean = false,
    /** Courte explication affichée au-dessus des champs. */
    val intro: String? = null,
    /** Avertissement permanent (ex. MD5). */
    val warning: String? = null,
    private val compute: (FormValues, FormContext) -> FormResult,
) {
    init {
        val keys = fields.map { it.key }
        require(keys.toSet().size == keys.size) { "Clés de champ en double : $keys" }
    }

    /** Évalue le formulaire ; les erreurs de saisie deviennent des messages lisibles, jamais des exceptions. */
    fun evaluate(values: FormValues, context: FormContext): FormOutcome = try {
        FormOutcome.Success(compute(values, context))
    } catch (e: AwaitingInputException) {
        FormOutcome.Waiting(e.hint)
    } catch (e: UserInputException) {
        FormOutcome.Invalid(e.message ?: "Entrée invalide.")
    } catch (e: ArithmeticException) {
        FormOutcome.Invalid("Calcul impossible avec ces valeurs.")
    } catch (e: NumberFormatException) {
        FormOutcome.Invalid("Nombre invalide.")
    } catch (e: StackOverflowError) {
        FormOutcome.Invalid("Entrée trop complexe.")
    } catch (e: OutOfMemoryError) {
        FormOutcome.Invalid("Entrée trop volumineuse pour être traitée.")
    }

    fun visibleFields(values: FormValues): List<Field> = fields.filter { it.visibleWhen?.invoke(values) ?: true }
}

/** Extrait la valeur d'un [Outcome] ou remonte son message d'erreur. */
fun <T> Outcome<T>.orFail(): T = when (this) {
    is Outcome.Ok -> value
    is Outcome.Err -> fail(message)
}
