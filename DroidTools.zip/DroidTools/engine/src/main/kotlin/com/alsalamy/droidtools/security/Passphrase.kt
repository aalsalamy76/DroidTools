package com.alsalamy.droidtools.security

import com.alsalamy.droidtools.core.Outcome
import com.alsalamy.droidtools.core.fail
import com.alsalamy.droidtools.core.outcomeOf
import java.security.SecureRandom
import java.util.Locale

object Passphrase {
    val separators = listOf("-", " ", ".", "_", "")

    data class Options(
        val words: Int = 6,
        val separator: String = "-",
        val capitalize: Boolean = false,
        val appendDigit: Boolean = false,
    )

    val dictionarySize: Int get() = WordList.words.size

    fun generate(options: Options, random: SecureRandom): Outcome<SecureGenerators.Generated> = outcomeOf {
        if (options.words !in 3..12) fail("Choisissez entre 3 et 12 mots.")
        val list = WordList.words
        val chosen = MutableList(options.words) { list[random.nextInt(list.size)] }
        if (options.capitalize) {
            for (i in chosen.indices) chosen[i] = chosen[i].replaceFirstChar { it.titlecase(Locale.FRENCH) }
        }
        var entropy = options.words * SecureGenerators.log2(list.size.toDouble())
        if (options.appendDigit) {
            val target = random.nextInt(chosen.size)
            chosen[target] = chosen[target] + random.nextInt(10)
            entropy += SecureGenerators.log2(10.0 * chosen.size)
        }
        SecureGenerators.Generated(chosen.joinToString(options.separator), entropy)
    }
}
