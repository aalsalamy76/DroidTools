package com.alsalamy.droidtools.tools.text

import com.alsalamy.droidtools.core.Outcome
import com.alsalamy.droidtools.core.fail
import com.alsalamy.droidtools.core.outcomeOf
import java.text.BreakIterator
import java.text.Collator
import java.util.Locale
import java.util.regex.Pattern

data class TextStats(
    val characters: Int,
    val charactersNoSpaces: Int,
    val words: Int,
    val lines: Int,
    val nonEmptyLines: Int,
    val paragraphs: Int,
    val sentences: Int,
    val utf8Bytes: Int,
    /** Temps de lecture estimé (230 mots/minute), en secondes. */
    val readingSeconds: Int,
)

object TextStatistics {
    private val wordRegex = Regex("[\\p{L}\\p{N}]+(?:['’\\-][\\p{L}\\p{N}]+)*")
    private val sentenceEnd = Regex("[.!?…]+(?=\\s|$)")
    private val paragraphSplit = Regex("\\n\\s*\\n")

    /** Nombre de caractères perçus (graphèmes) : « é » composé ou une lettre accentuée comptent pour 1. */
    fun graphemeCount(text: String): Int {
        if (text.isEmpty()) return 0
        val it = BreakIterator.getCharacterInstance(Locale.ROOT)
        it.setText(text)
        var count = 0
        while (it.next() != BreakIterator.DONE) count++
        return count
    }

    /** Phrases approximatives : ponctuation finale, plus un éventuel dernier segment sans ponctuation. */
    private fun countSentences(text: String): Int {
        if (text.isEmpty()) return 0
        val ends = sentenceEnd.findAll(text).toList()
        val tailStart = ends.lastOrNull()?.range?.last?.plus(1) ?: 0
        val tail = text.substring(tailStart)
        return ends.size + if (tail.any { it.isLetterOrDigit() }) 1 else 0
    }

    fun analyze(text: String): TextStats {
        val normalized = text.replace("\r\n", "\n").replace('\r', '\n')
        val words = wordRegex.findAll(normalized).count()
        val lines = if (normalized.isEmpty()) 0 else normalized.count { it == '\n' } + 1
        val nonEmpty = normalized.split('\n').count { it.isNotBlank() }
        val paragraphs = if (normalized.isBlank()) 0 else normalized.trim().split(paragraphSplit).count { it.isNotBlank() }
        val sentences = countSentences(normalized.trim())
        val noSpaces = normalized.filterNot { it.isWhitespace() }
        return TextStats(
            characters = graphemeCount(normalized),
            charactersNoSpaces = graphemeCount(noSpaces),
            words = words,
            lines = lines,
            nonEmptyLines = nonEmpty,
            paragraphs = paragraphs,
            sentences = sentences,
            utf8Bytes = text.toByteArray(Charsets.UTF_8).size,
            readingSeconds = if (words == 0) 0 else maxOf(1, Math.round(words * 60.0 / 230.0).toInt()),
        )
    }
}

enum class TextOperation(val label: String) {
    UPPERCASE("MAJUSCULES"),
    LOWERCASE("minuscules"),
    CAPITALIZE_WORDS("Chaque Mot"),
    CAPITALIZE_SENTENCES("Début de phrase"),
    CLEAN_SPACES("Nettoyer les espaces"),
    DEDUPE_LINES("Supprimer les doublons"),
    SORT_LINES("Trier les lignes"),
    REVERSE_TEXT("Inverser les caractères"),
    REVERSE_LINES("Inverser l'ordre des lignes"),
}

enum class SortOrder(val label: String) { ASCENDING("A → Z"), DESCENDING("Z → A"), NUMERIC("Numérique"), LENGTH("Longueur") }

data class TransformOptions(
    val locale: Locale = Locale.FRENCH,
    val ignoreCase: Boolean = false,
    val sortOrder: SortOrder = SortOrder.ASCENDING,
    val removeEmptyLines: Boolean = false,
)

data class TransformResult(val text: String, val summary: String?)

object TextTransforms {
    private val multiSpaces = Regex("[ \\t\\u00A0]+")
    private val leadingNumber = Regex("^\\s*[-+]?\\d+(?:[.,]\\d+)?")

    fun apply(text: String, op: TextOperation, options: TransformOptions = TransformOptions()): TransformResult {
        val input = text.replace("\r\n", "\n")
        return when (op) {
            TextOperation.UPPERCASE -> TransformResult(input.uppercase(options.locale), null)
            TextOperation.LOWERCASE -> TransformResult(input.lowercase(options.locale), null)
            TextOperation.CAPITALIZE_WORDS -> TransformResult(capitalizeWords(input, options.locale), null)
            TextOperation.CAPITALIZE_SENTENCES -> TransformResult(capitalizeSentences(input, options.locale), null)
            TextOperation.CLEAN_SPACES -> cleanSpaces(input, options.removeEmptyLines)
            TextOperation.DEDUPE_LINES -> dedupe(input, options)
            TextOperation.SORT_LINES -> TransformResult(sortLines(input, options), null)
            TextOperation.REVERSE_TEXT -> TransformResult(reverseGraphemes(input), null)
            TextOperation.REVERSE_LINES -> TransformResult(input.split('\n').asReversed().joinToString("\n"), null)
        }
    }

    private fun capitalizeWords(text: String, locale: Locale): String {
        val sb = StringBuilder(text.length)
        var startOfWord = true
        for (c in text) {
            if (c.isLetter()) {
                sb.append(if (startOfWord) c.titlecase(locale) else c.lowercase(locale))
                startOfWord = false
            } else {
                sb.append(c)
                // Après une apostrophe, pas de majuscule (« aujourd'hui ») ; après un trait d'union, oui (« Jean-Pierre »).
                startOfWord = c != '\'' && c != '’'
            }
        }
        return sb.toString()
    }

    private fun capitalizeSentences(text: String, locale: Locale): String {
        val sb = StringBuilder(text.length)
        var capitalizeNext = true
        for (c in text) {
            when {
                c.isLetter() && capitalizeNext -> { sb.append(c.titlecase(locale)); capitalizeNext = false }
                c.isLetter() -> sb.append(c.lowercase(locale))
                else -> {
                    sb.append(c)
                    if (c == '.' || c == '!' || c == '?' || c == '…' || c == '\n') capitalizeNext = true
                    else if (c.isLetterOrDigit()) capitalizeNext = false
                }
            }
        }
        return sb.toString()
    }

    private fun cleanSpaces(text: String, removeEmptyLines: Boolean): TransformResult {
        val lines = text.split('\n').map { it.replace(multiSpaces, " ").trim() }
        val result = ArrayList<String>()
        var previousEmpty = false
        for (line in lines) {
            val empty = line.isEmpty()
            if (empty && (removeEmptyLines || previousEmpty)) continue
            result += line
            previousEmpty = empty
        }
        while (result.isNotEmpty() && result.first().isEmpty()) result.removeAt(0)
        while (result.isNotEmpty() && result.last().isEmpty()) result.removeAt(result.size - 1)
        val out = result.joinToString("\n")
        return TransformResult(out, "${text.length - out.length} caractère(s) supprimé(s)")
    }

    private fun dedupe(text: String, options: TransformOptions): TransformResult {
        val seen = HashSet<String>()
        val lines = text.split('\n')
        val kept = lines.filter { line ->
            val key = if (options.ignoreCase) line.lowercase(options.locale) else line
            seen.add(key)
        }
        return TransformResult(kept.joinToString("\n"), "${lines.size - kept.size} ligne(s) en double supprimée(s)")
    }

    private fun sortLines(text: String, options: TransformOptions): String {
        val lines = text.split('\n')
        val collator = Collator.getInstance(options.locale).apply {
            strength = if (options.ignoreCase) Collator.SECONDARY else Collator.TERTIARY
        }
        val sorted = when (options.sortOrder) {
            SortOrder.ASCENDING -> lines.sortedWith { a, b -> collator.compare(a, b) }
            SortOrder.DESCENDING -> lines.sortedWith { a, b -> collator.compare(b, a) }
            SortOrder.LENGTH -> lines.sortedBy { it.length }
            SortOrder.NUMERIC -> lines.sortedWith(
                compareBy<String> { line ->
                    leadingNumber.find(line)?.value?.trim()?.replace(',', '.')?.toDoubleOrNull() ?: Double.MAX_VALUE
                }.thenComparator { a, b -> collator.compare(a, b) }
            )
        }
        return sorted.joinToString("\n")
    }

    /** Inverse le texte graphème par graphème (préserve accents combinés et emoji simples). */
    fun reverseGraphemes(text: String): String {
        if (text.isEmpty()) return text
        val it = BreakIterator.getCharacterInstance(Locale.ROOT)
        it.setText(text)
        val clusters = ArrayList<String>()
        var start = it.first()
        var end = it.next()
        while (end != BreakIterator.DONE) {
            clusters += text.substring(start, end)
            start = end
            end = it.next()
        }
        return clusters.asReversed().joinToString("")
    }
}

data class FindReplaceOptions(
    val useRegex: Boolean = false,
    val ignoreCase: Boolean = false,
    val wholeWord: Boolean = false,
)

object FindReplace {
    fun run(text: String, find: String, replacement: String, options: FindReplaceOptions): Outcome<ReplaceResult> = outcomeOf {
        if (find.isEmpty()) fail("Indiquez le texte à rechercher.")
        var pattern = if (options.useRegex) find else Pattern.quote(find)
        if (options.wholeWord) pattern = "(?<![\\p{L}\\p{N}_])(?:$pattern)(?![\\p{L}\\p{N}_])"
        val compiled = SafeRegex.compile(pattern, com.alsalamy.droidtools.tools.text.RegexOptions(ignoreCase = options.ignoreCase))
        SafeRegex.replace(compiled, text, replacement, useGroupRefs = options.useRegex)
    }
}
