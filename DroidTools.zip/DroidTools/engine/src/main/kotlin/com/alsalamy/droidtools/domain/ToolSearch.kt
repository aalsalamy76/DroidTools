package com.alsalamy.droidtools.domain

import com.alsalamy.droidtools.core.TextNormalizer

/**
 * Recherche instantanée, insensible à la casse et aux accents.
 *
 * Chaque mot de la requête doit correspondre au début d'un mot du nom, des mots-clés,
 * de la catégorie ou de la description. Les correspondances sur le nom et les mots-clés
 * sont mieux classées que celles sur la description.
 */
object ToolSearch {

    private class Indexed(
        val tool: ToolDefinition,
        val name: String,
        val nameWords: List<String>,
        val keywords: List<String>,
        val keywordWords: List<String>,
        val categoryWords: List<String>,
        val descriptionWords: List<String>,
    )

    private val cache = HashMap<String, Indexed>()

    private fun index(tool: ToolDefinition): Indexed = synchronized(cache) {
        cache.getOrPut(tool.id) {
            val keywords = tool.keywords.map(TextNormalizer::normalize)
            Indexed(
                tool = tool,
                name = TextNormalizer.normalize(tool.name),
                nameWords = TextNormalizer.words(tool.name),
                keywords = keywords,
                keywordWords = keywords.flatMap { it.split(' ') }.filter { it.isNotEmpty() },
                categoryWords = (TextNormalizer.words(tool.category.label) +
                    tool.category.keywords.flatMap(TextNormalizer::words)),
                descriptionWords = TextNormalizer.words(tool.description),
            )
        }
    }

    fun search(query: String, tools: List<ToolDefinition> = ToolCatalog.all): List<ToolDefinition> {
        val normalizedQuery = TextNormalizer.normalize(query)
        if (normalizedQuery.isEmpty()) return emptyList()
        val tokens = normalizedQuery.split(' ').filter { it.isNotEmpty() }
        return tools.asSequence()
            .map { index(it) }
            .mapNotNull { indexed -> score(indexed, normalizedQuery, tokens)?.let { indexed.tool to it } }
            .sortedWith(compareByDescending<Pair<ToolDefinition, Int>> { it.second }
                .thenBy { if (it.first.isAvailable) 0 else 1 }
                .thenBy { TextNormalizer.normalize(it.first.name) })
            .map { it.first }
            .toList()
    }

    private fun score(item: Indexed, phrase: String, tokens: List<String>): Int? {
        var total = 0
        for (token in tokens) {
            val tokenScore = tokenScore(item, token) ?: return null
            total += tokenScore
        }
        // Bonus pour une correspondance exacte de toute la requête.
        if (item.name == phrase) total += 200
        else if (item.name.startsWith(phrase)) total += 80
        if (item.keywords.any { it == phrase }) total += 120
        else if (item.keywords.any { it.startsWith(phrase) }) total += 40
        return total
    }

    private fun tokenScore(item: Indexed, token: String): Int? {
        var best = -1
        fun consider(value: Int) { if (value > best) best = value }
        for (w in item.nameWords) {
            if (w == token) consider(60) else if (w.startsWith(token)) consider(45)
        }
        for (w in item.keywordWords) {
            if (w == token) consider(50) else if (w.startsWith(token)) consider(35)
        }
        for (w in item.categoryWords) {
            if (w == token) consider(25) else if (w.startsWith(token)) consider(15)
        }
        if (token.length >= 3) {
            for (w in item.descriptionWords) {
                if (w.startsWith(token)) consider(8)
            }
        }
        return if (best >= 0) best else null
    }
}
