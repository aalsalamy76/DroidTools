package com.alsalamy.droidtools.core

import java.text.Normalizer
import java.util.Locale

/** Normalisation utilisée par la recherche : insensible à la casse, aux accents et à la ponctuation légère. */
object TextNormalizer {
    private val combiningMarks = Regex("\\p{Mn}+")
    /** Tout ce qui n'est ni lettre, ni chiffre, ni « % » sépare les mots (tirets longs, ponctuation, symboles…). */
    private val separators = Regex("[^\\p{L}\\p{N}%]+")

    fun normalize(input: String): String {
        val decomposed = Normalizer.normalize(input, Normalizer.Form.NFD)
            .replace(combiningMarks, "")
            .lowercase(Locale.ROOT)
            .replace("œ", "oe")
            .replace("æ", "ae")
            .replace("ß", "ss")
        return decomposed.replace(separators, " ").trim()
    }

    fun words(input: String): List<String> =
        normalize(input).split(' ').filter { it.isNotEmpty() }
}
