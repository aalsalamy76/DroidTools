package com.alsalamy.droidtools.tools.codec

import com.alsalamy.droidtools.core.Outcome
import com.alsalamy.droidtools.core.fail
import com.alsalamy.droidtools.core.outcomeOf
import java.net.URLDecoder
import java.net.URLEncoder
import java.nio.ByteBuffer
import java.nio.charset.CharacterCodingException
import java.nio.charset.CodingErrorAction
import java.util.Base64

data class DecodedBytes(
    val bytes: ByteArray,
    /** Texte UTF-8 si les octets forment un UTF-8 valide, sinon null. */
    val text: String?,
) {
    val hex: String get() = Hex.encode(bytes, separator = " ")
    override fun equals(other: Any?) = other is DecodedBytes && bytes.contentEquals(other.bytes) && text == other.text
    override fun hashCode() = bytes.contentHashCode()
}

object Hex {
    private val digits = "0123456789abcdef".toCharArray()

    fun encode(bytes: ByteArray, separator: String = "", uppercase: Boolean = false): String {
        val sb = StringBuilder(bytes.size * (2 + separator.length))
        bytes.forEachIndexed { i, b ->
            if (i > 0) sb.append(separator)
            val v = b.toInt() and 0xFF
            sb.append(digits[v ushr 4]).append(digits[v and 0x0F])
        }
        return if (uppercase) sb.toString().uppercase() else sb.toString()
    }
}

object Utf8 {
    /** Décodage strict : retourne null si les octets ne sont pas de l'UTF-8 valide. */
    fun decodeStrict(bytes: ByteArray): String? = try {
        Charsets.UTF_8.newDecoder()
            .onMalformedInput(CodingErrorAction.REPORT)
            .onUnmappableCharacter(CodingErrorAction.REPORT)
            .decode(ByteBuffer.wrap(bytes))
            .toString()
    } catch (e: CharacterCodingException) {
        null
    }
}

object Base64Codec {
    const val MAX_INPUT_CHARS = 5_000_000

    fun encode(text: String, urlSafe: Boolean = false, padding: Boolean = true): String {
        val encoder = (if (urlSafe) Base64.getUrlEncoder() else Base64.getEncoder())
            .let { if (padding) it else it.withoutPadding() }
        return encoder.encodeToString(text.toByteArray(Charsets.UTF_8))
    }

    /** Décode du Base64 standard ou « URL », avec ou sans remplissage ; les espaces et retours à la ligne sont ignorés. */
    fun decode(input: String): Outcome<DecodedBytes> = outcomeOf {
        if (input.length > MAX_INPUT_CHARS) fail("Texte trop long.")
        val compact = input.filterNot { it.isWhitespace() }
        if (compact.isEmpty()) fail("Saisissez du texte Base64.")
        val invalid = compact.indexOfFirst { !(it.isLetterOrDigit() && it.code < 128) && it != '+' && it != '/' && it != '-' && it != '_' && it != '=' }
        if (invalid >= 0) fail("Caractère « ${compact[invalid]} » invalide en Base64 (position ${invalid + 1}).")
        if (compact.contains('-') || compact.contains('_')) {
            if (compact.contains('+') || compact.contains('/')) fail("Mélange des alphabets Base64 standard et URL.")
        }
        val normalized = compact.replace('-', '+').replace('_', '/').trimEnd('=')
        if (normalized.contains('=')) fail("Caractère de remplissage « = » mal placé.")
        if (normalized.length % 4 == 1) fail("Longueur invalide : le texte Base64 semble tronqué.")
        val padded = normalized + "=".repeat((4 - normalized.length % 4) % 4)
        val bytes = try {
            Base64.getDecoder().decode(padded)
        } catch (e: IllegalArgumentException) {
            fail("Texte Base64 invalide.")
        }
        DecodedBytes(bytes, Utf8.decodeStrict(bytes))
    }
}

enum class UrlEncodingMode(val label: String) {
    /** RFC 3986 : espace → %20, caractères non réservés conservés. */
    COMPONENT("Composant d'URL (RFC 3986)"),
    /** application/x-www-form-urlencoded : espace → +. */
    FORM("Formulaire (espace = +)"),
}

object UrlCodec {
    fun encode(text: String, mode: UrlEncodingMode): String {
        val form = URLEncoder.encode(text, "UTF-8")
        return when (mode) {
            UrlEncodingMode.FORM -> form
            UrlEncodingMode.COMPONENT -> form.replace("+", "%20").replace("*", "%2A").replace("%7E", "~")
        }
    }

    fun decode(text: String, mode: UrlEncodingMode): Outcome<String> = outcomeOf {
        // En mode RFC 3986, « + » est un caractère littéral : on le protège avant URLDecoder.
        val prepared = if (mode == UrlEncodingMode.COMPONENT) text.replace("+", "%2B") else text
        val bad = Regex("%(?![0-9A-Fa-f]{2})").find(prepared)
        if (bad != null) fail("Séquence « % » invalide (position ${bad.range.first + 1}) : deux chiffres hexadécimaux sont attendus.")
        try {
            URLDecoder.decode(prepared, "UTF-8")
        } catch (e: IllegalArgumentException) {
            fail("Texte encodé invalide.")
        }
    }
}
