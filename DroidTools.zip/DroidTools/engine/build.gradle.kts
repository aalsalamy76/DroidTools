import org.jetbrains.kotlin.gradle.dsl.JvmTarget

// Module de logique pure : aucune dépendance Android, aucun accès réseau.
// Toute la logique des outils (calculs, formulaires, validations) vit ici pour être testée unitairement.
plugins {
    alias(libs.plugins.kotlin.jvm)
}

java {
    sourceCompatibility = JavaVersion.VERSION_1_8
    targetCompatibility = JavaVersion.VERSION_1_8
}

kotlin {
    compilerOptions {
        jvmTarget.set(JvmTarget.JVM_1_8)
        // Compile contre l'API du JDK 8, sous-ensemble disponible dès Android 8.0 (minSdk 26).
        // Empêche d'appeler par erreur une méthode Java 9+ absente des anciennes versions d'Android
        // (ex. LocalDate.ofInstant, List.removeFirst) : l'erreur apparaît dès la compilation.
        freeCompilerArgs.add("-Xjdk-release=1.8")
    }
}

dependencies {
    testImplementation(libs.junit)
}

tasks.test {
    useJUnit()
    testLogging {
        events("failed")
        exceptionFormat = org.gradle.api.tasks.testing.logging.TestExceptionFormat.FULL
    }
}
