# Politique de confidentialité de DroidTools

Version de l'application : 0.3.0 — mise à jour le 3 novembre 2026.
Développeur : Abdullah AL-SALAMY.

Ce document décrit le comportement réel de cette version de l'application. Le code est la source de vérité : toute évolution du code qui modifie l'accès aux données entraîne la mise à jour de ce document.

## En bref

- DroidTools ne déclare pas la permission Internet : Android l'empêche d'ouvrir la moindre connexion réseau.
- Aucune publicité, aucun traceur, aucun outil d'analyse d'usage, aucun identifiant publicitaire, aucun service de rapport de plantage.
- Aucune donnée n'est envoyée au développeur ni à un tiers.
- Ce que vous saisissez dans un outil reste en mémoire le temps du calcul et n'est pas enregistré. Seules exceptions : la checklist (que vous remplissez volontairement) et vos réglages, favoris et outils récents.

## Données accessibles et finalités

- Textes, nombres et dates saisis dans les outils : utilisés uniquement pour calculer le résultat affiché. Ils restent en mémoire et disparaissent quand vous fermez l'outil.
- Mots de passe, phrases de passe, codes PIN et jetons générés, mot de passe analysé : jamais enregistrés, jamais journalisés, jamais ajoutés à l'historique. Ces écrans bloquent les captures d'écran et masquent leur contenu dans la liste des applications récentes.
- Fichier choisi dans l'outil « Hash de fichier » : vous le sélectionnez vous-même dans le sélecteur de fichiers d'Android. DroidTools le lit par blocs pour calculer son empreinte, sans le copier ni le modifier. L'accès est limité à ce fichier et ne dure que le temps du calcul. Aucune permission de stockage n'est demandée.
- Éléments de la checklist : enregistrés sur l'appareil jusqu'à ce que vous les supprimiez.
- Réglages, favoris et outils récents : enregistrés sur l'appareil. Les outils récents ne contiennent que des identifiants d'outils (par exemple « Calculatrice »), jamais ce que vous y avez saisi.
- Heure et fuseau horaire de l'appareil : lus pour les outils de date et d'heure, jamais enregistrés.
- Presse-papiers : DroidTools y écrit uniquement quand vous touchez un bouton « Copier ». L'application ne lit jamais le presse-papiers. Les valeurs sensibles copiées sont signalées comme telles à Android, qui en masque l'aperçu (Android 13 et plus).

## Permissions

DroidTools ne demande aucune permission à l'utilisateur dans cette version. Aucun outil disponible n'utilise la caméra, le microphone ou la localisation.

Le manifeste final peut contenir une permission technique de signature ajoutée par la bibliothèque AndroidX (DYNAMIC_RECEIVER_NOT_EXPORTED_PERMISSION) : elle est propre à l'application et ne donne accès à aucune de vos données. L'écran « Confidentialité et sécurité » affiche la liste exacte des permissions, lue sur l'appareil.

Les futurs outils qui auront besoin de la caméra, du microphone ou de la localisation demanderont la permission uniquement au moment où vous les ouvrez, après une explication. Un refus ne bloquera jamais le reste de l'application.

## Accès réseau

Aucun. Sans la permission Internet, DroidTools ne peut contacter aucun serveur.

Le lien vers le profil LinkedIn du développeur, sur la page « À propos », s'ouvre dans votre navigateur (une autre application), uniquement si vous touchez le bouton prévu.

Les outils réseau prévus (DNS, ping, en-têtes HTTP…) ne sont pas implémentés dans cette version. S'ils le sont un jour, ils seront signalés « Réseau requis », serviront uniquement au diagnostic de réseaux que vous êtes autorisé à analyser, et ce document sera mis à jour.

## Stockage

Toutes les données enregistrées restent dans l'espace privé de l'application, inaccessible aux autres applications :

- réglages, favoris et outils récents : Jetpack DataStore ;
- checklist : Jetpack DataStore, non chiffrée (n'y notez pas d'informations secrètes).

Ces données sont exclues des sauvegardes Android dans le cloud et des transferts d'appareil à appareil.

## Conservation

Les données enregistrées sont conservées jusqu'à ce que vous les supprimiez ou que vous désinstalliez l'application. Rien n'est conservé ailleurs que sur votre appareil.

## Suppression

Depuis Réglages > Confidentialité et sécurité :

- désactiver la mémorisation des outils récents (ce qui efface aussi l'historique existant) ;
- vider l'historique ;
- vider le cache et les fichiers temporaires ;
- effacer toutes les données de DroidTools (réglages, favoris, historique, checklist, cache).

La désinstallation de l'application supprime toutes ses données.

## Bibliothèques tierces

DroidTools utilise uniquement des bibliothèques open source de Google (AndroidX, Jetpack Compose) et de JetBrains (Kotlin), sous licence Apache 2.0. Aucune n'est un service d'analyse, de publicité ou de rapport de plantage. L'application n'utilise ni Google Play Services ni Firebase. La liste figure dans « Licences open source ».

## Contact

Pour toute question, contactez le développeur via son profil LinkedIn, indiqué dans la page « À propos ».
