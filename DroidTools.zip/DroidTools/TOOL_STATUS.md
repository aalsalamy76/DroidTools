# État des outils DroidTools

Tableau généré à partir du catalogue (`engine/.../domain/ToolCatalog.kt`), la même source que l'application : il ne peut pas diverger du code.

**Depuis la version 0.3.0, l'application ne propose que les outils qui fonctionnent** (73 outils : FONCTIONNEL ou PARTIEL). Les outils NON IMPLÉMENTÉS restent listés ici comme feuille de route, pour la traçabilité du cahier des charges, mais ils ne sont plus ni affichés, ni trouvables par la recherche, ni ouvrables dans l'application (vérifié par les tests du module `engine`).

Signification des statuts :

- **FONCTIONNEL** : logique implémentée et couverte par les tests unitaires, interface Android compilée par l'intégration continue, fiche de confidentialité exacte.
- **PARTIEL** : utilisable, avec des limites connues affichées dans l'application et rappelées ci-dessous.
- **NON IMPLÉMENTÉ** : feuille de route, absent de l'application.

Les numéros renvoient au cahier des charges (1 à 145). Certains numéros en double y sont regroupés : par exemple, les compteurs de mots 58, 59 et 71 à 73 forment un seul outil.

| Statut | Outils |
|---|---|
| FONCTIONNEL | 70 |
| PARTIEL | 3 |
| NON IMPLÉMENTÉ | 61 |

### Calculs

| N° | Outil | Statut | Interface | Réseau | Remarques |
|---|---|---|---|---|---|
| 1 | Calculatrice | FONCTIONNEL | écran dédié | non |  |
| 2 | Calculatrice scientifique | FONCTIONNEL | écran dédié | non |  |
| 3 | Pourcentages | FONCTIONNEL | formulaire | non |  |
| 4 | TVA HT / TTC | FONCTIONNEL | formulaire | non |  |
| 5 | Remises | FONCTIONNEL | formulaire | non |  |
| 6 | Règle de trois | FONCTIONNEL | formulaire | non |  |
| 7 | Partage d'addition | FONCTIONNEL | formulaire | non |  |
| 8 | Moyenne et statistiques | FONCTIONNEL | formulaire | non |  |
| 9 | Ratios | FONCTIONNEL | formulaire | non |  |

### Conversions

| N° | Outil | Statut | Interface | Réseau | Remarques |
|---|---|---|---|---|---|
| 10 | Longueur | FONCTIONNEL | formulaire | non |  |
| 11 | Surface | FONCTIONNEL | formulaire | non |  |
| 12 | Volume | FONCTIONNEL | formulaire | non |  |
| 13 | Masse | FONCTIONNEL | formulaire | non |  |
| 14 | Température | FONCTIONNEL | formulaire | non |  |
| 15 | Vitesse | FONCTIONNEL | formulaire | non |  |
| 16 | Pression | FONCTIONNEL | formulaire | non |  |
| 17 | Énergie | FONCTIONNEL | formulaire | non |  |
| 18 | Puissance | FONCTIONNEL | formulaire | non |  |
| 19 | Temps | FONCTIONNEL | formulaire | non |  |
| 20 | Angles | FONCTIONNEL | formulaire | non |  |
| 21 | Stockage numérique | FONCTIONNEL | formulaire | non |  |
| 22 | Binaire / décimal / hexadécimal | FONCTIONNEL | formulaire | non |  |

### Réseau / IT

| N° | Outil | Statut | Interface | Réseau | Remarques |
|---|---|---|---|---|---|
| 23 | Informations Wi-Fi | NON IMPLÉMENTÉ | — | oui |  |
| 24 | Force du signal | NON IMPLÉMENTÉ | — | oui |  |
| 25 | Adresse IP locale | NON IMPLÉMENTÉ | — | oui |  |
| 26 | Informations réseau | NON IMPLÉMENTÉ | — | oui |  |
| 27 | DNS Lookup | NON IMPLÉMENTÉ | — | oui |  |
| 28 | Ping | NON IMPLÉMENTÉ | — | oui |  |
| 29 | Calculateur IPv4 | FONCTIONNEL | formulaire | non |  |
| 30 | Calculateur CIDR | FONCTIONNEL | formulaire | non |  |
| 31 | IPv4 vers binaire | FONCTIONNEL | formulaire | non |  |
| 32 | Binaire vers IPv4 | FONCTIONNEL | formulaire | non |  |
| 33 | Analyse de sous-réseau | FONCTIONNEL | formulaire | non |  |
| 34 | Scanner réseau local | NON IMPLÉMENTÉ | — | oui |  |
| 35 | Scanner de ports | NON IMPLÉMENTÉ | — | oui |  |
| 36 | Informations DNS | NON IMPLÉMENTÉ | — | oui |  |
| 37 | En-têtes HTTP | NON IMPLÉMENTÉ | — | oui |  |
| 38 | Certificat SSL/TLS | NON IMPLÉMENTÉ | — | oui |  |
| 39 | Analyse de User-Agent | PARTIEL | formulaire | non | Analyse heuristique : un User-Agent peut être falsifié. Les navigateurs récents figent la version du système et le modèle d'appareil (« UA reduction ») : ces informations peuvent être approximatives. |

### QR & codes-barres

| N° | Outil | Statut | Interface | Réseau | Remarques |
|---|---|---|---|---|---|
| 40 | Scanner QR | NON IMPLÉMENTÉ | — | non |  |
| 41, 44, 45, 46, 47 | Générateur QR | NON IMPLÉMENTÉ | — | non |  |
| 42 | Scanner code-barres | NON IMPLÉMENTÉ | — | non |  |
| 43 | Générateur code-barres | NON IMPLÉMENTÉ | — | non |  |
| 48 | Historique des scans | NON IMPLÉMENTÉ | — | non |  |

### PDF & documents

| N° | Outil | Statut | Interface | Réseau | Remarques |
|---|---|---|---|---|---|
| 49 | Scanner document | NON IMPLÉMENTÉ | — | non |  |
| 50, 69 | Images vers PDF | NON IMPLÉMENTÉ | — | non |  |
| 51 | Fusion PDF | NON IMPLÉMENTÉ | — | non |  |
| 52 | Division PDF | NON IMPLÉMENTÉ | — | non |  |
| 53 | Extraire des pages | NON IMPLÉMENTÉ | — | non |  |
| 54 | Réorganiser les pages | NON IMPLÉMENTÉ | — | non |  |
| 55 | Rotation de pages | NON IMPLÉMENTÉ | — | non |  |
| 56 | Compression PDF | NON IMPLÉMENTÉ | — | non |  |
| 57 | Extraction de texte PDF | NON IMPLÉMENTÉ | — | non |  |

### Couleurs

| N° | Outil | Statut | Interface | Réseau | Remarques |
|---|---|---|---|---|---|
| 60 | Redimensionnement | NON IMPLÉMENTÉ | — | non |  |
| 61 | Compression d'image | NON IMPLÉMENTÉ | — | non |  |
| 62 | Recadrage | NON IMPLÉMENTÉ | — | non |  |
| 63 | Rotation d'image | NON IMPLÉMENTÉ | — | non |  |
| 64 | Détecteur de couleur | NON IMPLÉMENTÉ | — | non |  |
| 65, 66 | Couleurs RGB ↔ HEX | FONCTIONNEL | formulaire | non |  |
| 67 | Inspecteur EXIF | NON IMPLÉMENTÉ | — | non |  |
| 68 | Suppression des métadonnées EXIF | NON IMPLÉMENTÉ | — | non |  |
| 70 | Loupe | NON IMPLÉMENTÉ | — | non |  |

### Texte & dev

| N° | Outil | Statut | Interface | Réseau | Remarques |
|---|---|---|---|---|---|
| 58, 59, 71, 72, 73 | Compteur de texte | FONCTIONNEL | formulaire | non |  |
| 74 | Majuscules | FONCTIONNEL | formulaire | non |  |
| 75 | Minuscules | FONCTIONNEL | formulaire | non |  |
| 76 | Capitalisation | FONCTIONNEL | formulaire | non |  |
| 77 | Nettoyage des espaces | FONCTIONNEL | formulaire | non |  |
| 78 | Suppression des doublons | FONCTIONNEL | formulaire | non |  |
| 79 | Trier les lignes | FONCTIONNEL | formulaire | non |  |
| 80 | Inverser le texte | FONCTIONNEL | formulaire | non |  |
| 81 | Rechercher / remplacer | FONCTIONNEL | formulaire | non |  |
| 82 | Base64 : encoder | FONCTIONNEL | formulaire | non |  |
| 83 | Base64 : décoder | FONCTIONNEL | formulaire | non |  |
| 84 | URL : encoder | FONCTIONNEL | formulaire | non |  |
| 85 | URL : décoder | FONCTIONNEL | formulaire | non |  |
| 86 | JSON : formater | FONCTIONNEL | formulaire | non |  |
| 87 | JSON : valider | FONCTIONNEL | formulaire | non |  |
| 88 | JSON : minifier | FONCTIONNEL | formulaire | non |  |
| 89 | XML : formater | PARTIEL | formulaire | non | Vérifie la structure (balises, imbrication, attributs) mais pas un schéma XSD/DTD. Les entités ne sont jamais développées (protection contre XXE) : elles sont conservées telles quelles. Dans un contenu mixte (texte + balises), les espaces peuvent être normalisés. |
| 90 | Testeur d'expressions régulières | FONCTIONNEL | formulaire | non |  |
| 91 | Échappement de chaînes | FONCTIONNEL | formulaire | non |  |
| 92 | Inspecteur Unicode | FONCTIONNEL | formulaire | non |  |
| 93 | Timestamp Unix actuel | FONCTIONNEL | formulaire | non |  |
| 94 | Timestamp → date | FONCTIONNEL | formulaire | non |  |
| 95 | Date → timestamp | FONCTIONNEL | formulaire | non |  |
| 96, 102 | Générateur UUID | FONCTIONNEL | formulaire | non |  |
| 97 | Générateur ULID | FONCTIONNEL | formulaire | non |  |

### Sécurité

| N° | Outil | Statut | Interface | Réseau | Remarques |
|---|---|---|---|---|---|
| 98 | Générateur de mots de passe | FONCTIONNEL | formulaire | non |  |
| 99 | Générateur de phrases de passe | FONCTIONNEL | formulaire | non |  |
| 100 | Générateur de code PIN | FONCTIONNEL | formulaire | non |  |
| 101 | Analyse de robustesse | FONCTIONNEL | formulaire | non |  |
| 103 | Générateur aléatoire | FONCTIONNEL | formulaire | non |  |
| 104 | SHA-256 | FONCTIONNEL | formulaire | non |  |
| 105 | SHA-512 | FONCTIONNEL | formulaire | non |  |
| 106 | MD5 (compatibilité) | FONCTIONNEL | formulaire | non |  |
| 107 | Comparaison de hash | FONCTIONNEL | formulaire | non |  |
| 108 | Hash de fichier | FONCTIONNEL | écran dédié | non |  |
| 109 | Coffre-fort local chiffré | NON IMPLÉMENTÉ | — | non |  |

### Capteurs

| N° | Outil | Statut | Interface | Réseau | Remarques |
|---|---|---|---|---|---|
| 110 | Niveau | NON IMPLÉMENTÉ | — | non |  |
| 111 | Fil à plomb | NON IMPLÉMENTÉ | — | non |  |
| 112 | Boussole | NON IMPLÉMENTÉ | — | non |  |
| 113 | Accéléromètre | NON IMPLÉMENTÉ | — | non |  |
| 114 | Gyroscope | NON IMPLÉMENTÉ | — | non |  |
| 115 | Magnétomètre | NON IMPLÉMENTÉ | — | non |  |
| 116 | Détecteur de champ magnétique | NON IMPLÉMENTÉ | — | non |  |
| 117 | Luxmètre | NON IMPLÉMENTÉ | — | non |  |
| 118 | Baromètre | NON IMPLÉMENTÉ | — | non |  |
| 119 | Vibromètre | NON IMPLÉMENTÉ | — | non |  |
| 120 | Décibelmètre | NON IMPLÉMENTÉ | — | non |  |
| 121 | Compteur de vitesse GPS | NON IMPLÉMENTÉ | — | non |  |
| 122 | Coordonnées GPS | NON IMPLÉMENTÉ | — | non |  |
| 123 | Liste des capteurs | NON IMPLÉMENTÉ | — | non |  |
| 124 | Informations appareil | NON IMPLÉMENTÉ | — | non |  |
| 125 | Informations batterie | NON IMPLÉMENTÉ | — | non |  |

### Tests appareil

| N° | Outil | Statut | Interface | Réseau | Remarques |
|---|---|---|---|---|---|
| 126 | Test écran | NON IMPLÉMENTÉ | — | non |  |
| 127 | Test pixels | NON IMPLÉMENTÉ | — | non |  |
| 128 | Test tactile | NON IMPLÉMENTÉ | — | non |  |
| 129 | Test vibration | NON IMPLÉMENTÉ | — | non |  |
| 130 | Test haut-parleur | NON IMPLÉMENTÉ | — | non |  |
| 131 | Test microphone | NON IMPLÉMENTÉ | — | non |  |

### Audio

| N° | Outil | Statut | Interface | Réseau | Remarques |
|---|---|---|---|---|---|
| 132 | Enregistreur vocal | NON IMPLÉMENTÉ | — | non |  |
| 133 | Reconnaissance vocale | NON IMPLÉMENTÉ | — | non |  |
| 134 | Synthèse vocale | NON IMPLÉMENTÉ | — | non |  |
| 135 | Générateur de tonalités | NON IMPLÉMENTÉ | — | non |  |
| 136 | Lecteur audio | NON IMPLÉMENTÉ | — | non |  |

### Quotidien

| N° | Outil | Statut | Interface | Réseau | Remarques |
|---|---|---|---|---|---|
| 137 | Chronomètre | FONCTIONNEL | écran dédié | non |  |
| 138 | Minuteur | PARTIEL | écran dédié | non | En arrière-plan, le décompte continue mais l'alerte n'est émise qu'à votre retour dans l'outil (aucune notification). Le minuteur est perdu si vous fermez l'outil ou si Android arrête l'application. À l'échéance, l'outil affiche « Temps écoulé » et émet un bip sonore. L'écran reste allumé pendant le décompte pour que le minuteur continue. |
| 139 | Compte à rebours | FONCTIONNEL | formulaire | non |  |
| 140 | Différence entre deux dates | FONCTIONNEL | formulaire | non |  |
| 141 | Calcul d'âge | FONCTIONNEL | formulaire | non |  |
| 142 | Nombres aléatoires | FONCTIONNEL | formulaire | non |  |
| 143 | Dé | FONCTIONNEL | formulaire | non |  |
| 144 | Pile ou face | FONCTIONNEL | formulaire | non |  |
| 145 | Checklist | FONCTIONNEL | écran dédié | non |  |

